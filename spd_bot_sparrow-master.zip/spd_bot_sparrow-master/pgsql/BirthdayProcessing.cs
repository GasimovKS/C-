﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{
  /// <summary>
  /// процесс поздравления, ставим задачу в ауре, отслеживаем её выполнение
  /// </summary>
  [Table("birthdayprocessing")]
  public class BirthdayProcessing
    {
    [Column("id")]
    public int id { get; set; }
    [Column("iduser")]
    public int iduser { get; set; }
    [Column("idbirthdayman")]
    public int idbirthdayman { get; set; }
    [Column("task")]
    public int task { get; set; }
    [Column("birthday")]
    public DateTime birthday { get; set; }
    [Column("complited")]
    public bool complited { get; set; }
    [Column("idtracking")]
    public int idtracking { get; set; }
    }
}
