﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace spd_bot_sparrow
{
  [Table("users")]
  public class User
  {
    [Column("id")]
    public int Id { get; set; }
    [Column("login")]
    public string Login { get; set; }
    [Column("fio")]
    public string Fio { get; set; }
    [Column("date_of_birth")]
    public DateTime Date_of_birth { get; set; }
    [Column("employee_spd")]
    public bool Employee_SPD { get; set; }
    [Column("duty")]
    public bool? Duty { get; set; }
    [Column("intern")]
    public bool Intern { get; set; }
    [Column("team")]
    public string? Team { get; set; }
    [Column("idaura")]
    public int IdAura { get; set; }
    [Column("rank")]
    public int? Rank { get; set; }
    [Column("teamlead")]
    public bool Teamlead { get; set; }
  }
}
