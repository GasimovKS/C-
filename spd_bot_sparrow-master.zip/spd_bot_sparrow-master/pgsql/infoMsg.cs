﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace spd_bot_sparrow
{
  [Table("infomsg")]
  public class InfoMsg
  {
    [Column("id")]
    public int id { get; set; }
    [Column("date")]
    public DateTime date { get; set; }
    [Column("msgtype")]
    public string msgtype { get; set; }
    [Column("iduser")]
    public int? iduser { get; set; }
    [Column("value")]
    public string? value { get; set; }
  }
}
