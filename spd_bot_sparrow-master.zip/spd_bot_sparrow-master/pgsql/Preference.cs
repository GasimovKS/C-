﻿using System.ComponentModel.DataAnnotations.Schema;

namespace spd_bot_sparrow
{
  [Table("preferences")]
  public class Preference
  {
    [Column("id")]
    public int Id { get; set; }
    [Column("iduser")]
    public int Iduser { get; set; }
    [Column("monday")]
    public bool Monday { get; set; }
    [Column("tuesday")]
    public bool Tuesday { get; set; }
    [Column("wednesday")]
    public bool Wednesday { get; set; }
    [Column("thursday")]
    public bool Thursday { get; set; }
    [Column("friday")]
    public bool Friday { get; set; }
    [Column("saturday")]
    public bool Saturday { get; set; }
    [Column("sunday")]
    public bool Sunday { get; set; }


  }
}
