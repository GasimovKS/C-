﻿using Microsoft.EntityFrameworkCore;
using System;

namespace spd_bot_sparrow
{
  public class ApplicationContext : DbContext
  {
    public DbSet<Absence> Absences { get; set; }
    public DbSet<Calendar> Calendars { get; set; }
    public DbSet<DutyHistory> DutyHistorys { get; set; }
    public DbSet<DirectChannel> DirectChannels { get; set; }
    public DbSet<User> Users { get; set; }
    public DbSet<Preference> Preferences { get; set; }
    public DbSet<TmpDutyNotHistory> TmpDutyNotHistorys { get; set; }
    public DbSet<BirthdayMessageTracking> BirthdayMessageTrackings { get; set; }
    public DbSet<BirthdayProcessing> BirthdayProcessings { get; set; }
    public DbSet<InfoMsg> InfoMsgs { get; set; }
    public DbSet<HappyIgnore> HappyIgnores { get; set; }
    public ApplicationContext() { }
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
      optionsBuilder.UseNpgsql(Config.ConnectPostgresSQL);
      AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);
    }
  }
}
