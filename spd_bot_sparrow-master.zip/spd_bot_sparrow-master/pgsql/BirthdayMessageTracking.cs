﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{

  /// <summary>
  /// класс для отсеживания отказов и согласий на поздравление
  /// </summary>
  [Table("birthdaymessagetracking")]
  public class BirthdayMessageTracking
  {
    [Column("id")]
    public int id { get; set; }
    [Column("iduser")]
    public int iduser { get; set; }
    [Column("idbirthdayman")]
    public int idbirthdayman { get; set; }
    [Column("message")]
    public string message { get; set; }
    [Column("inputdate")]
    public DateTime inputdate { get; set; }
    [Column("status")]
    public bool? status { get; set; }
  }
}