﻿using System.ComponentModel.DataAnnotations.Schema;

namespace spd_bot_sparrow
{
  [Table("happyignore")]
  public class HappyIgnore
  {
    [Column("id")]
    public int Id { get; set; }
    [Column("iduser")]
    public int Iduser { get; set; }
    [Column("needcongrat")]
    public bool NeedCongrat { get; set; }
    [Column("willcongrat")]
    public bool WillCongrat { get; set; }
  }
}
