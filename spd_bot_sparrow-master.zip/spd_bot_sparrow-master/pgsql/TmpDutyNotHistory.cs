﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace spd_bot_sparrow
{
  [Keyless]
  [Table("tmpdutynothistory")]
  public class TmpDutyNotHistory
  {
    [Column("date")]
    public DateTime date { get; set; }
    [Column("login")]
    public string login { get; set; }
    [Column("isintern")]
    public bool isIntern { get; set; }
  }
}
