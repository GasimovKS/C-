﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace spd_bot_sparrow
{
  [Table("absence")]
  public class Absence
    {
    [Column("id")]
    public int Id { get; set; }
    [Column("iduser")]
    public int Iduser { get; set; }
    [Column("date")]
    public DateTime Date { get; set; }
    [Column("type")]
    public string type { get; set; }
    }
}
