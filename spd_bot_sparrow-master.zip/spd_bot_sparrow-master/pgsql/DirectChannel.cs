﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace spd_bot_sparrow
{
  [Table("directchannel")]
  public class DirectChannel
  {
    [Column("id")]
    public int Id { get; set; }
    [Column("iduser")]
    public int Iduser { get; set; }
    [Column("idchannel")]
    public string Idchannel { get; set; }
  }
}
