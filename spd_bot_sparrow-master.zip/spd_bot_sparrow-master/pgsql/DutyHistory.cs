﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace spd_bot_sparrow
{
  [Table("dutyhistory")]
  public class DutyHistory
  {
    [Column("id")]
    public int Id { get; set; }
    [Column("iduser")]
    public int Iduser { get; set; }
    [Column("date")]
    public DateTime Date { get; set; }
  }
}
