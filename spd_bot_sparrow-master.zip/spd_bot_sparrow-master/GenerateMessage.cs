﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace spd_bot_sparrow
{
  internal class GenerateMessage
  {
    /// <summary>
    /// класс формирует график дежурств
    /// </summary>
    /// <param name="duty">кортеж списка дежурных</param>
    /// <param name="isRewriteSchedule">признак необходимости обновлени записи в графике</param>
    /// <returns></returns>
    public static string GenerateDutyMsg(List<Tuple<DateTime, string, string>> duty, bool isRewriteSchedule = false, bool isPreviously = false)
    {
      List<User> users;
      using (ApplicationContext db = new ApplicationContext())
      {
        users = db.Users.Where(x => x.Employee_SPD).ToList();
        //Рефакторинг
        //users = db.Users.FromSqlRaw("SELECT * FROM users where Employee_SPD is true").ToList();
      }
      List<string> intern = calculation.GenerateInternList(isRewriteSchedule, isPreviously);
      List<string> tmpDuty = calculation.GenerateTmpDutyList(isRewriteSchedule, isPreviously);
      DateTime firstDayOfDutyWeek = calculation.GetFirstDateOfNextWeek();
      string msg = "";
      //var dateList = calculation.NextWorkingWeek();
      //string insertQuery = "INSERT INTO dutyhistory (iduser, date) VALUES";
      List<DutyHistory> history = new List<DutyHistory>();
      List<DateTime> dateList = new List<DateTime>();
      foreach (var dutyItem in duty)
      {
        if (!dateList.Contains(dutyItem.Item1))
        {
          dateList.Add(dutyItem.Item1);
        }
      }
      dateList.Sort();
      DateTime firstDayOfWeek = calculation.GetFirstDateOfTargetWeek(dateList.Min());
      if (isRewriteSchedule)
      {
        DateTime endDateOfWeek = calculation.GetEndDateOfWeek();
        DateTime startDateOfWeek = calculation.GetFirstDateOfTargetWeek(endDateOfWeek);
        msg = string.Format("@here График дежурств с {0} по {1}\r\n",
            startDateOfWeek.ToString("d MMMM"), startDateOfWeek.AddDays(6).ToString("d MMMM"));
      }
      else
      {
        msg = string.Format("@here График дежурств с {0} по {1}\r\n",
            firstDayOfWeek.ToString("d MMMM"), firstDayOfWeek.AddDays(6).ToString("d MMMM"));
      }
      int index = 0;
      for (int i = 0; i < dateList.Count; i++)
      {
        string firstDuty = "", secondDuty = "";
        if (calculation.EternalDuty(dateList[i]))
        {
          history.Add(new DutyHistory
          {
            Iduser = users.Where(x => x.Login.ToLower().Equals(Config.EternalDuty.ToLower())).Select(x => x.Id).FirstOrDefault(),
            Date = dateList[i]
          });
          firstDuty = duty.Find(d => d.Item1 == dateList[i]).Item2;
          history.Add(new DutyHistory
          {
            Iduser = users.Where(x => x.Login.ToLower().Equals(duty.Find(d => d.Item1 == dateList[i]).Item2.ToLower())).Select(x => x.Id).FirstOrDefault(),
            Date = dateList[i]
          });
          //Рефакторинг
          /*
          insertQuery += $" ({users.Where(x => x.Login.ToLower().Equals(Config.EternalDuty.ToLower())).Select(x => x.Id).FirstOrDefault()}, '{dateList[i].ToString("dd.MM.yyyy")}'),";
          firstDuty = duty.Find(d => d.Item1 == dateList[i]).Item2;
          insertQuery += $" ({users.Where(x => x.Login.ToLower().Equals(duty.Find(d => d.Item1 == dateList[i]).Item2.ToLower())).Select(x => x.Id).FirstOrDefault()}, '{dateList[i].ToString("dd.MM.yyyy")}'),";
          */
        }
        else
        {
          firstDuty = duty.Find(d => d.Item1 == dateList[i]).Item2;
          secondDuty = duty.FindLast(d => d.Item1 == dateList[i]).Item2;
          history.Add(new DutyHistory
          {
            Iduser = users.Where(x => x.Login.ToLower().Equals(duty.Find(d => d.Item1 == dateList[i]).Item2.ToLower())).Select(x => x.Id).FirstOrDefault(),
            Date = dateList[i]
          });
          firstDuty = duty.Find(d => d.Item1 == dateList[i]).Item2;
          history.Add(new DutyHistory
          {
            Iduser = users.Where(x => x.Login.ToLower().Equals(duty.FindLast(d => d.Item1 == dateList[i]).Item2.ToLower())).Select(x => x.Id).FirstOrDefault(),
            Date = dateList[i]
          });
          //Рефакторинг
          /*
          firstDuty = duty.Find(d => d.Item1 == dateList[i]).Item2;
          secondDuty = duty.FindLast(d => d.Item1 == dateList[i]).Item2;
          insertQuery += $" ({users.Where(x => x.Login.ToLower().Equals(duty.Find(d => d.Item1 == dateList[i]).Item2.ToLower())).Select(x => x.Id).FirstOrDefault()}, '{dateList[i].ToString("dd.MM.yyyy")}'),";
          insertQuery += $" ({users.Where(x => x.Login.ToLower().Equals(duty.FindLast(d => d.Item1 == dateList[i]).Item2.ToLower())).Select(x => x.Id).FirstOrDefault()}, '{dateList[i].ToString("dd.MM.yyyy")}'),";
          */
        }
        switch (dateList[i].DayOfWeek.ToString())
        {
          case "Monday":
            {
              if (calculation.EternalDuty(dateList[i]))
              {
                msg += string.Format(
                    "ПН: @{0} - телефон / Directum Talk | @{1}{2} - дополнительный дежурный | {3}\r\n",
                    Config.EternalDuty, firstDuty, tmpDuty[index], intern[index]);
                index++;
              }
              else
              {
                msg += string.Format(
                    "ПН: @{0}, @{1} - телефон / Directum Talk {2} | {3}\r\n",
                    firstDuty, secondDuty, tmpDuty[index], intern[index]);
                index++;
              }
              break;
            }
          case "Tuesday":
            {
              if (calculation.EternalDuty(dateList[i]))
              {
                msg += string.Format(
                    "ВТ: @{0} - телефон / Directum Talk | @{1}{2} - дополнительный дежурный | {3}\r\n",
                    Config.EternalDuty, firstDuty, tmpDuty[index], intern[index]);
                index++;
              }
              else
              {
                msg += string.Format(
                    "ВТ: @{0}, @{1} - телефон / Directum Talk {2} | {3}\r\n",
                    firstDuty, secondDuty, tmpDuty[index], intern[index]);
                index++;
              }
              break;
            }
          case "Wednesday":
            {
              if (calculation.EternalDuty(dateList[i]))
              {
                msg += string.Format(
                    "СР: @{0} - телефон / Directum Talk | @{1}{2} - дополнительный дежурный | {3}\r\n",
                    Config.EternalDuty, firstDuty, tmpDuty[index], intern[index]);
                index++;
              }
              else
              {
                msg += string.Format(
                    "СР: @{0}, @{1} - телефон / Directum Talk {2} | {3}\r\n",
                    firstDuty, secondDuty, tmpDuty[index], intern[index]);
                index++;
              }
              break;
            }
          case "Thursday":
            {
              if (calculation.EternalDuty(dateList[i]))
              {
                msg += string.Format(
                    "ЧТ: @{0} - телефон / Directum Talk | @{1}{2} - дополнительный дежурный | {3}\r\n",
                    Config.EternalDuty, firstDuty, tmpDuty[index], intern[index]);
                index++;
              }
              else
              {
                msg += string.Format(
                    "ЧТ: @{0}, @{1} - телефон / Directum Talk {2} | {3}\r\n",
                    firstDuty, secondDuty, tmpDuty[index], intern[index]);
                index++;
              }
              break;
            }
          case "Friday":
            {
              if (calculation.EternalDuty(dateList[i]))
              {
                msg += string.Format(
                    "ПТ: @{0} - телефон / Directum Talk | @{1}{2} - дополнительный дежурный | {3}\r\n",
                    Config.EternalDuty, firstDuty, tmpDuty[index], intern[index]);
                index++;
              }
              else
              {
                msg += string.Format(
                    "ПТ: @{0}, @{1} - телефон / Directum Talk {2} | {3}\r\n",
                    firstDuty, secondDuty, tmpDuty[index], intern[index]);
                index++;
              }
              break;
            }
          case "Saturday":
            {
              if (calculation.EternalDuty(dateList[i]))
              {
                msg += string.Format(
                    "СБ: @{0} - телефон / Directum Talk | @{1}{2} - дополнительный дежурный | {3}\r\n",
                    Config.EternalDuty, firstDuty, tmpDuty[index], intern[index]);
                index++;
              }
              else
              {
                msg += string.Format(
                    "СБ: @{0}, @{1} - телефон / Directum Talk {2} | {3}\r\n",
                    firstDuty, secondDuty, tmpDuty[index], intern[index]);
                index++;
              }
              break;
            }
          case "Sunday":
            {
              if (calculation.EternalDuty(dateList[i]))
              {
                msg += string.Format(
                    "ВС: @{0} - телефон / Directum Talk | @{1}{2} - дополнительный дежурный | {3}\r\n",
                    Config.EternalDuty, firstDuty, tmpDuty[index], intern[index]);
                index++;
              }
              else
              {
                msg += string.Format(
                    "ВС: @{0}, @{1} - телефон / Directum Talk {2} | {3}\r\n",
                    firstDuty, secondDuty, tmpDuty[index], intern[index]);
                index++;
              }
              break;
            }
          default:
            break;
        }
      }
      msg +=
          "После утверждения текущего графика, замену ищите себе самостоятельно и уведомляете @Sparrow о желании поменяться.\r\n" +
          "Коллеги, не забывайте, пожалуйста, что у нас помимо служебного пользователя в ТехКас, есть еще задачи на служебного пользователя в Аура.\r\n" +
          "Список доступных команд можно узнать, выполнив команду **@sparrow !help**";

      if (!isRewriteSchedule)
      {
        using (ApplicationContext db = new ApplicationContext())
        {
          db.AddRange(history);
          db.SaveChanges();
          //Рефакторинг
          /*
          insertQuery = insertQuery.TrimEnd(',');
          db.Database.ExecuteSqlRaw(insertQuery);
          */
        }
      }
      return msg;
    }
  }
}
