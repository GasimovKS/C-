﻿using System.Configuration;
namespace spd_bot_sparrow
{
    internal class Config
    {
        //метод для загрузки конфига
        public static string ApiUrlPost { get { return ConfigurationManager.ConnectionStrings["apiUrlPost"].ConnectionString; } } //адрес для сообщений в каналы
        public static string ApiUrlChannel { get { return ConfigurationManager.ConnectionStrings["apiUrlChannels"].ConnectionString; } } //адрес для сообщений в каналы
        public static string ApiUrlMe { get { return ConfigurationManager.ConnectionStrings["apiUrlMe"].ConnectionString; } } //адрес для сообщений в каналы
        public static string ApiUrlUser { get { return ConfigurationManager.ConnectionStrings["apiUrlUser"].ConnectionString; } } //адрес для сообщений в каналы
        public static string ApiSearchUsersByName { get { return ConfigurationManager.ConnectionStrings["apiSearchUsersByName"].ConnectionString; } } //адрес для сообщений в каналы
        public static string ApiUrlReactions { get { return ConfigurationManager.ConnectionStrings["apiUrlReactions"].ConnectionString; } } //адрес для сообщений в каналы
        public static string ApiUrlDirectChannel { get { return ConfigurationManager.ConnectionStrings["apiUrlDirectChannel"].ConnectionString; } } //адрес для создания канала прямых сообщений
        public static string ApiUrlGroupChannel { get { return ConfigurationManager.ConnectionStrings["apiUrlGroupChannel"].ConnectionString; } } //адрес для создания канала прямых сообщений
        public static string ApiUrlUploadFile { get { return ConfigurationManager.ConnectionStrings["apiUrlUploadFile"].ConnectionString; } } //адрес для загрузки файлов
        public static string WebSock { get { return ConfigurationManager.ConnectionStrings["webSocket"].ConnectionString; } } //адрес для WebSocket
        public static string DutyChannalID { get { return ConfigurationManager.ConnectionStrings["dutyChannelID"].ConnectionString; } } // ID канала Дежурства
        public static string BotToken { get { return ConfigurationManager.ConnectionStrings["botToken"].ConnectionString; } } //Токен Bearer для бота Sparrow
        public static string BotID { get { return ConfigurationManager.ConnectionStrings["botID"].ConnectionString; } } //ID бота
        public static string ConnectPostgresSQL { get { return ConfigurationManager.ConnectionStrings["connectPostgresSQL"].ConnectionString; } } //строка подключения к БД
        public static string EternalDuty { get { return ConfigurationManager.ConnectionStrings["eternalDuty"].ConnectionString; } } //Вечный дежурный из конфига
        public static string DutysResponsible { get { return ConfigurationManager.ConnectionStrings["dutysResponsible"].ConnectionString; } } //Ответственный за поздравления в отделе
        public static string CongratulationsResponsible { get { return ConfigurationManager.ConnectionStrings["congratulationsResponsible"].ConnectionString; } } //Ответственный за поздравления в отделе
        public static string Aura { get { return ConfigurationManager.ConnectionStrings["aura"].ConnectionString; } } //Адрес сервисов интеграции ауры
        public static string AuraUser { get { return ConfigurationManager.ConnectionStrings["auraUser"].ConnectionString; } } //Логин служебного пользователя
        public static string AuraPass { get { return ConfigurationManager.ConnectionStrings["auraPassword"].ConnectionString; } } //Пароль служебного пользователя
        public static string Department { get { return ConfigurationManager.ConnectionStrings["department"].ConnectionString; } } //Наименование отдела
        public static string Supervisor { get { return ConfigurationManager.ConnectionStrings["supervisor"].ConnectionString; } } //Руководитель отдела
        public static bool ModuleAuraSync { get { return ConfigurationManager.AppSettings["moduleAuraSync"].ToLower().Equals("true"); } } //Модуль синхронизации    }
        public static bool ModuleDirectMessage { get { return ConfigurationManager.AppSettings["moduleDirectMessage"].ToLower().Equals("true"); } } //Модуль прямых сообщений }
        public static bool ModuleInterplay { get { return ConfigurationManager.AppSettings["moduleInterplay"].ToLower().Equals("true"); } } //Модуль тредов для канала}
        public static bool ModuleHappyBirthday { get { return ConfigurationManager.AppSettings["moduleHappyBirthday"].ToLower().Equals("true"); } } //Модуль поздравления с ДР}
        public static bool ModuleGenerateSchedule { get { return ConfigurationManager.AppSettings["moduleGenerateSchedule"].ToLower().Equals("true"); } } //Модуль генерации графика дежурств}
    }
}