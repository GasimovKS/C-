﻿using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Information;
using OfficeOpenXml.FormulaParsing.Excel.Functions.RefAndLookup;
using OfficeOpenXml.Style;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using static System.Net.WebRequestMethods;

namespace spd_bot_sparrow
{
  /// <summary>
  /// класс для формирования графика дежурств и отпусков в эксель файл для загрузки в ауру.
  /// </summary>
  internal class GenerateExcelFile
  {

    private static string exporSchedulePath { get { return @"ScheduleFile.xlsx"; } }
    private static string exporVacationPath { get { return @"VacationFile.xlsx"; } }
    private static string exporHappyBirthdayPath { get { return @"HappyBirthdayFile.xlsx"; } }
    /// <summary>
    /// Генерация графика дежурств в Excel-файл.
    /// </summary>
    /// <returns>Путь к файлу.</returns>
    internal static string GenerateSchedule()
    {
      Logger.WriteLog("Старт генерации файла с графиком дежурств");
      List<string> spdTeams = new List<string>();
      List<UsersList> spdEmployees = new List<UsersList>();
      DateTime firstDayCurrentYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
      DateTime startDayOfWeek = calculation.GetFirstDateOfTargetWeek(firstDayCurrentYear.AddDays(7));

      int indexOfColumn = 3;
      int lastColumn = 0;
      int indexOfRow = 2;
      int lastRow = 0;

      using (ApplicationContext db = new ApplicationContext())
      {
        //Получаем список действующих сотрудников отдела.
        var users = db.Users.Where(x => x.Employee_SPD).ToList();
        //Рефакторинг
        //var users = db.Users.FromSqlRaw("SELECT * FROM users where Employee_SPD is true").ToList();
        foreach (User u in users)
        {
          if (!spdTeams.Contains(u.Team))
          {
            spdTeams.Add(u.Team);
          }
          spdEmployees.Add(new UsersList(u.Login, 0, u.Team, u.Fio));
        }
      }
      spdTeams.Sort();

      using (ExcelPackage excelPackage = new ExcelPackage())
      {
        excelPackage.Workbook.Properties.Author = "Sparrow - spd bot";
        excelPackage.Workbook.Properties.Title = "График дежурств";
        excelPackage.Workbook.Properties.Subject = "Экспорт данных по дежурствам во внешние системы";
        excelPackage.Workbook.Properties.Created = DateTime.Now;
        //Создаем новый лист - график дежурств
        ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Дежурства");
        {
          int startMonthColumn = indexOfColumn;
          int index = indexOfColumn;
          int endMonthColumn = 0;
          for (DateTime tmpDate = firstDayCurrentYear; tmpDate < firstDayCurrentYear.AddYears(1); tmpDate = tmpDate.AddDays(1))
          {
            CreateBorder(worksheet, indexOfRow, index);
            CreateBorder(worksheet, indexOfRow + 1, index);
            worksheet.Column(index).Width = 3;
            worksheet.Cells[indexOfRow, index].Value = tmpDate.ToString("dd");
            worksheet.Cells[indexOfRow + 1, index].Value = tmpDate.ToString("ddd");
            if (tmpDate.Month != tmpDate.AddDays(1).Month)
            {
              endMonthColumn = index;
              worksheet.Cells[indexOfRow - 1, startMonthColumn].Value = tmpDate.ToString("MMMM");
              worksheet.Cells[indexOfRow - 1, startMonthColumn, indexOfRow - 1, endMonthColumn].Merge = true;
              CreateBorder(worksheet, indexOfRow - 1, startMonthColumn);
              startMonthColumn = index + 1;
            }
            index++;
          }
          lastColumn = index;
        }
        worksheet.Column(indexOfColumn - 2).Width = 25;
        worksheet.Column(indexOfColumn - 1).Width = 4;
        indexOfRow += 2;
        foreach (var team in spdTeams)
        {
          if (team == null)
          {
            worksheet.Cells[indexOfRow, 1].Value = "Вне команд";
          }
          else
          {
            worksheet.Cells[indexOfRow, 1].Value = team;
          }
          for (int i = 1; i < lastColumn; i++)
          {
            CreateBorder(worksheet, indexOfRow, i);
            worksheet.Cells[indexOfRow, i].Style.Fill.BackgroundColor.SetColor(Color.Orange);
          }
          indexOfRow++;
          foreach (var u in spdEmployees.Where(currentTeam => currentTeam.team == team).OrderBy(family => family.fio))
          {
            worksheet.Cells[indexOfRow, 1].Value = u.fio.Remove(u.fio.LastIndexOf(" "));
            CreateBorder(worksheet, indexOfRow, 1);
            List<DateTime> tmpStory = new List<DateTime>();
            startDayOfWeek = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
            using (ApplicationContext db = new ApplicationContext())
            {
              var usr = db.Users.Where(x => x.Login.ToLower().Equals(u.userLogin.ToLower())).FirstOrDefault();
              var history = db.DutyHistorys
                .Where(x => x.Iduser == usr.Id && x.Date >= startDayOfWeek && x.Date <= startDayOfWeek.AddYears(1).AddDays(-1)).ToList();
              //Рефакторинг
              //var history = db.DutyHistorys.FromSqlRaw("SELECT * FROM dutyhistory WHERE iduser = " +
              //    $"(select id from users where login ='" + u.userLogin +
              //    $"') and date between '{startDayOfWeek}' and '{startDayOfWeek.AddYears(1).AddDays(-1)}'").ToList();
              foreach (var h in history)
              {
                tmpStory.Add(h.Date);
              }
            }
            int i = indexOfColumn;
            while (startDayOfWeek < firstDayCurrentYear.AddYears(1))
            {
              int countDuty = tmpStory.Count(date => date == startDayOfWeek);
              if (tmpStory.Contains(startDayOfWeek))
              {
                worksheet.Cells[indexOfRow, i].Value = countDuty;
              }
              CreateBorder(worksheet, indexOfRow, i);
              startDayOfWeek = startDayOfWeek.AddDays(1);
              i++;
            }
            worksheet.Cells[indexOfRow, indexOfColumn - 1].FormulaR1C1 = $"=SUM(RC[1]:RC[365])";
            CreateBorder(worksheet, indexOfRow, indexOfColumn - 1);

            indexOfRow++;
          }
          indexOfRow++;
        }
        worksheet.DeleteRow(indexOfRow, indexOfRow, true);
        indexOfRow--;
        worksheet.DeleteRow(indexOfRow, indexOfRow, true);
        indexOfRow--;

        // Удалим файл если он есть уже
        if (!System.IO.File.Exists(exporSchedulePath))
        {
          System.IO.File.Delete(exporSchedulePath);
        }
        Thread.Sleep(5000);
        //сохраняем в эксельку
        FileInfo exporSchedule = new FileInfo(exporSchedulePath);
        excelPackage.SaveAs(exporSchedule);
      }
      Logger.WriteLog("Генерация файла с графиком дежурств завершена успешно");
      return exporSchedulePath;
    }

    /// <summary>
    /// Формирование бордюров ячейки.
    /// </summary>
    /// <param name="worksheet">Страница Excel-файла.</param>
    /// <param name="row">Номер строки.</param>
    /// <param name="column">Номер колонки.</param>
    /// <param name="needBackground">Необходимость подкрашивания ячейки.</param>
    private static void CreateBorder(ExcelWorksheet worksheet, int row, int column, bool needBackground = true)
    {
      worksheet.Cells[row, column].Style.Fill.PatternType = ExcelFillStyle.Solid;
      if (needBackground)
      {
        worksheet.Cells[row, column].Style.Fill.BackgroundColor.SetColor(Color.White);
      }
      worksheet.Cells[row, column].Style.Border.Top.Style = ExcelBorderStyle.Thin;
      worksheet.Cells[row, column].Style.Border.Left.Style = ExcelBorderStyle.Thin;
      worksheet.Cells[row, column].Style.Border.Right.Style = ExcelBorderStyle.Thin;
      worksheet.Cells[row, column].Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
    }

    /// <summary>
    /// Генерация графика отпусков.
    /// </summary>
    /// <returns>Путь к файлу.</returns>
    internal static string GenerateVacation()
    {
      Logger.WriteLog("Старт генерации файла с графиком отпусков");
      List<string> spdTeams = new List<string>();
      List<UsersList> spdEmployees = new List<UsersList>();
      DateTime firstDayCurrentYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
      DateTime startDayOfWeek = calculation.GetFirstDateOfTargetWeek(firstDayCurrentYear.AddDays(7));

      using (ApplicationContext db = new ApplicationContext())
      {
        //Получаем список действующих сотрудников отдела.
        var users = db.Users.Where(x => x.Employee_SPD).ToList();
        //Рефакторинг
        //var users = db.Users.FromSqlRaw("SELECT * FROM users where Employee_SPD is true").ToList();

        foreach (User u in users)
        {

          if (!spdTeams.Contains(u.Team))
          {
            spdTeams.Add(u.Team);
          }
          spdEmployees.Add(new UsersList(u.Login, 0, u.Team, u.Fio));
        }
      }
      spdTeams.Sort();

      int indexOfColumn = 2;
      int indexOfRow = 2;
      int lastColumn = 0;
      int lastRow = 0;
      startDayOfWeek = calculation.GetFirstDateOfTargetWeek(firstDayCurrentYear.AddDays(7));
      using (ExcelPackage excelPackage = new ExcelPackage())
      {
        //Set some properties of the Excel document
        excelPackage.Workbook.Properties.Author = "Sparrow - spd bot";
        excelPackage.Workbook.Properties.Title = "График отпусков в отделе";
        excelPackage.Workbook.Properties.Subject = "Экспорт данных по отпускам во внешние системы";
        excelPackage.Workbook.Properties.Created = DateTime.Now;
        //Создаем новый лист - график дежурств
        ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Отпуска");
        {
          worksheet.Column(indexOfColumn - 1).Width = 25;
          worksheet.Cells[indexOfRow, indexOfColumn - 1].Value = "Фамилия имя";
          CreateBorder(worksheet, indexOfRow, indexOfColumn);
          while (startDayOfWeek < firstDayCurrentYear.AddYears(1))
          {
            CreateBorder(worksheet, indexOfRow, indexOfColumn);
            switch (startDayOfWeek.Month)
            {
              case 4:
                worksheet.Cells[indexOfRow, indexOfColumn].Style.Fill.BackgroundColor.SetColor(Color.Red);
                break;
              case 5:
                worksheet.Cells[indexOfRow, indexOfColumn].Style.Fill.BackgroundColor.SetColor(Color.Yellow);
                break;
              case 7:
                worksheet.Cells[indexOfRow, indexOfColumn].Style.Fill.BackgroundColor.SetColor(Color.Yellow);
                break;
              case 8:
                worksheet.Cells[indexOfRow, indexOfColumn].Style.Fill.BackgroundColor.SetColor(Color.Yellow);
                break;
              case 10:
                worksheet.Cells[indexOfRow, indexOfColumn].Style.Fill.BackgroundColor.SetColor(Color.Red);
                break;
              case 11:
                worksheet.Cells[indexOfRow, indexOfColumn].Style.Fill.BackgroundColor.SetColor(Color.Red);
                break;
              case 12:
                worksheet.Cells[indexOfRow, indexOfColumn].Style.Fill.BackgroundColor.SetColor(Color.Red);
                break;
              default:
                worksheet.Cells[indexOfRow, indexOfColumn].Style.Fill.BackgroundColor.SetColor(Color.Green);
                break;

            }
            worksheet.Column(indexOfColumn).Width = 3;
            worksheet.Cells[indexOfRow, indexOfColumn].Style.TextRotation = 90;
            worksheet.Cells[indexOfRow, indexOfColumn].Value = startDayOfWeek.ToString("dd MMMM");
            startDayOfWeek = startDayOfWeek.AddDays(7);
            indexOfColumn++;
          }
          lastColumn = indexOfColumn;

          indexOfColumn = 1;
          indexOfRow += 2;
          foreach (var team in spdTeams)
          {
            if (team == null)
            {
              worksheet.Cells[indexOfRow, indexOfColumn].Value = "Вне команд";
            }
            else
            {
              worksheet.Cells[indexOfRow, indexOfColumn].Value = team;
            }
            for (int i = indexOfColumn; i < lastColumn; i++)
            {
              CreateBorder(worksheet, indexOfRow, i);
              worksheet.Cells[indexOfRow, i].Style.Fill.BackgroundColor.SetColor(Color.Orange);
            }
            indexOfRow++;
            foreach (var u in spdEmployees.Where(currentTeam => currentTeam.team == team).OrderBy(family => family.fio))
            {
              worksheet.Cells[indexOfRow, indexOfColumn].Value = u.fio.Remove(u.fio.LastIndexOf(" "));
              CreateBorder(worksheet, indexOfRow, indexOfColumn);
              List<DateTime> tmpHolidays = new List<DateTime>();
              using (ApplicationContext db = new ApplicationContext())
              {
                //сотрудник.
                var usr = db.Users.Where(x => x.Login.ToLower().Equals(u.userLogin.ToLower())).FirstOrDefault();
                //список отпусков.
                var absences = db.Absences
                  .Where(x => x.Iduser == usr.Id && x.type.ToLower().Equals("holiday")).ToList();
                //Рефакторинг
                //список отпусков
                //var absences = db.Absences.FromSqlRaw("SELECT * FROM absence WHERE type ILIKE 'holiday' and iduser = " +
                //    "(select id from users where login ='" + u.userLogin + "')").ToList();

                foreach (var a in absences)
                {
                  tmpHolidays.Add(a.Date);
                }
              }

              startDayOfWeek = calculation.GetFirstDateOfTargetWeek(firstDayCurrentYear.AddDays(7));
              int i = indexOfColumn + 1;
              while (startDayOfWeek < firstDayCurrentYear.AddYears(1))
              {
                int counter = 0;
                foreach (var tmpHoliday in tmpHolidays)
                {
                  if ((tmpHoliday >= startDayOfWeek) && (tmpHoliday < startDayOfWeek.AddDays(7)))
                    counter++;
                }
                if (counter != 0)
                {
                  worksheet.Cells[indexOfRow, i].Value = counter;
                }
                CreateBorder(worksheet, indexOfRow, i);
                startDayOfWeek = startDayOfWeek.AddDays(7);
                i++;
              }
              worksheet.Cells[indexOfRow, i].FormulaR1C1 = $"=SUM(RC[-52]:RC[-1])";

              indexOfRow++;
            }
            indexOfRow++;
          }
          worksheet.DeleteRow(indexOfRow, indexOfRow, true);
          indexOfRow--;
          worksheet.DeleteRow(indexOfRow, indexOfRow, true);
          indexOfRow--;
          lastRow = indexOfRow;
          indexOfRow = 3;
          for (indexOfColumn = 2; indexOfColumn < lastColumn; indexOfColumn++)
          {
            worksheet.Cells[indexOfRow, indexOfColumn].FormulaR1C1 = $"=SUM(R[2]C:R[{lastRow - indexOfRow}]C)";
          }
        }
        // Удалим файл если он есть уже
        if (!System.IO.File.Exists(exporVacationPath))
        {
          System.IO.File.Delete(exporVacationPath);
        }
        Thread.Sleep(5000);
        //сохраняем в эксельку
        FileInfo exporVacation = new FileInfo(exporVacationPath);
        excelPackage.SaveAs(exporVacation);
      }
      Logger.WriteLog("Генерация файла с графиком отпусков завершена успешно");
      return exporVacationPath;
    }

    /// <summary>
    /// График поздравлений с днём рождения и ответственных.
    /// </summary>
    /// <returns>Путь к файлу.</returns>
    internal static string GenerateHappy()
    {
      Console.WriteLine($"{DateTime.Now}: Старт генерации файла с графиком поздравлений");
      Logger.WriteLog("Старт генерации файла с графиком поздравлений");
      List<User> spdEmployees;
      List<BirthdayMessageTracking> history;
      List<BirthdayProcessing> processing;
      Dictionary<int, DateTime> tmpUsr = new Dictionary<int, DateTime>();
      List<int> colunmUsers = new List<int>();
      DateTime startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
      DateTime endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31); ;
      int indexOfColumn = 4;
      int lastColumn = 0;
      int indexOfRow = 2;
      int lastRow = 0;
      using (ApplicationContext db = new ApplicationContext())
      {
        spdEmployees = db.Users.ToList();
        history = db.BirthdayMessageTrackings
          .Where(x => x.inputdate >= startYear && x.inputdate <= endYear).ToList();
        processing = db.BirthdayProcessings
          .Where(x => x.birthday >= startYear && x.birthday <= endYear).ToList();
        //Рефакторинг
        /*
        spdEmployees = db.Users.FromSqlRaw("SELECT * FROM users").ToList();
        history = db.BirthdayMessageTrackings
          .FromSqlRaw($"SELECT * FROM birthdaymessagetracking where inputdate between '{startYear}' and '{endYear}'").ToList();
        processing = db.BirthdayProcessings
          .FromSqlRaw($"SELECT * FROM birthdayprocessing where birthday between '{startYear}' and '{endYear}'").ToList();
        */
      }
      //преобразуем в дату без времени
      foreach (BirthdayMessageTracking d in history)
      {
        d.inputdate = new DateTime(int.Parse(d.inputdate.ToString("yyyy")),
            int.Parse(d.inputdate.ToString("MM")), int.Parse(d.inputdate.ToString("dd")));
      }
      //преобразуем дни рождения в текущий год
      foreach (var u in spdEmployees)
      {
        tmpUsr.Add(u.Id, u.Date_of_birth);
        u.Date_of_birth = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")),
            int.Parse(u.Date_of_birth.ToString("MM")), int.Parse(u.Date_of_birth.ToString("dd")));//преобразуем в ДР текущего года
      }
      spdEmployees = spdEmployees.OrderBy(x => x.Date_of_birth).ToList();
      using (ExcelPackage excelPackage = new ExcelPackage())
      {
        excelPackage.Workbook.Properties.Author = "Sparrow - spd bot";
        excelPackage.Workbook.Properties.Title = "График поздравлений";
        excelPackage.Workbook.Properties.Subject = "Экспорт данных по поздравлениям во внешние системы";
        excelPackage.Workbook.Properties.Created = DateTime.Now;
        //Создаем новый лист - график дежурств
        ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Поздравления коллег");
        worksheet.Cells[indexOfRow + 1, 1].Value = "ФИ поздравляющего";
        CreateBorder(worksheet, indexOfRow + 1, 1);
        worksheet.Cells[indexOfRow + 1, 2].Value = "Согласия";
        CreateBorder(worksheet, indexOfRow + 1, 2);
        worksheet.Cells[indexOfRow + 1, 3].Value = "Отказы";
        CreateBorder(worksheet, indexOfRow + 1, 3);
        int index = indexOfColumn;

        //заполняем столбцы в графике
        foreach (var u in spdEmployees.Where(x => x.Employee_SPD == true))
        {
          colunmUsers.Add(u.Id);
          CreateBorder(worksheet, indexOfRow, index);
          CreateBorder(worksheet, indexOfRow + 1, index);
          worksheet.Column(index).Width = 21;
          worksheet.Cells[indexOfRow, index].Value = u.Fio.Remove(u.Fio.LastIndexOf(" "));
          worksheet.Cells[indexOfRow + 1, index].Value = tmpUsr.Where(user => user.Key == u.Id)
              .Select(user => user.Value).FirstOrDefault().ToString("dd.MM.yyyy");
          worksheet.Cells[indexOfRow, index].Style.Fill.PatternType = ExcelFillStyle.Solid;
          worksheet.Cells[indexOfRow, index].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
          worksheet.Cells[indexOfRow, index].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
          worksheet.Cells[indexOfRow + 1, index].Style.Fill.PatternType = ExcelFillStyle.Solid;
          worksheet.Cells[indexOfRow + 1, index].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
          worksheet.Cells[indexOfRow + 1, index].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
          index++;
        }
        lastColumn = index;
        worksheet.Column(indexOfColumn - 3).Width = 25;
        worksheet.Column(indexOfColumn - 2).Width = 9;
        worksheet.Column(indexOfColumn - 1).Width = 9;
        indexOfRow += 2;
        foreach (var u in spdEmployees.OrderBy(family => family.Fio))
        {
          for (int i = 4; i < lastColumn; i++)
          {
            CreateBorder(worksheet, indexOfRow, i, false);
          }
          if (!u.Employee_SPD && (processing.Where(x => x.iduser == u.IdAura).Count() == 0))
          {
            continue;
          }
          int targerColumn = indexOfColumn;
          int agreeCase = processing.Where(x => x.iduser == u.IdAura).Count();
          int ignoreCase = history.Where(x => x.status == false && x.iduser == u.Id).Count();
          worksheet.Cells[indexOfRow, indexOfColumn - 2].Value = agreeCase;
          CreateBorder(worksheet, indexOfRow, 2);
          worksheet.Cells[indexOfRow, indexOfColumn - 2].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
          worksheet.Cells[indexOfRow, indexOfColumn - 1].Value = ignoreCase;
          CreateBorder(worksheet, indexOfRow, 1);
          worksheet.Cells[indexOfRow, indexOfColumn - 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
          worksheet.Cells[indexOfRow, 1].Value = u.Fio.Remove(u.Fio.LastIndexOf(" "));
          if (!u.Employee_SPD)
          {
            worksheet.Cells[indexOfRow, 1].Style.Font.Color.SetColor(Color.Gray); //ставим цвет текста
          }
          CreateBorder(worksheet, indexOfRow, indexOfColumn - 1);
          int tableSumm = 0;
          foreach (var id in colunmUsers)
          {
            CreateBorder(worksheet, indexOfRow, targerColumn);
            if (id == u.Id)
            {
              worksheet.Cells[indexOfRow, targerColumn].Value = "X";
              worksheet.Cells[indexOfRow, targerColumn].Style.Fill.PatternType = ExcelFillStyle.Solid;
              worksheet.Cells[indexOfRow, targerColumn].Style.Fill.BackgroundColor.SetColor(Color.LightBlue);
              worksheet.Cells[indexOfRow, targerColumn].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            }
            if (history.Where(x => x.idbirthdayman == id && x.iduser == u.Id).Select(x => x.status).FirstOrDefault() == false)
            {
              worksheet.Cells[indexOfRow, targerColumn].Value = "Отказ";
              worksheet.Cells[indexOfRow, targerColumn].Style.Fill.PatternType = ExcelFillStyle.Solid;
              worksheet.Cells[indexOfRow, targerColumn].Style.Fill.BackgroundColor.SetColor(Color.Red);
              worksheet.Cells[indexOfRow, targerColumn].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            }
            if (processing.Where(x => x.idbirthdayman == id && x.iduser == u.IdAura).Count() > 0)
            {
              string tmpFact = "Поздравляет";
              if (DateTime.Now > processing.Where(x => x.idbirthdayman == id && x.iduser == u.IdAura).Select(x => x.birthday).FirstOrDefault())
              {
                tmpFact = "Поздравил";
              }
              tableSumm++;
              worksheet.Cells[indexOfRow, targerColumn].Value = tmpFact;
              worksheet.Cells[indexOfRow, targerColumn].Style.Fill.PatternType = ExcelFillStyle.Solid;
              worksheet.Cells[indexOfRow, targerColumn].Style.Fill.BackgroundColor.SetColor(Color.LightGreen);
              worksheet.Cells[indexOfRow, targerColumn].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            }
            targerColumn++;
          }
          if (targerColumn != lastColumn)
          {
            for (int i = targerColumn; i < lastColumn; i++)
            {
              CreateBorder(worksheet, indexOfRow, i);
            }
          }
          //смотрим, кто есть ли уволенные, которых поздравляли
          if (tableSumm != processing.Where(x => x.iduser == u.IdAura).Count())
          {
            List<BirthdayProcessing> dismissedUsers = processing.Where(x => x.iduser == u.IdAura
            && spdEmployees.Where(x => x.Employee_SPD == false).Select(x => x.Id).ToList().Contains(x.idbirthdayman))
                .ToList();
            foreach (var dis in dismissedUsers)
            {
              CreateBorder(worksheet, 2, lastColumn);
              CreateBorder(worksheet, 3, lastColumn);
              worksheet.Column(lastColumn).Width = 21;
              string dismissedUserFio = spdEmployees.Where(x => x.Id == dis.idbirthdayman)
                  .Select(x => x.Fio).FirstOrDefault();
              DateTime dismissedUserDate = tmpUsr.Where(x => x.Key == dis.idbirthdayman).Select(x => x.Value).FirstOrDefault();
              worksheet.Cells[2, lastColumn].Value = dismissedUserFio.Remove(dismissedUserFio.LastIndexOf(" "));
              worksheet.Cells[3, lastColumn].Value = dismissedUserDate.ToString("dd.MM.yyyy");
              worksheet.Cells[2, lastColumn].Style.Fill.PatternType = ExcelFillStyle.Solid;
              worksheet.Cells[2, lastColumn].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
              worksheet.Cells[2, lastColumn].Style.Font.Color.SetColor(Color.Gray); //ставим цвет текста
              worksheet.Cells[2, lastColumn].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
              worksheet.Cells[3, lastColumn].Style.Fill.PatternType = ExcelFillStyle.Solid;
              worksheet.Cells[3, lastColumn].Style.Fill.BackgroundColor.SetColor(Color.LightGray);
              worksheet.Cells[3, lastColumn].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
              for (int i = 4; i <= spdEmployees.Where(x => x.Employee_SPD == true).Count() + 3; i++)
              {
                CreateBorder(worksheet, i, lastColumn);
              }
              worksheet.Cells[indexOfRow, lastColumn].Value = "Поздравил";
              worksheet.Cells[indexOfRow, lastColumn].Style.Fill.PatternType = ExcelFillStyle.Solid;
              worksheet.Cells[indexOfRow, lastColumn].Style.Fill.BackgroundColor.SetColor(Color.LightGreen);
              worksheet.Cells[indexOfRow, lastColumn].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
              lastColumn++;
            }
          }

          indexOfRow++;
        }

        worksheet.DeleteRow(indexOfRow, indexOfRow, true);
        indexOfRow--;

        // Удалим файл если он есть уже
        if (!System.IO.File.Exists(exporSchedulePath))
        {
          System.IO.File.Delete(exporSchedulePath);
        }
        Thread.Sleep(5000);
        //сохраняем в эксельку
        FileInfo exporHappy = new FileInfo(exporHappyBirthdayPath);
        excelPackage.SaveAs(exporHappy);
      }
      Console.WriteLine($"{DateTime.Now}: Генерация файла с графиком поздравлений завершена успешно");
      Logger.WriteLog("Генерация файла с графиком поздравлений завершена успешно");
      return exporHappyBirthdayPath;
    }
  }
}
