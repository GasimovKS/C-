﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{

  /// <summary>
  /// Расширение типа данных STRING для генерации текста в формате JSON формата
  /// </summary>
  public static class Extensions
  {
    public static StringContent AsJson(this object o)
        => new StringContent(JsonConvert.SerializeObject(o), Encoding.UTF8, "application/json");
  }
  internal class ToMattermost
  {
    private static string BotID { get { return Config.BotID; } }
    /// <summary>
    /// Получить ID бота.
    /// </summary>
    /// <param name="uri">Адрес API MM для получения информации.</param>
    /// <param name="data">Тело сообщения.</param>
    /// <returns></returns>
    public static async Task<string> GetBotId(string uri = null, object data = null)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      dynamic json;
      try
      {
        json = JObject.Parse((await client.GetStringAsync(Config.ApiUrlMe)).ToString());
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost");
        Logger.WriteLog($"Текст ошибки:\r\n{ex}");
        Logger.WriteLog($"{DateTime.Now}: Обращение к API завершилось c ошибкой.");
        return "ошибка";
      }
      return json["id"];
    }

    /// <summary>
    /// Получить логин пользователя в ММ.
    /// </summary>
    /// <param name="userID">ID пользователя ММ</param>
    /// <returns>Логин пользователя.</returns>
    public static async Task<string> GetUserNameByID(string userID)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      dynamic json;
      try
      {
        json = JObject.Parse((await client.GetStringAsync(Config.ApiUrlUser + userID)).ToString());
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost");
        Logger.WriteLog($"Текст ошибки:\r\n{ex}");
        Logger.WriteLog($"Обращение к API завершилось c ошибкой.");
        return "ошибка";
      }
      return json["username"];
    }

    /// <summary>
    /// Запинить сообщение бота.
    /// </summary>
    /// <param name="botID">ID бота</param>
    /// <returns>ID запинненого сообщения.</returns>
    public async static Task<string> PinnedMessage(string botID)
    {
      return (await PinOnlyLastBotPosts(botID)).ToString();
    }

    /// <summary>
    /// Отправка сообщения в канал.
    /// </summary>
    /// <param name="uri">Адрес канала, куда отправляем сообщение</param>
    /// <param name="botID">ID бота</param>
    /// <param name="data">Данные в формате OBJECT, по умолчанию в переменной NULL.</param>
    /// <param name="isNeedPinned">Надо ли запиннить отправляемое сообщение.</param>
    /// <returns>ID отправленного сообщения.</returns>
    public async static Task<string> PostMsgAsync(string uri, string botID, object data = null, bool isNeedPinned = true)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      var res = await client.PostAsync(uri, data.AsJson());
      dynamic json = JObject.Parse((await res.Content.ReadAsStringAsync()).ToString());
      if (isNeedPinned)
      {
        uri += "/" + json["id"] + "/pin";
        await client.PostAsync(uri, data.AsJson());
        client.DefaultRequestHeaders.Accept.Clear();
        return await PinnedMessage(botID);
      }
      else
      {
        return json["id"];
      }
    }

    /// <summary>
    /// Запиннить крайнее сообщение, отправленное ботом, ВСЕ остальные сообщения, в том числе и пользователей будут откреплены в данном канале.
    /// </summary>
    /// <param name="botID">ID бота.</param>
    /// <param name="uri">Адрес канала, где необходимо закрепить сообщение.</param>
    /// <param name="data">данные в формате OBJECT, по умолчанию в переменной NULL, желательно ничего не передавать на вход, т.к. RESTapi mattermost ждет тело сообщения.</param>
    /// <returns>ID запинненного сообщения.</returns>
    private static async Task<string> PinOnlyLastBotPosts(string botID, string uri = null, object data = null)
    {
      Int64 tmpCreateDate = 0;
      List<string> idMsg = new List<string>();
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      uri = Config.ApiUrlChannel + "/" + Config.DutyChannalID + "/posts";
      uri += "?since=" + DateTimeOffset.Now.AddDays(-20).ToUnixTimeMilliseconds();
      string top = FindLastBotMessage(uri, botID).Result;
      await Task.Delay(100);
      uri = Config.ApiUrlPost + "/" + top + "/pin";
      await client.PostAsync(uri, data.AsJson());
      await Task.Delay(100);
      uri = Config.ApiUrlChannel + "/" + Config.DutyChannalID + "/pinned";
      dynamic json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
      foreach (dynamic object1 in json.order)
      {
        idMsg.Add(object1.ToString());
      }
      foreach (var id in idMsg)
      {
        uri = Config.ApiUrlPost + "/" + id;
        try
        {
          json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
          await Task.Delay(100);
        }
        catch
        {
          await Task.Delay(100);
          continue;
        }

        if (json["user_id"] == botID && json["root_id"] == "") //добавил условие, что это собщение не является сообщение в тред
        {
          if (tmpCreateDate < (Int64)json["create_at"])
          {
            tmpCreateDate = (Int64)json["create_at"];
            top = id;
          }
        }
        await Task.Delay(100);
      }
      foreach (var id in idMsg)
      {
        if (id != top)
        {
          uri = Config.ApiUrlPost + "/" + id + "/unpin";
          await PostMsgAsync(uri, null, false); ;
        }
        await Task.Delay(100);
      }
      client.DefaultRequestHeaders.Accept.Clear();
      return top;
    }

    /// <summary>
    /// Получение крайнего (закрепренного) сообщения бота в канале для дальнейшего редактирования (либо парсинга в историю).
    /// </summary>
    /// <param name="uri">Адрес канала, где необходимо получить сообщение.</param>
    /// <param name="data">Данные в формате OBJECT, по умолчанию в переменной NULL, желательно ничего не передавать на вход, т.к. RESTapi mattermost ждет тело сообщения.</param>
    /// <returns>Возвращает текст сообщения</returns>
    public static async Task<string> GetMessage(string uri, object data = null)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      dynamic json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
      return json["message"];
    }

    /// <summary>
    /// Получить время отправки указанного сообщения.
    /// </summary>
    /// <param name="uri">Адрес канала, где необходимо получить сообщение.</param>
    /// <param name="userID">ID пользователя.</param>
    /// <param name="data">Данные в формате OBJECT, по умолчанию в переменной NULL, желательно ничего не передавать на вход, т.к. RESTapi mattermost ждет тело сообщения.</param>
    /// <returns>Время сообщения.</returns>
    public static async Task<Int64> GetMessageTime(string uri = null, string userID = null, object data = null)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      dynamic json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
      Int64 time = json["create_at"];
      return time;
    }

    /// <summary>
    /// Поиск крайнего сообщения бота.
    /// </summary>
    /// <param name="uri">Адрес канала, где необходимо получить сообщение.</param>
    /// <param name="userID">ID пользователя.</param>
    /// <param name="data">Данные в формате OBJECT, по умолчанию в переменной NULL, желательно ничего не передавать на вход, т.к. RESTapi mattermost ждет тело сообщения.</param>
    /// <returns>ID крайнего сообщения.</returns>
    public static async Task<string> FindLastBotMessage(string uri = null, string userID = null, object data = null)
    {
      List<string> idMsg = new List<string>();
      string idLastDutyMsg = "";
      string tmpMsg = "";
      long tmpCreateDate = 0;
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      dynamic json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
      foreach (dynamic obj in json.order)
      {
        idMsg.Add(obj.ToString());
      }
      foreach (var id in idMsg)
      {
        uri = Config.ApiUrlPost + "/" + id;
        try
        {
          json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
          await Task.Delay(200);
        }
        catch (Exception ex)
        {
          await Task.Delay(200);
          continue;
        }
        tmpMsg = json["message"];
        if ((json["user_id"] == userID) && (json["delete_at"] == 0) && (json["message"].ToString().Contains("@here График дежурств")))
        {
          if (tmpCreateDate < (long)json["create_at"])
          {
            tmpCreateDate = (long)json["create_at"];
            idLastDutyMsg = id;
          }
        }
        await Task.Delay(500);
      }
      return idLastDutyMsg;
    }

    /// <summary>
    /// Ответ автору сообщения с текстом ошибки
    /// </summary>
    /// <param name="targetMessageID">ID сообщения графиком дежурств.</param>
    /// <param name="authorMsg">Автор сообщения, которому отвечаем.</param>
    /// <param name="ErrMsg">Текст ошибки.</param>
    /// <param name="botID">ID бота.</param>
    /// <returns>Ничего не возвращает, хотя может.</returns>
    public static async Task ErrorMsgReplace(string targetMessageID, string authorMsg, string ErrMsg, string botID)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      var data = new
      {
        channel_id = Config.DutyChannalID,
        message = "@" + authorMsg + " @" + ErrMsg,
        root_id = targetMessageID
      };
      try
      {
        await PostMsgAsync(Config.ApiUrlPost, botID, data, false);
        await Task.Delay(100);
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost" +
        $"Текст ошибки:\r\n{ex}\r\nОбращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return;
      }
      Logger.WriteLog($"@{authorMsg} {ErrMsg}");
      Console.WriteLine("@" + authorMsg + " " + ErrMsg);
    }

    /// <summary>
    /// Запостить информационное сообщение в канале дежурств.
    /// </summary>
    /// <param name="msg">Текст информационного сообщения.</param>
    /// <param name="botID">ID бота.</param>
    /// <returns>Ничего не возвращает, хотя может.</returns>
    public static async Task PutInfoMessage(string msg, string botID)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      var data = new
      {
        channel_id = Config.DutyChannalID,
        message = msg,
      };
      try
      {
        await PostMsgAsync(Config.ApiUrlPost, botID, data, false);
        await Task.Delay(100);
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost\r" +
        $"Текст ошибки:\r{ex}\rОбращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return;
      }
    }

    /// <summary>
    /// Поставить реакцию на сообщение.
    /// </summary>
    /// <param name="msgID">ID сообщения, на которое ставится реакция.</param>
    /// <param name="reactions">Реакция.</param>
    /// <param name="botID">ID бота.</param>
    /// <returns></returns>
    public static async Task PutReactionPost(string msgID, string reactions, string botID)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      var data = new
      {
        user_id = botID,
        post_id = msgID,
        emoji_name = reactions
      };
      try
      {
        client.PostAsync(Config.ApiUrlReactions, data.AsJson());
        await Task.Delay(100);
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost" +
            $"Текст ошибки:\r\n{ex}\r\nОбращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return;
      }
    }
    /// <summary>
    /// Удаление реакции с сообщения.
    /// </summary>
    /// <param name="msgID">id сообщения, с которого удаляется реакция.</param>
    /// <param name="reactions">Реакция.</param>
    /// <returns></returns>
    public static async Task RemoveReactionPost(string msgID, string reactions)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      string uri = Config.ApiUrlUser + BotID + "/posts/" + msgID + "/reactions/" + reactions;
      try
      {
        client.DeleteAsync(uri);
        await Task.Delay(100);
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost" +
            $"Текст ошибки:\r\n{ex}\r\nОбращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return;
      }
    }

    /// <summary>
    /// Редактирование сообщения.
    /// </summary>
    /// <param name="uri">Адрес редактируемого сообщения.</param>
    /// <param name="data">Данные в формате OBJECT, по умолчанию в переменной NULL</param>
    /// <returns>Ничего не возвращает, хотя может.</returns>
    public async static Task PutMsgAsync(string uri, object data = null)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      try
      {
        var response = await client.PutAsync(uri, data.AsJson());
        await Task.Delay(100);
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost\r" +
            $"Текст ошибки:\r\n{ex}\rОбращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return;
      }
    }

    /// <summary>
    /// Создать канал прямыхх сообщений с ботом.
    /// </summary>
    /// <param name="data">Данные в формате OBJECT, по умолчанию в переменной NULL</param>
    /// <returns>Возвращает ID канала сообщения бота и пользователя.</returns>
    public static async Task<string> GetDirectMessageChannel(object data = null)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      dynamic json;
      try
      {
        json = JObject.Parse((await client.PostAsync(Config.ApiUrlDirectChannel, data.AsJson())).ToString());
        await Task.Delay(100);
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost\r" +
            $"Текст ошибки:\r\n{ex}\rОбращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return "";
      }
      return json["id"];
    }

    /// <summary>
    /// Сообщения в канал прямых диалогов с ботом.
    /// </summary>
    /// <param name="channel">ID канала.</param>
    /// <param name="Msg">Текст сообщения</param>
    /// <param name="botID">ID бота.</param>
    /// <returns></returns>
    public static async Task MsgToDirectChannel(string channel, string Msg, string botID)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      var data = new
      {
        channel_id = channel,
        message = Msg
      };
      try
      {
        await PostMsgAsync(Config.ApiUrlPost, botID, data, false);
        await Task.Delay(100);
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost" +
            $"Текст ошибки:\r{ex}\rОбращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return;
      }
    }
    /// <summary>
    /// Загрузка файла на сервер маттермоста.
    /// </summary>
    /// <param name="fileName">Путь к файлу.</param>
    /// <param name="channelID">Id канала прямых сообщений пользователя, от которого пришел запрос на файл.</param>
    /// <returns>ID загруженного файла.</returns>
    public static async Task<string> UploadScheduleFile(string fileName, string channelID)
    {
      fileInfo returnUploadInfo;
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("multipart/form-data"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      string uri = Config.ApiUrlUploadFile + "?channel_id=" + channelID + "&filename=" + fileName;
      try
      {
        Thread.Sleep(5000);
        using var fileSteam = System.IO.File.Open(fileName, FileMode.Open);
        using var content = new StreamContent(fileSteam);
        returnUploadInfo = JObject.Parse((await client.PostAsync(uri, content)).Content.ReadAsStringAsync().Result).ToObject<fileInfo>();
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost" +
            $"Текст ошибки:\r{ex}\rОбращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return "";
      }
      return returnUploadInfo.file_infos[0].id;
    }

    /// <summary>
    /// Отправляем загруженный файл пользователю.
    /// </summary>
    /// <param name="data">Данные для отправки.</param>
    public async static Task PostMsgWithFilesAsync(object data)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      await client.PostAsJsonAsync(Config.ApiUrlPost, data);
    }
    /// <summary>
    /// Удаление сообщения бота.
    /// </summary>
    /// <param name="msgID">ID удаляемого сообщения.</param>
    /// <returns>Возвращает результат удаления.</returns>
    public static async Task<bool> DestroyMsg(string msgID)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      dynamic json;
      string uri = Config.ApiUrlPost + "/" + msgID;
      try
      {
        json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
        string msg = json["message"];
        //обработка, что сообщение с графиком удалять нельзя.
        if (msg.Contains("@here График дежурств с"))
          return false;
      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к api MatterMost при попытке удаления сообщения с ID {msgID}. " +
            $"Текст ошибки:\r\n{ex}\r\n" +
            $"Обращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return false;
      }
      try
      {
        client.DeleteAsync(uri);
        await Task.Delay(100);
      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к api MatterMost при попытке удаления сообщения с ID {msgID}. " +
            $"Текст ошибки:\r\n{ex}\r\n" +
            $"Обращение к API завершилось c ошибкой.");
        await Task.Delay(100);
        return false;
      }
      return true;
    }
  }
}