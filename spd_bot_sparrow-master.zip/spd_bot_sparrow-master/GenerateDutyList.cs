﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{
  internal class GenerateDutyList
  {
    private static string BotID { get { return Config.BotID; } }
    public static async void DutyWeek()
    {
      await Task.Run(() => StartGenerateWork());
    }
    private async static Task StartGenerateWork()
    {
#if !DEBUG
      DateTime targetDate = calculation.NextGeneratingDate().Result;//prod
#endif
#if DEBUG
      DateTime targetDate = DateTime.Now;//test
#endif
      Logger.WriteLog("Дата и время новой генерации списка дежурств - " + targetDate);
      Console.WriteLine($"{DateTime.Now}: Дата и время новой генерации списка дежурств - " + targetDate);
      while (true)
      {
        if (DateTime.Now >= targetDate)
        {
          Console.WriteLine($"{DateTime.Now}: Старт новой генерации: " + DateTime.Now);
          Logger.WriteLog("Старт новой генерации");
          await Task.Run(() => GenerateDutyWeek());
          targetDate = calculation.NextGeneratingDate().Result;
          Logger.WriteLog("Следующая генерация графика: " + targetDate);
          Console.WriteLine($"{DateTime.Now}: Следующая генерация графика: " + targetDate);
        }
        await Task.Delay(60000);
      }
    }

    private async static Task GenerateDutyWeek()
    {
      //очищаем временную таблицу дежурств
      using (ApplicationContext db = new ApplicationContext())
      {
        db.Database.ExecuteSqlRaw("delete from tmpdutynothistory");
      }
      int iteration = 0;
      int neededDutyInThisWeek = 0;
      var dateList = calculation.NextWorkingWeek();
      //List<string> intern = calculation.GenerateInternList(); //зачем то болтается, но не используется
      foreach (DateTime currentDate in dateList)
      {
        if (calculation.EternalDuty(currentDate))
        {
          neededDutyInThisWeek++;
        }
        else
        {
          neededDutyInThisWeek += 2;
        }
      }
      var tmpDateList = new List<DateTime>();
      foreach (var d in dateList)
      {
        tmpDateList.Add(d);
      };

      List<Tuple<DateTime, string, string>> duty = new List<Tuple<DateTime, string, string>>(); //ДАТА : Дежурный : Команда Дежурного
      calculation.GenerateList(tmpDateList, duty);

      if (duty.Count < neededDutyInThisWeek && (tmpDateList.Count > 0))
      {
        while (true)
        {
          Console.WriteLine("Итерация №" + iteration);
          if (iteration < 2)
          {
            calculation.GenerateList(tmpDateList, duty);
          }
          else
          {
            calculation.GenerateWithoutPreference(tmpDateList, duty, iteration);
          }
          if ((duty.Count >= neededDutyInThisWeek) || (tmpDateList.Count <= 0))
          {
            break;
          }
          iteration++;
        }
      }
      //Формируем сообщение в канал
      string msg = GenerateMessage.GenerateDutyMsg(duty);
      var data = new
      {
        channel_id = Config.DutyChannalID,
        message = msg
      };
      try
      {
        Interplay.PreviousMessageID = Interplay.MessageID;
        Interplay.MessageID = await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data);
      }
      catch (Exception e)
      {
        Console.WriteLine(DateTime.Now + ". Ошибка при публикации сообщения в канал. Ошибка: \n\r " + e.Message);
        Console.WriteLine(DateTime.Now + ". График не опубликован.");
        return;
      }
      Console.WriteLine("Готово: " + DateTime.Now);
      Logger.WriteLog($"График дежурств, треды которого отслеживаются: {Interplay.MessageID}");

      //делаем 2 графика
      using (ApplicationContext db = new ApplicationContext())
      {
        var schedule = db.InfoMsgs.Where(x => x.msgtype.ToLower().Equals("previousschedule") || x.msgtype.ToLower().Equals("nextschedule"));
        if (!schedule.Any(x => x.msgtype.ToLower().Equals("previousschedule")))
        {
          db.InfoMsgs.Add(new InfoMsg
          {
            date = DateTime.Now,
            msgtype = "previousschedule",
            value = Interplay.PreviousMessageID
          });
        }
        else
        {
          if (!Interplay.PreviousMessageID.Equals(""))
          {
            schedule.Where(x => x.msgtype.ToLower().Equals("previousschedule")).FirstOrDefault().date = DateTime.Now;
            schedule.Where(x => x.msgtype.ToLower().Equals("previousschedule")).FirstOrDefault().value = Interplay.PreviousMessageID;
          }
        }
        if (!schedule.Any(x => x.msgtype.ToLower().Equals("nextschedule")))
        {
          db.InfoMsgs.Add(new InfoMsg
          {
            date = DateTime.Now,
            msgtype = "nextschedule",
            value = Interplay.MessageID
          });
        }
        else
        {
          if (!Interplay.MessageID.Equals(""))
          {
            schedule.Where(x => x.msgtype.ToLower().Equals("nextschedule")).FirstOrDefault().date = DateTime.Now;
            schedule.Where(x => x.msgtype.ToLower().Equals("nextschedule")).FirstOrDefault().value = Interplay.MessageID;
          }
        }
        db.SaveChanges();
        //Рефакторинг
        /*
        List<string> querys = new List<string>();

        querys.Add("DELETE FROM infomsg WHERE msgtype in ('previousschedule', 'nextschedule')");
        querys.Add($"INSERT INTO infomsg (date, msgtype, value) VALUES ('{DateTime.Now}', 'previousschedule', '{Interplay.MessageID}')");
        querys.Add($"INSERT INTO infomsg (date, msgtype, value) VALUES ('{DateTime.Now}', 'nextschedule', '{Interplay.PreviousMessageID}')");
        foreach (var query in querys)
        {
          db.Database.ExecuteSqlRaw(query);
        }
        */
      }
    }
  }
}