﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{
  /// <summary>
  /// Класс использовался на ранних этапах разработки, в данный момент не используется, оставлен для истории.
  /// </summary>
  internal class ParsingToHistory
  {
    #region не используемые классы, оставлю для совместимости
    public static async void ParsingHistory()
    {

      await Task.Run(() => StartParsing()); //prod
                                            //await Task.Run(() => ParsingDutyToHistory()); //debug
                                            //await ParsingDutyToHistory(); //debug
    }
    /// <summary>
    /// не используемый класс, парсинг графика происходит сразу после формирования, использовался до реализации замен через бота
    /// </summary>
    /// <returns></returns>
    private async static Task StartParsing()
    {
      DateTime targetDate = calculation.NextGeneratingDate().Result.AddHours(7);
      Console.WriteLine("Дата и время парсинга списка дежурств - " + targetDate);
      while (true)
      {
        if (DateTime.Now >= targetDate)
        {
          await Task.Run(() => ParsingDutyToHistory());
          targetDate = calculation.NextGeneratingDate().Result.AddHours(7);
        }
        //Thread.Sleep(60000);
        await Task.Delay(60000);
      }
    }

    #endregion

    /// <summary>
    /// основной класс для парсинга истории сразу после генерации графика
    /// </summary>
    /// <returns></returns>
    public async static Task ParsingDutyToHistory()
    {
      Console.WriteLine("Старт парсинга в историю графика дежурств " + DateTime.Now);
      Logger.WriteLog("Старт парсинга в историю графика дежурств");
      List<Tuple<DateTime, string>> duty = calculation.ParseDutyListAsync();
      if (duty.Count == 0)
      {
        return;
      }
      using (ApplicationContext db = new ApplicationContext())
      {
        var usr = db.Users.FromSqlRaw("SELECT * FROM users where intern is false").ToList();
        foreach (var d in duty)
        {
          foreach (User u in usr)
          {
            if (u.Login.ToLower().Equals(d.Item2.ToLower()))
            {
              string query = string.Format("INSERT INTO dutyhistory (iduser, date) VALUES ({0},'{1}')",
                  u.Id, d.Item1.ToString("dd.MM.yyyy"));
              db.Database.ExecuteSqlRaw(query);
            }
          }
        }
      }
      Console.WriteLine("График внесен в историю: " + DateTime.Now);
      Logger.WriteLog("График внесен в историю.");
    }
  }
}