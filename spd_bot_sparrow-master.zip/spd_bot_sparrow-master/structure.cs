﻿namespace spd_bot_sparrow
{
    /// <summary>
    /// классы структур
    /// </summary>
    struct UsersList
    {
        public string userLogin;
        public int shiftsNumber;
        public string team;
        public string fio;
        public UsersList(string userLogin, int shiftsNumber, string team, string fio)
        {
            this.userLogin = userLogin;
            this.shiftsNumber = shiftsNumber;
            this.team = team;
            this.fio = fio;
        }
    }
}
