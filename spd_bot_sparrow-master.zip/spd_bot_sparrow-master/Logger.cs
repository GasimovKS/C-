﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{
  /// <summary>
  /// Класс для логирования сообщений бота в текстовый файл. Файл располагается рядом с самим ботом.
  /// </summary>
  internal class Logger
  {
    /// <summary>
    /// Лог работы бота.
    /// </summary>
    /// <param name="textLog">Текст сообщения в лог</param>
    public static async void WriteLog(string textLog)
    {
      if (!File.Exists("sparrow.log"))
      {
        using (StreamWriter writer = new StreamWriter("sparrow.log", true))
        {
          await writer.WriteLineAsync("Начало лога");
        }
      }
      string logToFile = $"{DateTime.Now}: " + textLog;
      while (FileIsLocked("sparrow.log", FileAccess.ReadWrite))
      {
        await Task.Delay(300);
      }
      try
      {
        using (StreamWriter writer = new StreamWriter("sparrow.log", true))
        {
          await writer.WriteLineAsync(logToFile);
        }
      }
      catch
      {
        WriteLog(textLog);
      }
    }
    /// <summary>
    /// Лог для прямых сообщений.
    /// </summary>
    /// <param name="textLog">Текст сообщения в лог</param>
    public static async void WriteDirectLog(string textLog)
    {
      if (!File.Exists("direct.log"))
      {
        using (StreamWriter writer = new StreamWriter("direct.log", true))
        {
          await writer.WriteLineAsync("Начало лога");
        }
      }
      string logToFile = $"{DateTime.Now}: " + textLog;
      while (FileIsLocked("direct.log", FileAccess.ReadWrite))
      {
        await Task.Delay(150);
      }
      try
      {
        using (StreamWriter writer = new StreamWriter("direct.log", true))
        {
          await writer.WriteLineAsync(logToFile);
        }
      }
      catch
      {
        WriteDirectLog(textLog);
      }
    }
    /// <summary>
    /// Лог поздравлялки.
    /// </summary>
    /// <param name="textLog">Текст сообщения в лог.</param>
    public static async void WriteBirthdayLog(string textLog)
    {
      if (!File.Exists("birthday.log"))
      {
        using (StreamWriter writer = new StreamWriter("birthday.log", true))
        {
          await writer.WriteLineAsync("Начало лога");
        }
      }
      string logToFile = $"{DateTime.Now}: " + textLog;
      while (FileIsLocked("birthday.log", FileAccess.ReadWrite))
      {
        await Task.Delay(50);
      }
      try
      {
        using (StreamWriter writer = new StreamWriter("birthday.log", true))
        {
          await writer.WriteLineAsync(logToFile);
        }
      }
      catch
      {
        WriteBirthdayLog(textLog);
      }
    }
    /// <summary>
    /// Возвращает true, если файл заблокирован для указанного доступа.
    /// </summary>
    /// <param name="filename">Проверяемый на доступность файл.</param>
    /// <param name="file_access">Вид доступа к файлу.</param>
    /// <returns>Результат проверки на доступность.</returns>
    private static bool FileIsLocked(string filename, FileAccess file_access)
    {
      // Попробуйте открыть файл с указанным доступом.
      try
      {
        FileStream fs =
            new FileStream(filename, FileMode.Open, file_access);
        fs.Close();
        return false;
      }
      catch (IOException)
      {
        return true;
      }
      catch (Exception)
      {
        throw;
      }
    }
  }
}
