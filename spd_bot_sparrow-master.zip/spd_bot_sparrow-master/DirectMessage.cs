﻿using Microsoft.EntityFrameworkCore;
using NameCaseLib;
using Newtonsoft.Json.Linq;
using Npgsql.EntityFrameworkCore.PostgreSQL.Infrastructure.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{
  internal class DirectMessage
  {
    #region переменные
    private static string BotID { get { return Config.BotID; } }
    private static string ErrMsg { get { return "Неверный формат команды, отказано."; } }
    private static string ErrCmdMsg { get { return "Команда не найдена, повторите попытку"; } }
    private static string ErrHappy { get { return "Запрещено готовить поздравление и подравлять самого себя"; } }
    private static string ErrCmdFormatMsg { get { return "Команда не соотвутствеует формату команды, повторите попытку"; } }
    private static string ErrAuthorNotDuty { get { return "Ты не дежуришь на этой недели."; } }
    private static string ErrDate { get { return "Запрещена замена/подмена на даты дежурств, которые уже прошли"; } }
    private static string JokeMsg { get { return "А ты шутник."; } }
    private static string NotEmployeesSPD { get { return "Указаный сотрудник не является действующим сотрудником СПД, отказано."; } }
    private static string NotNeedCongrat { get { return " просил его не поздравлять с днём рождения, отказано."; } }

    private static string UserRefusal { get { return " отказался от замены"; } }
    private static readonly List<string> allAgreeReactions = new List<string>
        {
            "heavy_check_mark",
            "ballot_box_with_check",
            "checkered_flag",
            "white_check_mark",
            "plus",
            "heavy_plus_sign",
            "ok",
            "ok_hand",
            "okay",
            "+1",
            "resolved"
        };
    private static readonly List<string> allDisagreeReactions = new List<string>
        {
            "minus",
            "heavy_minus_sign",
            "octagonal_sign",
            "black_square_for_stop",
            "x",
            "name_badge",
            "negative_squared_cross_mark",
        };
    private static readonly List<string> nameDayOfWeek = new List<string>
        {
            "monday",
            "tuesday",
            "wednesday",
            "thursday",
            "friday",
            "saturday",
            "sunday",
        };
    #endregion

    /// <summary>
    /// работа с прямыми диалогами к боту
    /// </summary>
    internal static async void TrackingDirectMessages()
    {
      DateTime targetDateSyncDirectChannel = DateTime.Now;
      DateTime targetSearchNewMessageInDirectChannels = DateTime.Now;
      DateTime targetDateUpdateChannels = DateTime.Today;
      DateTime targetDateProcessedRecordsClean = DateTime.Today;
      DateTime targetDateUpdatePreferences = DateTime.Today;
      List<string> directChannels = new List<string>();
      List<string> processedRecords = new List<string>();
      while (true)
      {
        if (DateTime.Now.DayOfWeek.Equals("sunday") && (processedRecords.Count != 0)
            && (DateTime.Now >= DateTime.Today.AddHours(23).AddMinutes(55)) && (DateTime.Now <= DateTime.Today.AddHours(23).AddMinutes(59)))
        {
          processedRecords.Clear();
        }
        if (DateTime.Now >= targetDateUpdateChannels)
        {
          directChannels.Clear();
          using (ApplicationContext db = new ApplicationContext())
          {
            directChannels = db.DirectChannels.Select(x => x.Idchannel).ToList();
            //Рефакторинг
            /*var direct = db.DirectChannels.FromSqlRaw("SELECT * FROM directchannel");
            foreach (var d in direct)
            {
              directChannels.Add(d.Idchannel);
            }*/
          }
          targetDateUpdateChannels = targetDateUpdateChannels.AddDays(1);
        }
        if (DateTime.Now >= targetDateSyncDirectChannel)
        {
          await Task.Run(() => SyncDirectChannel());
          targetDateSyncDirectChannel = targetDateSyncDirectChannel.AddDays(1);
          directChannels.Clear();
          using (ApplicationContext db = new ApplicationContext())
          {
            directChannels = db.DirectChannels.Select(x => x.Idchannel).ToList();
          }
        }
        if ((DateTime.Now >= targetSearchNewMessageInDirectChannels)
            && (DateTime.Now >= DateTime.Today.AddHours(5)) && (DateTime.Now <= DateTime.Today.AddHours(24)))
        {
          if (directChannels.Count == 0)
          {
            Logger.WriteLog("В БД бота отсутствую записи с каналами прямых сообщений, требуется синхронизация");
            targetSearchNewMessageInDirectChannels = DateTime.Now.AddMinutes(5);
            await Task.Delay(300);
            continue;
          }
          await Task.Run(() => SearchNewMessageInDirectChannels(directChannels, processedRecords));
          targetSearchNewMessageInDirectChannels = DateTime.Now.AddSeconds(4);
        }

        if ((DateTime.Now > targetDateUpdatePreferences)
            && (DateTime.Now >= DateTime.Today.AddHours(10)) && (DateTime.Now <= DateTime.Today.AddHours(15)))
        {
          var startDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
          var endDate = startDate.AddMonths(1).AddDays(-1);
          bool isWorkingDay = false;
          int countPostMsgInCurrentMonth = 0;
          using (ApplicationContext db = new ApplicationContext())
          {
            countPostMsgInCurrentMonth = db.InfoMsgs.Where(x => x.date >= startDate
                                                                && x.date <= endDate
                                                                && x.msgtype.ToLower().Equals("info")).Count();
            isWorkingDay = db.Calendars.Where(x => x.Date == targetDateUpdatePreferences).Select(x => x.Iswork).FirstOrDefault();
            //Рефакторинг
            /*countPostMsgInCurrentMonth = db.InfoMsgs.FromSqlRaw($"SELECT * FROM infomsg " +
                $"WHERE date between '{startDate.ToString("dd.MM.yyyy")}' and '{endDate.ToString("dd.MM.yyyy")}' " +
                $"and msgtype = 'info'")
                .Count();
            isWorkingDay = db.Calendars.FromSqlRaw($"SELECT * FROM calendar WHERE date = '{targetDateUpdatePreferences.ToString("dd.MM.yyyy")}'")
                .Select(x => x.Iswork)
                .FirstOrDefault();*/
          }
          if (countPostMsgInCurrentMonth != 0)
          {
            targetDateUpdatePreferences = startDate.AddMonths(1);
            await Task.Delay(300);
            continue;
          }
          if (!isWorkingDay)
          {
            targetDateUpdatePreferences = targetDateUpdatePreferences.AddDays(1);
            await Task.Delay(300);
            continue;
          }
          await Task.Run(() => PostMsgNeedUpdatePreferenceInBase());
          targetDateUpdatePreferences = startDate.AddMonths(1);
        }
        await Task.Delay(1000);
      }

    }
    /// <summary>
    /// Постим сообщение об необходимости обновления предпочтений в базе бота и напоминание, что можно выразить желание поздравить коллегу
    /// </summary>
    private static async void PostMsgNeedUpdatePreferenceInBase()
    {
      string infoMsg = "@channel Коллеги, напоминаю, что Вы можете обновить список дней, в которые Вас предпочтительнее ставить дежурными." + Environment.NewLine +
          "Для этого воспользуйтесь прямым диалогом с ботом @sparrow." + Environment.NewLine +
          "Команда для получения вашего актуального списка предпочтений **!currentpreferences**" + Environment.NewLine +
          "Так же Вы можете выразить желание поздравить коллегу с днем рождения, " +
          "воспользовавшись командой **!happybirthday** в прямом диалоге с ботом @sparrow." + Environment.NewLine +
          "Рекомендуется заблаговременно уведомить об этом бота.";
      ToMattermost.PutInfoMessage(infoMsg, BotID);
      using (ApplicationContext db = new ApplicationContext())
      {
        db.Add(new InfoMsg
        {
          date = DateTime.Now,
          msgtype = "info"
        });
        db.SaveChanges();
        //Рефакторинг
        //string insertQuery = $"INSERT INTO infomsg (date, msgtype) VALUES ('{DateTime.Now}', 'info')";
        //db.Database.ExecuteSqlRaw(insertQuery);
      }
    }

    /// <summary>
    /// метод для синхронизации ID прямого канала сообщений с пользователем
    /// </summary>
    public static async void SyncDirectChannel()
    {
      Console.WriteLine($"{DateTime.Now} Старт синхронизации каналов прямых сообщений");
      Logger.WriteLog($"Старт синхронизации каналов прямых сообщений");
      List<User> users;
      List<Tuple<int, string, string>> directChannels = new List<Tuple<int, string, string>>();
      List<string> userLogins = new List<string>();

      bool isNeedUpdateRecords = false;
      bool isNeeInsertRecords = false;
      int updateCount = 0;
      int insertCount = 0;
      using (ApplicationContext db = new ApplicationContext())
      {
        //удаляем из списка отслеживаемых каналов те, которые больше не сотрудники СПД
        users = db.Users.Where(x => !x.Employee_SPD).ToList();
        //Рефакторинг
        //users = db.Users.FromSqlRaw("SELECT * FROM users where employee_spd is false").ToList();
        foreach (var user in users)
        {
          if (db.DirectChannels.Where(x => x.Iduser == user.Id).Any())
          {
            db.DirectChannels.Remove(db.DirectChannels.Where(x => x.Iduser == user.Id).First());
            db.SaveChanges();
          }
          //Рефакторинг
          /*int countDirectChannels = db.DirectChannels.FromSqlRaw($"SELECT * FROM directchannel where iduser = {user.Id}").Count();
          if (countDirectChannels > 0)
          {
            string deleteQuery = $"DELETE FROM directchannel " +
                       $"WHERE iduser = {user.Id}";
            db.Database.ExecuteSqlRaw(deleteQuery);
          }*/
        }
        users = db.Users.Where(x => x.Employee_SPD).ToList();
        var usersChannels = db.DirectChannels.ToList();
        //Рефакторинг
        //users = db.Users.FromSqlRaw("SELECT * FROM users where employee_spd is true").ToList();
        //var usersChannels = db.DirectChannels.FromSqlRaw("SELECT * FROM directchannel").ToList();
        var directChannelList = (from u in users
                                 join d in usersChannels on u.Id equals d.Iduser
                                 select new { Id = u.Id, Login = u.Login, d.Idchannel }).ToList();
        foreach (var u in users)
        {
          userLogins.Add(u.Login.ToLower());
        }
        foreach (var d in directChannelList)
        {
          directChannels.Add(new Tuple<int, string, string>(d.Id, d.Login, d.Idchannel));
        }
      }
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      int counter = 0;
      List<string> usrToMM = new List<string>();
      List<UsersInfo> usersInfo;
      try
      {
        var response = await client.PostAsJsonAsync(Config.ApiSearchUsersByName, userLogins);
        usersInfo = JArray.Parse(response.Content.ReadAsStringAsync().Result).ToObject<List<UsersInfo>>();
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Произошла ошибка при обращении к api MatterMost\r" +
        $"Текст ошибки:\r{ex}\r" +
        $"Обращение к API завершилось c ошибкой.");
        return;
      }
      //Рефакторинг
      //string insertQuery = "INSERT INTO directchannel (iduser, idchannel) VALUES";
      List<DirectChannel> channels = new List<DirectChannel>();
      foreach (var user in usersInfo)
      {
        foreach (var u in users)
        {
          if (user.username.ToLower().Equals(u.Login.ToLower()))
          {
            switch (directChannels.Where(x => x.Item1 == u.Id).Count())
            {
              case 0:
                {
                  DirectChannelInfo directInfo;
                  List<string> json = new List<string>();
                  json.Add(BotID);
                  json.Add(user.id);
                  var response = await client.PostAsJsonAsync(Config.ApiUrlDirectChannel, json);
                  directInfo = JObject.Parse(response.Content.ReadAsStringAsync().Result).ToObject<DirectChannelInfo>();
                  channels.Add(new DirectChannel
                  {
                    Iduser = u.Id,
                    Idchannel = directInfo.id
                  });
                  //insertQuery += $" ({u.Id}, '{directInfo.id}'),";
                  isNeeInsertRecords = true;
                  insertCount++;
#if !DEBUG
                  await Task.Delay(1000);
#endif
                  break;
                }
              case 1:
                {
                  DirectChannelInfo directInfo;
                  List<string> json = new List<string>();
                  json.Add(BotID);
                  json.Add(user.id);
                  var response = await client.PostAsJsonAsync(Config.ApiUrlDirectChannel, json);
                  directInfo = JObject.Parse(response.Content.ReadAsStringAsync().Result).ToObject<DirectChannelInfo>();
                  if (directChannels.Where(x => x.Item1 == u.Id).First().Item3.ToLower().Equals(directInfo.id))
                  {
                    continue;
                  }
#if !DEBUG
                  await Task.Delay(1000);
#endif
                  //Рефакторинг
                  /*string updateQuery = $"UPDATE directchannel SET idchannel = '{directInfo.id}' WHERE iduser = {u.Id}";
                  using (ApplicationContext db = new ApplicationContext())
                  {
                    db.Database.ExecuteSqlRaw(updateQuery);
                  }*/
                  updateCount++;
                  using (ApplicationContext db = new ApplicationContext())
                  {
                    db.DirectChannels.Where(x => x.Iduser == u.Id).First().Idchannel = directInfo.id;
                    db.SaveChanges();
                  }
                  break;
                }
              default:
                Logger.WriteLog($"В таблице DIRECTCHANNELS найдено более одной уникальной записи с idUser");
                break;
            }
          }
        }
      }
      using (ApplicationContext db = new ApplicationContext())
      {
        if (isNeeInsertRecords)
        {
          db.AddRange(channels);
          db.SaveChanges();
          //Рефакторинг
          //insertQuery = insertQuery.TrimEnd(',');
          //db.Database.ExecuteSqlRaw(insertQuery);
        }
      }
      Logger.WriteLog($"Закончена синхронизация каналов прямых сообщений. " +
          $"Добавлено новых записей {insertCount}, обновлено записей {updateCount}.");
    }

    /// <summary>
    /// Метод для отслеживания новых сообщений прямых диалогах с ботом
    /// </summary>
    private static async void SearchNewMessageInDirectChannels(List<string> directChannels, List<string> processedRecords)
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      foreach (var channel in directChannels)
      {
        OneMessage msg;
        List<string> idMsg = new List<string>();
        string uri = Config.ApiUrlChannel + "/" + channel + "/posts";
        uri += "?since=" + DateTimeOffset.Now.AddDays(-1).ToUnixTimeMilliseconds();
        dynamic json;
        try
        {
          json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
        }
        catch (Exception ex)
        {
          Logger.WriteLog($"Произошла ошибка при обращении к API Mattermost, текст ошибки\r\n{ex.Message}");
#if !DEBUG
          await Task.Delay(5000);
#endif
          continue;
        }
        foreach (var id in json.order)
        {
          idMsg.Add(id.ToString());
        }
        if (idMsg.Count == 0)
        {
          continue;
        }
        for (int index = idMsg.Count - 1; index >= 0; index--)
        {
          if (processedRecords.Contains(idMsg[index]))
          {
            idMsg.RemoveAt(index);
          }
        }
        if (idMsg.Count == 0)
        {
          continue;
        }
        foreach (var id in idMsg)
        {
          uri = Config.ApiUrlPost + "/" + id;
          try
          {
            msg = JObject.Parse((await client.GetStringAsync(uri)).ToString()).ToObject<OneMessage>();
          }
          catch (Exception ex)
          {
#if !DEBUG
            await Task.Delay(500);
#endif
            continue;
          }
          if (msg.delete_at != 0)
          {
            processedRecords.Add(id);
            await Task.Delay(200);
            continue;
          }
          await Task.Delay(100);
          string uriReactions = Config.ApiUrlPost + "/" + id + "/reactions";
          try
          {
            bool isBotReactions = false;
            JArray jsonReactions = JArray.Parse(await client.GetStringAsync(uriReactions));
            await Task.Delay(500);
            foreach (var jString in jsonReactions)
            {
              dynamic jsonReaction = JObject.Parse(jString.ToString());
              string tmpUsrId = jsonReaction["user_id"];
              string emojiName = jsonReaction["emoji_name"];
              if ((string.Compare(tmpUsrId, BotID) == 0) &&
                  (string.Compare(emojiName, "no_entry_sign") == 0 || string.Compare(emojiName, "done2") == 0 ||
                  string.Compare(emojiName, "skoratov") == 0 || string.Compare(emojiName, "ed_dovolen") == 0))
              {
                processedRecords.Add(id);
                isBotReactions = true;
              }
            }
            if (isBotReactions)
            {
              continue;
            }
          }
          catch (Exception) { }

          string currentMsg = msg.message;
          string authorMsg = ToMattermost.GetUserNameByID(msg.user_id).Result;

          Regex regexCommand = new Regex(@"^!(\w*)");
          MatchCollection matchesCommand = regexCommand.Matches(currentMsg);
          currentMsg = regexCommand.Replace(currentMsg + " ", "");
          if (matchesCommand.Count != 0)
          {
            switch (matchesCommand[0].Value.ToLower())
            {
              case "!help": //список команд                                
                HelpCmd(channel, id, processedRecords, authorMsg);
                processedRecords.Add(id);
                break;
              case "!currentpreferences": //изменение предпочтительных дней дежурств                               
                CurrentPreferencesCmd(channel, id, processedRecords);
                processedRecords.Add(id);
                break;
              case "!preferences": //изменение предпочтительных дней дежурств                               
                PreferencesCmd(channel, id, currentMsg, processedRecords);
                break;
              case "!schedule":
                switch (currentMsg.Trim())
                {
                  case "duty"://сгенерировать график дежурств в эксель, загрузить на сервер ММ и отправить ответом вложеним в сообщение
                    processedRecords.Add(id);
                    ScheduleCmd(channel, id, processedRecords, "duty");
                    break;
                  case "vacation": //сгенерировать график отпусков в эксель, загрузить на сервер ММ и отправить ответом вложеним в сообщение
                    processedRecords.Add(id);
                    ScheduleCmd(channel, id, processedRecords, "vacation");
                    break;
                  case "congrat": //сгенерировать история поздравлений в эксель, загрузить на сервер ММ и отправить ответом вложеним в сообщение
                    processedRecords.Add(id);
                    ScheduleCmd(channel, id, processedRecords, "congratulations");
                    break;
                  default:
                    processedRecords.Add(id);
                    await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                    await ToMattermost.MsgToDirectChannel(channel, ErrCmdFormatMsg, BotID);
                    break;
                }
                break;
              case "!rating": //сгенерировать рейтинг дежурств
                GenerateRating(channel, id, processedRecords);
                processedRecords.Add(id);
                break;
              case "!variant": //список людей на замену
                DutyChangeOptions(channel, id, processedRecords);
                processedRecords.Add(id);
                break;
              case "!reload": //список людей на замену
                if (authorMsg.ToLower().Equals("chirkov_ro") || authorMsg.ToLower().Equals(Config.DutysResponsible.ToLower()))
                {
                  if (currentMsg.Contains("prev"))
                  {
                    processedRecords.Add(id);
                    ReloadSchedule(id, processedRecords, true);
                  }
                  else
                  {
                    processedRecords.Add(id);
                    ReloadSchedule(id, processedRecords);
                  }
                }
                else
                {
                  processedRecords.Add(id);
                  await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                  await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                }
                break;
              case "!destroy":
                if (authorMsg.ToLower().Equals("chirkov_ro") || authorMsg.ToLower().Equals(Config.DutysResponsible.ToLower()))
                {
                  processedRecords.Add(id);
                  destroyMsg(msg.message, id, processedRecords);
                }
                else
                {
                  processedRecords.Add(id);
                  await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                  await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                }
                break;
              case "!happybirthday":
                processedRecords.Add(id);
                await HappyBirthdayColleague(msg.message, authorMsg, channel, id, processedRecords);
                break;
              case "!заебал": //команда заебал)
                ZaebaCmd(processedRecords, id, msg.message, authorMsg);
                /*
                if (authorMsg.ToLower().Equals("chirkov_ro"))
                {
                  ZaebaCmd(processedRecords, id, msg.message, authorMsg);
                }
                else
                {
                  await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                  await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                }
                */
                break;
              case "!absence": //добавить вручную больничный
                if (authorMsg.ToLower().Equals("chirkov_ro") || authorMsg.ToLower().Equals(Config.DutysResponsible.ToLower()))
                {
                  AbsenceCmd(channel, processedRecords, id, currentMsg);
                }
                else
                {
                  await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                  await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                }
                break;
              case "!status": //статус работы бота
                if (authorMsg.ToLower().Equals("chirkov_ro") || authorMsg.ToLower().Equals(Config.DutysResponsible.ToLower()))
                {
                  StatusCmd(channel, processedRecords, id);
                }
                else
                {
                  await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                  await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                }
                break;
              case "!stoplist": //стоп-лист по поздравлениям
                if (authorMsg.ToLower().Equals("chirkov_ro") || authorMsg.ToLower().Equals(Config.CongratulationsResponsible.ToLower()))
                {
                  if (currentMsg.Trim().ToLower().Equals("show"))
                  {
                    ShowIgnoreCase(channel, processedRecords, id);
                  }
                  else
                  {
                    try
                    {
                      switch (currentMsg.Trim().Remove(currentMsg.IndexOf('@') - 2).Trim())
                      {
                        case "congrat": //обновить данные по возможности ставить поздравляющим
                          AddRemoveIgnoreCaseHappy(channel, id, processedRecords, currentMsg, false);
                          break;
                        case "birthday": //обновить данные по необходимости поздравлять
                          AddRemoveIgnoreCaseHappy(channel, id, processedRecords, currentMsg);
                          break;
                        default:
                          await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                          await ToMattermost.MsgToDirectChannel(channel, ErrCmdFormatMsg, BotID);
                          break;
                      }
                    }
                    catch
                    {
                      Logger.WriteDirectLog($"Пришла следующая кривая команда в прямые диалоги, автор {authorMsg}:{Environment.NewLine}{msg.message}");
                      await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                      await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                      processedRecords.Add(id);
                    }
                  }
                }
                else
                {
                  await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                  await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                  processedRecords.Add(id);
                }
                break;
              case "!teamlead": //изменить статус сотрудника на "тимлид"
                if (authorMsg.ToLower().Equals("chirkov_ro") || authorMsg.ToLower().Equals(Config.DutysResponsible.ToLower()))
                {
                  processedRecords.Add(id);
                  TeamleadCmd(channel, processedRecords, id, currentMsg);
                }
                else
                {
                  processedRecords.Add(id);
                  await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                  await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                }
                break;
              case "!removedoubles": //Удаление дублей в таблице отсутствий
                if (authorMsg.ToLower().Equals("chirkov_ro") || authorMsg.ToLower().Equals(Config.DutysResponsible.ToLower()))
                {
                  processedRecords.Add(id);
                  removeAbsenceDouble();
                  await ToMattermost.PutReactionPost(id, "done2", BotID);
                }
                else
                {
                  processedRecords.Add(id);
                  await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                  await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                }
                break;
              default:
                Logger.WriteDirectLog($"{DateTime.Now}: Пришла следующая неопознанная команда в прямые диалоги, автор {authorMsg}:{Environment.NewLine}{msg.message}");
                await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
                await ToMattermost.MsgToDirectChannel(channel, ErrCmdMsg, BotID);
                processedRecords.Add(id);
                break;
            }
          }
          else
          {
            processedRecords.Add(id);
          }
#if !DEBUG
          await Task.Delay(1000);
#endif
        }
      }
    }

    /// <summary>
    /// Команда для обновления/добавления предпочтительных дней дежурств
    /// </summary>
    /// <param name="channel">Id канала прямых сообщений пользователя, от которого пришла команда.</param>
    /// <param name="id">Id сообщения этого канала с пришедшей командой.</param>
    /// <param name="processedRecords">Список с ID обработанных сообщений.</param>
    /// <param name="authorMsg">Автор сообщения.</param>
    private static async void HelpCmd(string channel, string id, List<string> processedRecords, string authorMsg)
    {
      string message = "Доступные команды бота:" + Environment.NewLine +
          "**!rating** - команда выводит количество отдежуренных смен инженерами по возрастанию общего количества за год." + Environment.NewLine +
          "**!currentpreferences** - Дни, в которые тебе предпочтительные ставить дежурства." + Environment.NewLine +
          "**!preferences** - Обновление дней, в которые тебе предпочтительные ставить дежурства." + Environment.NewLine +
          "При использовании команды указываются дни недели, в которые ЖЕЛАТЕЛЬНО ставить дежурным" + Environment.NewLine +
          $"формат команды:{Environment.NewLine}**!preferences пн вт ср чт пт сб вс**{Environment.NewLine}" +
          $"или{Environment.NewLine}**!preferences понедельник вторник среда четверг пятница суббота воскресенье**" + Environment.NewLine +
          "**!schedule duty** - Сгенерировать график дежурств в файл формата Excel." + Environment.NewLine +
          "**!schedule vacation** - Сгенерировать график отпусков в файл формата Excel." + Environment.NewLine +
          "**!schedule congrat** - Сгенерировать информацию по отказам и согласиям поздравлений коллег в файл формата Excel." + Environment.NewLine +
          "**!happybirthday** - Выразить желание на поздравление определенного коллеги. Формат команды !happybirthday @sparrow";
      if (authorMsg.ToLower().Equals(Config.DutysResponsible.ToLower()) || authorMsg.ToLower().Equals("chirkov_ro"))
      {
        message += Environment.NewLine + "Команды управления ботом, доступные ответственному за дежурства:" + Environment.NewLine +
            "**!destroy** и id сообщения бота - удалит сообщение бота." + Environment.NewLine +
            "**!reload**, используется без параметров, запускает перегенерацию сообщения с графиком дежурств." +
            "Полезно, когда руками обновил некоторые данные в БД, и необходимо перегенерировать сообщение бота " +
            "с актуальным графиком дежурств." + Environment.NewLine +
            "**!reload previous**, при использовании с параметром запускается перегенерация сообщения с предыдущим графиком дежурств." + Environment.NewLine +
            "**!absence** - добавление больничного в базу бота. Полезно, когда человек не может оформить больничный или отгул, " +
            "но должен дежурить по графику. Формат команды: !absence @chirkov_ro 19.12.1989." + Environment.NewLine +
            "**!teamlead** - обновление информации о тимлиде, формат команд !teamlead @userlogin. Если отсутствует пользователь, то команда выведет текущую информацию в базе данных бота о тимлидах," + Environment.NewLine +
            "**!removedoubles** - удаление дублей записей в БД бота в таблице отсутствий" + Environment.NewLine +
            "**!status** - текущий статус работы бота по модулям.";
      }
      if (authorMsg.ToLower().Equals(Config.CongratulationsResponsible.ToLower()) || authorMsg.ToLower().Equals("chirkov_ro"))
      {
        message += Environment.NewLine + "Команды управления ботом, доступные ответственному за поздравления в отделе:" + Environment.NewLine +
            "**!stoplist show** - команда для отображения текущего стоп-листа" + Environment.NewLine +
            "**!stoplist congrat** - обновление данных стоп-листа по сотрудникам отдела, которых можно или нельзя ставить поздравляющими. Формат команды !stoplist congrat @userlogin" + Environment.NewLine +
            "**!stoplist birthday** - обновление данных стоп-листа по сотрудникам отдела, которых надо либо не надо поздравлять с днём рождения в отделе. Формат команды !stoplist birthday @userlogin";
      }
      var data = new
      {
        channel_id = channel,
        message = message,
      };
      await ToMattermost.PutReactionPost(id, "done2", BotID);
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
    }
    /// <summary>
    /// Команда для обновления/добавления предпочтительных дней дежурств
    /// </summary>
    /// <param name="channel">Id канала прямых сообщений пользователя, от которого пришла команда.</param>
    /// <param name="id">Id сообщения этого канала с пришедшей командой.</param>
    /// <param name="currentMsg">Текст сообщения пользователя.</param>
    /// <param name="processedRecords">Список с ID обработанных сообщений.</param>
    private static async void PreferencesCmd(string channel, string id, string currentMsg, List<string> processedRecords)
    {
      string msg = "Данные по предпочитаемым дням дежурства обновлены.";
      //Рефакторинг
      //string insertQuery = "INSERT INTO preferences (iduser, monday, tuesday, wednesday, thursday, friday, saturday, sunday) VALUES (";
      List<Preference> preferences = new List<Preference>();
      List<string> targetDayOfWeek = new List<string>();
      //Рефакторинг
      //DirectChannel usr;
      int idUser = 0;
      //чистим имеющиеся данные в БД по пользователю
      using (ApplicationContext db = new ApplicationContext())
      {
        idUser = db.DirectChannels.Where(x => x.Idchannel.ToLower().Equals(channel))
                                                  .Select(x => x.Iduser)
                                                  .FirstOrDefault();
        if (idUser != 0)
        {
          Preference usrPrefToRemove = db.Preferences.Where(x => x.Iduser == idUser).FirstOrDefault();
          if (usrPrefToRemove != null)
          {
            db.Preferences.Remove(usrPrefToRemove);
            db.SaveChanges();
          }
        }
        //Рефакторинг
        //usr = db.DirectChannels.FromSqlRaw($"SELECT * FROM directchannel WHERE idchannel = '{channel}'").FirstOrDefault();
        //db.Database.ExecuteSqlRaw($"DELETE FROM preferences WHERE iduser = {usr.Iduser}");
      }
      Regex regexDutyDays = new Regex(@"(\w*)");
      MatchCollection matchDutyDays = regexDutyDays.Matches(currentMsg);
      if (matchDutyDays.Count == 0)
      {
        processedRecords.Add(id);
        await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
        await ToMattermost.MsgToDirectChannel(channel, ErrMsg, BotID);
        return;
      }
      foreach (var targetDutyDay in matchDutyDays)
      {
        string tmpDate = calculation.textToDayFormat(targetDutyDay.ToString());
        if (tmpDate != "")
        {
          targetDayOfWeek.Add(tmpDate.ToLower());
        }
      }
      if (targetDayOfWeek.Count == 0)
      {
        processedRecords.Add(id);
        await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
        await ToMattermost.MsgToDirectChannel(channel, ErrMsg, BotID);
        return;
      }
      if (!targetDayOfWeek.Contains("saturday"))
      {
        targetDayOfWeek.Add("saturday");
      }
      if (!targetDayOfWeek.Contains("sunday"))
      {
        targetDayOfWeek.Add("sunday");
      }
      //Рефакторинг
      /*
      insertQuery += $"{usr.Iduser},";
      foreach (var d in nameDayOfWeek)
      {
        if (targetDayOfWeek.Contains(d.ToLower()))
        {
          insertQuery += "true,";
        }
        else
        {
          insertQuery += "false,";
        }
      }
      insertQuery = insertQuery.TrimEnd(',');
      insertQuery += ")";
      */
      Preference usrPref = new Preference
      {
        Iduser = idUser,
        Sunday = true,
        Monday = targetDayOfWeek.Contains("monday") ? true : false,
        Tuesday = targetDayOfWeek.Contains("tuesday") ? true : false,
        Wednesday = targetDayOfWeek.Contains("wednesday") ? true : false,
        Thursday = targetDayOfWeek.Contains("thursday") ? true : false,
        Friday = targetDayOfWeek.Contains("friday") ? true : false,
        Saturday = true
      };
      using (ApplicationContext db = new ApplicationContext())
      {
        db.Preferences.Add(usrPref);
        db.SaveChanges();
        //Рефакторинг
        //db.Database.ExecuteSqlRaw(insertQuery);
      }
      var data = new
      {
        channel_id = channel,
        message = msg,
      };
      await ToMattermost.PutReactionPost(id, "done2", BotID);
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
    }

    /// <summary>
    /// Информация по содержащимся предпочтениям по дежурствам запрашивающему.
    /// </summary>
    /// <param name="channel">Id канала прямых сообщений пользователя, от которого пришла команда.</param>
    /// <param name="id">Id сообщения этого канала с пришедшей командой.</param>
    /// <param name="processedRecords">Список с ID обработанных сообщений.</param>
    private static async void CurrentPreferencesCmd(string channel, string id, List<string> processedRecords)
    {
      string msg = "Дни, в которые тебе предпочтительныее ставить дежурства: ";
      Preference pref;
      using (ApplicationContext db = new ApplicationContext())
      {
        int idUsr = db.DirectChannels.Where(x => x.Idchannel.ToLower().Equals(channel.ToLower())).Select(x => x.Iduser).FirstOrDefault();
        pref = db.Preferences.Where(x => x.Iduser == idUsr).FirstOrDefault();
        //Рефакторинг
        //var usr = FromSqlRaw($"SELECT * FROM directchannel WHERE idchannel = '{channel}'").FirstOrDefault();
        //pref = db.Preferences.FromSqlRaw($"SELECT * FROM preferences where iduser = {usr.Iduser}").FirstOrDefault();
      }
      if (pref == null)
      {
        msg = "В базе данных отсутствует информация о твоих предпочтениях по дежурствам";
      }
      else
      {
        if (pref.Monday)
        {
          msg += "понедельник, ";
        }
        if (pref.Tuesday)
        {
          msg += "вторник, ";
        }
        if (pref.Wednesday)
        {
          msg += "среда, ";
        }
        if (pref.Thursday)
        {
          msg += "четверг, ";
        }
        if (pref.Friday)
        {
          msg += "пятница, ";
        }
        if (pref.Saturday)
        {
          msg += "суббота, ";
        }
        if (pref.Sunday)
        {
          msg += "воскресенье, ";
        }
      }
      msg = msg.TrimEnd();
      msg = msg.TrimEnd(',');
      var data = new
      {
        channel_id = channel,
        message = msg,
      };
      await ToMattermost.PutReactionPost(id, "done2", BotID);
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
    }

    /// <summary>
    /// Формирование запрашиваемого графика.
    /// </summary>
    /// <param name="channel">Id канала прямых сообщений пользователя, от которого пришла команда.</param>
    /// <param name="id">Id сообщения этого канала с пришедшей командой.</param>
    /// <param name="processedRecords">Список с ID обработанных сообщений.</param>
    /// <param name="type">Тип запрашиваемых данных.</param>
    private static async void ScheduleCmd(string channel, string id, List<string> processedRecords, string type)
    {
      string fileName = ""; // генерация графика дежурств в эксельку
      switch (type)
      {
        case "duty":
          fileName = GenerateExcelFile.GenerateSchedule();
          break;
        case "vacation":
          fileName = GenerateExcelFile.GenerateVacation();
          break;
        case "congratulations":
          fileName = GenerateExcelFile.GenerateHappy();
          break;
        default:
          return;
      }
      string msg = "Запрашиваемые данные за текущий год в формате таблицы Excel";
      List<string> idFilesInMM = new List<string>
            {
                await ToMattermost.UploadScheduleFile(fileName, channel)
            };
      var data = new
      {
        channel_id = channel,
        message = msg,
        file_ids = idFilesInMM,
      };
      await ToMattermost.PostMsgWithFilesAsync(data);
      await ToMattermost.PutReactionPost(id, "done2", BotID);
    }

    /// <summary>
    /// Информация по дежурным и количеству дежурств.
    /// </summary>
    /// <param name="channel">Id канала прямых сообщений пользователя, от которого пришла команда.</param>
    /// <param name="id">Id сообщения этого канала с пришедшей командой.</param>
    /// <param name="processedRecords">Список с ID обработанных сообщений.</param>
    private static async void GenerateRating(string channel, string id, List<string> processedRecords)
    {
      List<UsersList> dutyList = new List<UsersList> { };
      List<string> employees = new List<string>();
      int index = 1;
      string message = $"Количество дежурств по состоянию на {DateTime.Now}:{Environment.NewLine}";
      using (ApplicationContext db = new ApplicationContext())
      {
        var login = db.Users.Where(x => x.Employee_SPD && !x.Intern).ToList();
        //Рефакторинг
        //var login = db.Users.FromSqlRaw("SELECT * FROM users where Employee_SPD is true and intern is false").ToList();
        foreach (User u in login)
        {
          if (u.Login.ToLower().Equals(Config.EternalDuty.ToLower()))
            continue;
          var startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
          var endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31);
          int tmpShiftsNumber = db.DutyHistorys.Where(x => x.Iduser == u.Id && x.Date >= startYear && x.Date < endYear).Count();
          //Рефакторинг
          //int tmpShiftsNumber = db.DutyHistorys.FromSqlRaw($"SELECT id FROM DutyHistory " +
          //    $"where iduser = {u.Id} and date between '{startYear}' and '{endYear}'").Count();
          //if (!u.Login.ToLower().Equals(Config.EternalDuty.ToLower()))
          dutyList.Add(new UsersList(u.Login, tmpShiftsNumber, u.Team, u.Fio));
        }
        dutyList = dutyList.OrderBy(itm => itm.shiftsNumber).ToList();
      }
      foreach (var duty in dutyList)
      {
        if (duty.shiftsNumber != 0)
        {
          message += index + ". " + duty.fio.Remove(duty.fio.LastIndexOf(" ")) + " - " + duty.shiftsNumber + "\n\r";
          index++;
        }
      }
      var data = new
      {
        channel_id = channel,
        message = message
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(id, "done2", BotID);
    }

    /// <summary>
    /// Формирует возможные варианты для замены дежурного.
    /// </summary>
    /// <param name="channel">Id канала прямых сообщений пользователя, от которого пришла команда.</param>
    /// <param name="id">Id сообщения этого канала с пришедшей командой.</param>
    /// <param name="processedRecords">Список с ID обработанных сообщений.</param>
    /// <returns></returns>
    private static async Task DutyChangeOptions(string channel, string id, List<string> processedRecords)
    {
      DateTime endDateOfWeek = calculation.GetEndDateOfWeek();
      DateTime startDateOfWeek = calculation.GetFirstDateOfTargetWeek(endDateOfWeek);
      List<string> employees = new List<string>();

      string message = "Доступные варианты замены в день твоего дежурства:" + Environment.NewLine;
      using (ApplicationContext db = new ApplicationContext())
      {
        User usr = db.Users
          .Where(x => x.Id ==
            db.DirectChannels
            .Where(x => x.Idchannel.ToLower().Equals(channel.ToLower()))
            .Select(x => x.Iduser)
            .FirstOrDefault())
          .FirstOrDefault();
        if (usr == null)
        {
          processedRecords.Add(id);
          await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
          await ToMattermost.MsgToDirectChannel(channel, ErrAuthorNotDuty, BotID);
          return;
        }
        //Рефакторинг
        //User usr = db.Users.FromSqlRaw($"SELECT * FROM users where id = (SELECT iduser FROM directchannel WHERE idchannel = '{channel}')").FirstOrDefault();
        var dutyDays = db.DutyHistorys
          .Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek && x.Iduser == usr.Id)
          .ToList();
        //Рефакторинг
        //var dutyDays = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
        //        "where date between '{0}' and '{1}' and iduser = (select id from users where login ILIKE '{2}')",
        //        startDateOfWeek, endDateOfWeek, authorMsg)).ToList();
        if (dutyDays.Count() == 0)
        {
          processedRecords.Add(id);
          await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
          await ToMattermost.MsgToDirectChannel(channel, ErrAuthorNotDuty, BotID);
          return;
        }
        DateTime dutyDay = DateTime.Today;
        foreach (var d in dutyDays)
        {
          if (dutyDay < d.Date)
          {
            dutyDay = d.Date;
          }
        }
        var users = db.Users.Where(x => x.Employee_SPD && x.Duty == true).ToList();
        //Рефакторинг
        //var users = db.Users.FromSqlRaw("select * from users where Employee_SPD is true and duty is true").ToList();
        foreach (var user in users)
        {
          employees.Add(user.Login);
        }
        users = db.Users.Where(x => x.Employee_SPD && x.Duty == true).ToList();
        var dutyHistory = db.DutyHistorys.Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek).ToList();
        var absence = db.Absences.Where(x => x.Date == dutyDay).ToList();
        //Рефакторинг
        //var dutyHistory = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
        //                    "where date between '{0}' and '{1}'", startDateOfWeek, endDateOfWeek)).ToList();
        //var absence = db.Absences.FromSqlRaw(string.Format("select * from absence where date = '{0}'", dutyDay)).ToList();
        var missingUsers = (from u in users
                            join a in absence on u.Id equals a.Iduser
                            select new { login = u.Login }).ToList();
        foreach (var miss in missingUsers)
        {
          if (employees.Contains(miss.login))
          {
            employees.Remove(miss.login);
          }
        }
        var dutyUsers = (from u in users
                         join d in dutyHistory on u.Id equals d.Iduser
                         select new { login = u.Login }).ToList();
        foreach (var duty in dutyUsers)
        {
          if (employees.Contains(duty.login))
          {
            employees.Remove(duty.login);
          }
        }
        foreach (var user in users)
        {
          if (employees.Contains(user.Login))
          {
            employees.Remove(user.Login);
            employees.Add(user.Fio);
          }
        }
      }
      employees.Sort();
      int index = 0;
      foreach (var employee in employees)
      {
        index++;
        message += index + ". " + employee + "\n\r";
      }

      var data = new
      {
        channel_id = channel,
        message = message,
      };
      await ToMattermost.PutReactionPost(id, "done2", BotID);
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="id">Id сообщения этого канала с пришедшей командой.</param>
    /// <param name="processedRecords">Список с ID обработанных сообщений.</param>
    /// <param name="previously">Требуется обновление информации предыдущего графика</param>
    internal static async void ReloadSchedule(string id, List<string> processedRecords, bool previously = false)
    {
      DateTime endDateOfWeek = calculation.GetEndDateOfWeek();
      if (previously)
      {
        endDateOfWeek = calculation.GetEndDateOfWeek(calculation.GetFirstDateOfTargetWeek(endDateOfWeek).AddDays(-1));
      }
      DateTime startDateOfWeek = calculation.GetFirstDateOfTargetWeek(endDateOfWeek);
      List<string> intern = new List<string>();
      using (ApplicationContext db = new ApplicationContext())
      {
        var users = db.Users.Where(x => x.Employee_SPD).ToList();
        //Рефакторинг
        //var users = db.Users.FromSqlRaw("SELECT * FROM users where Employee_SPD is true").ToList();
        foreach (User u in users)
        {
          if (u.Intern)
          {
            intern.Add(u.Login.ToLower());
          }
        }
      }
      List<Tuple<DateTime, string, string>> DutyList = calculation.GetDutyList(intern, endDateOfWeek, startDateOfWeek);
      string post = GenerateMessage.GenerateDutyMsg(DutyList, true, previously);
      var data = new
      {
        is_pinned = true,
        message = post
      };
      string uriRewriteMessage;
      if (previously)
      {
        uriRewriteMessage = Config.ApiUrlPost + "/" + Interplay.PreviousMessageID + "/patch";
      }
      else
      {
        uriRewriteMessage = Config.ApiUrlPost + "/" + Interplay.MessageID + "/patch";
      }
      await ToMattermost.PutReactionPost(id, "done2", BotID);
      await ToMattermost.PutMsgAsync(uriRewriteMessage, data);
      processedRecords.Add(id);
    }
    /// <summary>
    /// Прибить сообщение бота по ID
    /// </summary>
    /// <param name="msg">Текст сообщения.</param>
    /// <param name="id">Id сообщения этого канала с пришедшей командой.</param>
    /// <param name="processedRecords">Список с ID обработанных сообщений.</param>
    private static async Task destroyMsg(string msg, string id, List<string> processedRecords)
    {
      msg = msg.Remove(0, msg.IndexOf(" ") + 1);
      bool status = ToMattermost.DestroyMsg(msg).Result;
      if (status)
      {
        await ToMattermost.PutReactionPost(id, "done2", BotID);
      }
      else
      {
        await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
      }
    }

    /// <summary>
    /// Сформировать задачу на поздравление коллеги.
    /// </summary>
    /// <param name="msg">Текст входящего сообщения.</param>
    /// <param name="authorMsg">Автор сообщения.</param>
    /// <param name="channel">Id канала прямых сообщений пользователя, от которого пришла команда.</param>
    /// <param name="id">Id сообщения этого канала с пришедшей командой.</param>
    /// <param name="processedRecords">Список с ID обработанных сообщений.</param>
    private static async Task HappyBirthdayColleague(string msg, string authorMsg, string channel, string id, List<string> processedRecords)
    {
      DateTime startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
      DateTime endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31);
      string infoMsg = "";
      if (!msg.Contains('@'))
      {
        await ToMattermost.MsgToDirectChannel(channel, ErrMsg, BotID);
        await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
        processedRecords.Add(id);
        return;
      }
      string birthdayManLogin = msg.Remove(0, msg.IndexOf(" ")).Trim().TrimStart('@').ToLower();
      if (authorMsg.ToLower().Equals(birthdayManLogin.ToLower()))
      {
        await ToMattermost.MsgToDirectChannel(channel, ErrHappy, BotID);
        await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
        processedRecords.Add(id);
        return;
      }
      User birthdayManUsr;
      User author;
      List<BirthdayMessageTracking> countCongrat;
      Ru lang = new Ru();
      using (ApplicationContext db = new ApplicationContext())
      {
        //Рефакторинг
        //var users = db.Users.FromSqlRaw("SELECT * FROM users").Where(emp => emp.Employee_SPD == true).Select(emp => emp.Login.ToLower()).ToList();
        var users = db.Users.Where(emp => emp.Employee_SPD).Select(emp => emp.Login.ToLower()).ToList();
        if (!users.Contains(birthdayManLogin.ToLower()))
        {
          await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
          await ToMattermost.MsgToDirectChannel(channel, NotEmployeesSPD, BotID);
          processedRecords.Add(id);
          return;
        }
        //Рефакторинг
        //var targerUserId = db.Users.FromSqlRaw("SELECT * FROM users").Where(emp => emp.Login.ToLower().Equals(birthdayManLogin.ToLower())).Select(emp => emp.Id).FirstOrDefault();
        //var happyIgnore = db.HappyIgnores.FromSqlRaw("SELECT * FROM happyignore").Where(ignore => ignore.Iduser == targerUserId).FirstOrDefault();
        var targerUserId = db.Users
                           .Where(emp => emp.Login.ToLower().Equals(birthdayManLogin.ToLower()))
                           .Select(emp => emp.Id).FirstOrDefault();
        var happyIgnore = db.HappyIgnores.Where(ignore => ignore.Iduser == targerUserId).FirstOrDefault();
        if (happyIgnore != null)
        {
          if (!happyIgnore.NeedCongrat)
          {
            await ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
            await ToMattermost.MsgToDirectChannel(channel, "@" + birthdayManLogin + NotNeedCongrat, BotID);
            processedRecords.Add(id);
            return;
          }
        }
        //Рефакторинг
        birthdayManUsr = db.Users.Where(x => x.Login.ToLower().Equals(birthdayManLogin)).FirstOrDefault();
        author = db.Users.Where(x => x.Login.ToLower().Equals(authorMsg.ToLower())).FirstOrDefault();
        //birthdayManUsr = db.Users.FromSqlRaw($"SELECT * FROM users where login ilike '{birthdayManLogin}'").FirstOrDefault();
        //author = db.Users.FromSqlRaw($"SELECT * FROM users where login ilike '{authorMsg}'").FirstOrDefault();

        //преобразуем в ДР текущего года
        birthdayManUsr.Date_of_birth = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")),
            int.Parse(birthdayManUsr.Date_of_birth.ToString("MM")), int.Parse(birthdayManUsr.Date_of_birth.ToString("dd")));
        if (DateTime.Today >= birthdayManUsr.Date_of_birth)
        {
          birthdayManUsr.Date_of_birth = birthdayManUsr.Date_of_birth.AddYears(1);
        }
        countCongrat = db.BirthdayMessageTrackings
          .Where(x => x.idbirthdayman == birthdayManUsr.Id && x.inputdate >= startYear && x.inputdate <= endYear)
          .ToList();
        //Рефакторинг
        //countCongrat = db.BirthdayMessageTrackings.FromSqlRaw($"SELECT * FROM birthdaymessagetracking " +
        //    $"WHERE inputdate between '{startYear}' and '{endYear}'").
        //    Where(x => x.idbirthdayman == birthdayManUsr.Id).ToList();
      }
      if (birthdayManUsr.Login.ToLower().Equals(author.Login.ToLower()))
      {
        await ToMattermost.PutReactionPost(id, "skoratov", BotID);
        await ToMattermost.MsgToDirectChannel(channel, JokeMsg, BotID);
        processedRecords.Add(id);
        return;
      }
      var FamilyName = lang.Q(birthdayManUsr.Fio.Remove(birthdayManUsr.Fio.LastIndexOf(" ")));
      if (countCongrat.Count() != 0)
      {
        infoMsg = $"Готово, ты поздравяешь {FamilyName[3]} с днём рождения. " +
            $"День рождения будет {birthdayManUsr.Date_of_birth.ToString("dd.MM.yyyy")}.\r\n" +
            $"Задача на поздравление в ауре будет направлена тебе в ближайщее время";

        int idtrackingMsg = 0;
        using (ApplicationContext db = new ApplicationContext())
        {
          db.BirthdayMessageTrackings.Add(new BirthdayMessageTracking
          {
            iduser = author.Id,
            idbirthdayman = birthdayManUsr.Id,
            message = id,
            inputdate = DateTime.Now,
            status = true
          });
          db.SaveChanges();
          idtrackingMsg = db.BirthdayMessageTrackings
            .Where(x => x.message.ToLower().Equals(id.ToLower()))
            .Select(x => x.id)
            .FirstOrDefault();
          //Рефакторинг
          /*
          string insertQuery = $"INSERT INTO birthdaymessagetracking (iduser, idbirthdayman, message, inputdate, status) " +
              $"VALUES ({author.Id}, {birthdayManUsr.Id}, '{id}', '{DateTime.Now}', true)";
          db.Database.ExecuteSqlRaw(insertQuery);
          idtrackingMsg = db.BirthdayMessageTrackings.FromSqlRaw($"select * from birthdaymessagetracking " +
              $"where message = '{id}'").Select(x => x.id).FirstOrDefault();
          */
        }
        HappyBirthday.CreateNewAuraTask(author.IdAura, birthdayManUsr.Id, birthdayManUsr.Date_of_birth, idtrackingMsg);
        ToMattermost.PutReactionPost(id, "done2", BotID);
      }
      else
      {
        if (countCongrat.Where(x => x.status == true).Count() != 0)
        {
          infoMsg = $"В этом году за поздравление выбранного тобой коллеги назначен другой сотрудник.\r\n" +
              $"Если ты хочешь поздравить коллегу в следующем году, просто выполни команду повторно после дня его рождения.\r\n" +
              $"Желаю тебе хорошо провести время на поздравлении коллеги!";
          ToMattermost.PutReactionPost(id, "no_entry_sign", BotID);
        }
        else
        {
          DirectChannel tmpUser;
          var tmpCongrat = countCongrat.Where(x => x.status == null).FirstOrDefault();
          if (tmpCongrat != null)
          {
            using (ApplicationContext db = new ApplicationContext())
            {

              tmpUser = db.DirectChannels.FromSqlRaw("SELECT * FROM directchannel")
                  .Where(x => x.Iduser == tmpCongrat.iduser)
                  .FirstOrDefault();
            }
            string errorMsg = $"Не успел получить от тебя подтверждение вовремя, " +
                $"поздравлять {FamilyName[1]} вызвался {author.Fio.Remove(author.Fio.LastIndexOf(" "))}";
            var dataClose = new
            {
              channel_id = tmpUser.Idchannel,
              message = errorMsg,
            };
            await ToMattermost.PutReactionPost(tmpCongrat.message, "no_entry_sign", BotID);
            await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, dataClose, false);
            using (ApplicationContext db = new ApplicationContext())
            {
              db.BirthdayMessageTrackings.Remove(db.BirthdayMessageTrackings.Where(x => x.id == tmpCongrat.id).FirstOrDefault());
              db.SaveChanges();
            }
            //Рефакторинг
            /*
            string deleteQuery = $"DELETE FROM birthdaymessagetracking WHERE id = {tmpCongrat.id}";
            using (ApplicationContext db = new ApplicationContext())
            {
              db.Database.ExecuteSqlRaw(deleteQuery);
            }*/
          }

          infoMsg = $"Готово, ты поздравяешь {FamilyName[1]} с днём рождения. " +
              $"День рождения будет {birthdayManUsr.Date_of_birth}.\r\n" +
              $"Задача на поздравление в ауре будет направлена в ближайщее время";
          string insertQuery = $"INSERT INTO birthdaymessagetracking (iduser, idbirthdayman, message, inputdate, status) " +
              $"VALUES ({author.Id}, {birthdayManUsr.Id}, '{id}', '{DateTime.Now}', true)";
          int idtrackingMsg = 0;
          using (ApplicationContext db = new ApplicationContext())
          {
            db.Database.ExecuteSqlRaw(insertQuery);
            idtrackingMsg = db.BirthdayMessageTrackings.FromSqlRaw($"select * from birthdaymessagetracking " +
                $"where message = '{id}'").Select(x => x.id).FirstOrDefault();
          }
          HappyBirthday.CreateNewAuraTask(author.IdAura, birthdayManUsr.Id, birthdayManUsr.Date_of_birth, idtrackingMsg);
          ToMattermost.PutReactionPost(id, "done2", BotID);
        }
      }

      var data = new
      {
        channel_id = channel,
        message = infoMsg,
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
    }

    /// <summary>
    /// Шуточная команда, отправляет сообщений "Да ты заебал!" от имени бота указанному человеку.
    /// </summary>
    /// <param name="threadMessages">Список ID обработанных записей.</param>
    /// <param name="msg">Id сообщения.</param>
    /// <param name="currentMsg">Текст сообщения.</param>
    private static async void ZaebaCmd(List<string> threadMessages, string msg, string currentMsg, string author)
    {
      string message = "Да ты заебал!";
      string channel = "";
      User usr;
      Regex regexUsers = new Regex(@"@(\w*)");
      MatchCollection matchesUsers = regexUsers.Matches(currentMsg);
      if (matchesUsers.Count == 0)
      {
        await ToMattermost.PutReactionPost(msg, "skoratov", BotID);
        threadMessages.Add(msg);
        return;
      }
      string targetUser = matchesUsers[0].Value.ToString().ToLower().Trim('@');
      using (ApplicationContext db = new ApplicationContext())
      {
        usr = db.Users.Where(x => x.Login.ToLower().Equals(targetUser.ToLower())).FirstOrDefault();
        if (usr == null)
        {
          await ToMattermost.PutReactionPost(msg, "skoratov", BotID);
          threadMessages.Add(msg);
          return;
        }
        channel = db.DirectChannels.Where(x => x.Iduser == usr.Id)
              .Select(x => x.Idchannel)
              .FirstOrDefault();
        //Рефакторинг
        //channel = db.DirectChannels.FromSqlRaw($"SELECT * FROM directchannel " +
        //    $"where iduser = (select id from users where login ILIKE '{targetUser}')")
        //    .Select(x => x.Idchannel)
        //    .FirstOrDefault();
      }
      if (channel == null)
      {
        await ToMattermost.PutReactionPost(msg, "skoratov", BotID);
        threadMessages.Add(msg);
        return;
      }
      var data = new
      {
        channel_id = channel,
        message = message,
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(msg, "ed_dovolen", BotID);
      Logger.WriteDirectLog($"{author} попросил отправить бота сообщение {usr.Login} о том, что он его заебал.");
    }


    /// <summary>
    /// Ручное добавление больничного.
    /// </summary>
    /// <param name="channel">ID канала, откуда пришла команда</param>
    /// <param name="threadMessages">Список ID обработанных записей.</param>
    /// <param name="msg">Id сообщения.</param>
    /// <param name="currentMsg">Текст сообщения.</param>
    private static async void AbsenceCmd(string channel, List<string> threadMessages, string msg, string currentMsg)
    {
      int idAbsenceUser = 0;
      Regex regexUsers = new Regex(@"@(\w*)");
      MatchCollection matchesUsers = regexUsers.Matches(currentMsg);
      if (matchesUsers.Count == 0)
      {
        await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
        await ToMattermost.MsgToDirectChannel(channel, ErrCmdFormatMsg, BotID);
        threadMessages.Add(msg);
        return;
      }
      string targetUser = matchesUsers[0].Value.ToString().ToLower().Trim('@');
      currentMsg = regexUsers.Replace(currentMsg + " ", "").Trim();
      DateTime absenceDate;
      try
      {
        absenceDate = DateTime.Parse(currentMsg);
      }
      catch (Exception ex)
      {
        string errmsg = "Неверный формат команды, отказано";
        await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
        await ToMattermost.MsgToDirectChannel(channel, errmsg, BotID);
        threadMessages.Add(msg);
        return;
      }

      if ((absenceDate < DateTime.Today) || (absenceDate > DateTime.Today.AddDays(7)))
      {
        string errmsg = "Разрешается добавление больничного только на ближайщие 7 дней, включая сегодняшний день";
        await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
        await ToMattermost.MsgToDirectChannel(channel, errmsg, BotID);
        threadMessages.Add(msg);
        return;
      }

      using (ApplicationContext db = new ApplicationContext())
      {
        idAbsenceUser = db.Users.Where(x => x.Login.ToLower().Equals(targetUser.ToLower()))
          .Select(x => x.Id)
          .FirstOrDefault();
        //Рефакторинг
        //idAbsenceUser = db.Users.FromSqlRaw($"SELECT * FROM users " +
        //$"where login ILIKE '{targetUser}'")
        //.Select(x => x.Id)
        //.FirstOrDefault();
      }
      if (idAbsenceUser == 0)
      {
        await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
        await ToMattermost.MsgToDirectChannel(channel, ErrCmdFormatMsg, BotID);
        threadMessages.Add(msg);
        return;
      }
      using (ApplicationContext db = new ApplicationContext())
      {
        db.Absences.Add(new Absence
        {
          Date = absenceDate,
          Iduser = idAbsenceUser,
          type = "absence"
        });
        db.SaveChanges();
      }
      //Рефакторинг
      //using (ApplicationContext db = new ApplicationContext())
      //{
      //  string insertQuery = $"INSERT INTO absence (date, iduser, type) VALUES " +
      //      $"('{absenceDate.ToString("dd.MM.yyyy")}', {idAbsenceUser}, 'absence')";
      //  db.Database.ExecuteSqlRaw(insertQuery);
      //}
      var data = new
      {
        channel_id = channel,
        message = "Готово, информация о больничном внесена в БД",
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(msg, "done2", BotID);
      if (AuraSync.SearchMissing())
      {
        data = new
        {
          channel_id = channel,
          message = "Требуется обновление графика дежурств, имеются новые данные по отсутствию дежурных",
        };
        await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
        await AuraSync.UpdateDutySchedule();
        data = new
        {
          channel_id = channel,
          message = "График дежурств обновлен",
        };
        await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      }
      ToMattermost.PutReactionPost(msg, "done2", BotID);
      threadMessages.Add(msg);
    }

    /// <summary>
    /// Информация из стоп-листа
    /// </summary>
    /// <param name="channel">ID канала, откуда пришла команда</param>
    /// <param name="threadMessages">Список ID обработанных записей.</param>
    /// <param name="msg">Id сообщения.</param>

    private static async void ShowIgnoreCase(string channel, List<string> threadMessages, string msg)
    {
      List<HappyIgnore> ignoreCases;
      List<User> users;
      bool foundUsers = false;
      int index = 0;
      string text = "Список пользователей в стоп-листе:" + Environment.NewLine;
      using (ApplicationContext db = new ApplicationContext())
      {
        ignoreCases = db.HappyIgnores.FromSqlRaw($"SELECT * FROM happyignore").ToList();
        users = db.Users.FromSqlRaw($"SELECT * FROM users where Employee_SPD is true").ToList();
      }
      foreach (var ignoreCase in ignoreCases)
      {
        //не добавляем в сообщение, если оба кейса можно назначать)
        if (ignoreCase.NeedCongrat && ignoreCase.WillCongrat)
        {
          continue;
        }
        if (users.Any(x => x.Id == ignoreCase.Iduser))
        {
          foundUsers = true;
          index++;

          text += index + $". {users.Where(x => x.Id == ignoreCase.Iduser).Select(x => x.Fio).FirstOrDefault()}: " +
              $"назначать поздравляющим " +
              $"{(ignoreCase.WillCongrat ? "можно" : "нельзя")}, поздравлять с днем рождения " +
              $"{(ignoreCase.NeedCongrat ? "можно" : "нельзя")}" + Environment.NewLine;
        }
      }
      if (!foundUsers)
      {
        text = "Не найдены данные в стоп-листе по действующим сотрудникам, " +
            "все сотрудники принимают участие в поздравлении коллег и могут быть поздравлены коллегами";
      }
      var data = new
      {
        channel_id = channel,
        message = text,
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(msg, "done2", BotID);
    }

    //Классы для обработки добавления, изменения состояние пользователя:
    //(needCongrat) -можно ставить поздравлять или нельзя 
    //(willCongrat) - надо поздравлять или нет
    /// <summary>
    /// Добавление в стоп-лист по назначению ответственным за подравление и необходимости поздравлять человека.
    /// </summary>
    /// <param name="channel">ID канала, откуда пришла команда</param>
    /// <param name="threadMessages">Список ID обработанных записей.</param>
    /// <param name="msg">Id сообщения.</param>
    /// <param name="message">Текст сообзения</param>
    /// <param name="ignoreWillCase">Тип добавления в стоп-лист (назначать или не поздравлять)</param>
    private static async void AddRemoveIgnoreCaseHappy(string channel, string idMsg, List<string> threadMessages, string message, bool ignoreWillCase = true)
    {
      string text = "";
      Regex regexUsers = new Regex(@"@(\w*)");
      MatchCollection matchesUsers = regexUsers.Matches(message);
      if (matchesUsers.Count == 0)
      {
        await ToMattermost.PutReactionPost(idMsg, "skoratov", BotID);
        threadMessages.Add(idMsg);
        return;
      }
      string targetUser = matchesUsers[0].Value.ToString().ToLower().Trim('@');
      using (ApplicationContext db = new ApplicationContext())
      {
        string queryCase = "";
        var ignoreCases = db.HappyIgnores.ToList();
        var users = db.Users.Where(x => x.Employee_SPD).ToList();
        //Рефакторинг
        //var ignoreCases = db.HappyIgnores.FromSqlRaw($"SELECT * FROM happyignore").ToList();
        //var users = db.Users.FromSqlRaw($"SELECT * FROM users where Employee_SPD is true").ToList();
        if (users.Any(x => x.Login.ToLower().Equals(targetUser.ToLower())))
        {
          int idTargetUser = users.Where(x => x.Login.ToLower().Equals(targetUser.ToLower())).Select(x => x.Id).FirstOrDefault();
          if (ignoreCases.Any(x => x.Iduser == idTargetUser))
          {
            if (!ignoreWillCase)
            {
              db.HappyIgnores.Where(x => x.Iduser == idTargetUser).First().WillCongrat =
                !ignoreCases.Where(x => x.Iduser == idTargetUser).Select(x => x.WillCongrat).FirstOrDefault();
            }
            else
            {
              db.HappyIgnores.Where(x => x.Iduser == idTargetUser).First().NeedCongrat =
                !ignoreCases.Where(x => x.Iduser == idTargetUser).Select(x => x.NeedCongrat).FirstOrDefault();
            }
          }
          else
          {
            if (!ignoreWillCase)
            {
              db.HappyIgnores.Add(new HappyIgnore
              {
                Iduser = idTargetUser,
                WillCongrat = false
              });
            }
            else
            {
              db.HappyIgnores.Add(new HappyIgnore
              {
                Iduser = idTargetUser,
                NeedCongrat = false
              });
            }
          }
          db.SaveChanges();
          //Рефакторинг
          /*
          if (ignoreCases.Any(x => x.Iduser == idTargetUser))
          {
            if (!ignoreWillCase)
            {
              queryCase = $"update happyignore set " +
                  $"willcongrat = {!ignoreCases.Where(x => x.Iduser == idTargetUser).Select(x => x.WillCongrat).FirstOrDefault()} " +
                  $"WHERE iduser = {idTargetUser}";
            }
            else
            {
              queryCase = $"update happyignore set " +
                  $"needcongrat = {!ignoreCases.Where(x => x.Iduser == idTargetUser).Select(x => x.NeedCongrat).FirstOrDefault()} " +
                  $"WHERE iduser = {idTargetUser}";
            }
          }
          else
          {
            if (!ignoreWillCase)
            {
              queryCase = $"INSERT INTO happyignore (iduser, willcongrat) VALUES ('{idTargetUser}', false)";
            }
            else
            {
              queryCase = $"INSERT INTO happyignore (iduser, needcongrat) VALUES ('{idTargetUser}', false)";
            }
          }
          db.Database.ExecuteSqlRaw(queryCase);
          */
          await ToMattermost.PutReactionPost(idMsg, "done2", BotID);
        }
        else
        {
          text = "Указанный сотрудник не является действующим сотрудником отдела";
          var data = new
          {
            channel_id = channel,
            message = text,
          };
          await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
          await ToMattermost.PutReactionPost(idMsg, "no_entry_sign", BotID);
        }
      }
      threadMessages.Add(idMsg);
    }

    /// <summary>
    /// Информация по активным модулям бота.
    /// </summary>
    /// <param name="channel">ID канала, откуда пришла команда</param>
    /// <param name="threadMessages">Список ID обработанных записей.</param>
    /// <param name="msg">Id сообщения.</param>
    private static async void StatusCmd(string channel, List<string> threadMessages, string msg)
    {
      string message = $"Бот запущен: {Program.StartTime}{Environment.NewLine}";
      message += $"Текущий статус работы бота:{Environment.NewLine}";
      message += Config.ModuleAuraSync ?
          $"Модуль синхронизации с аурой подключен{Environment.NewLine}" :
          $"Модуль синхронизации с аурой отключен. Не работает:{Environment.NewLine}" +
          $"1. Получение актуального списка сотрудников из ауры.{Environment.NewLine}" +
          $"2. Получение списка больничных из ауры.{Environment.NewLine}" +
          $"3. Получение списка командировок из ауры.{Environment.NewLine}" +
          $"4. Получение графика отпусков из ауры.{Environment.NewLine}" +
          $"5. Получение календарей рабочего времени на год из ауры.{Environment.NewLine}" +
          $"6. Автоматическое изменение заболевшего дежурного.{Environment.NewLine}";
      message += Config.ModuleGenerateSchedule ?
          $"Модуль генерации графика дежурств подключен{Environment.NewLine}" :
          $"Модуль генерации графика дежурств отключен. Не работает:{Environment.NewLine}" +
          $"1. Генерация графика дежурств на новую неделю.{Environment.NewLine}";
      message += Config.ModuleInterplay ?
          $"Модуль отслеживания тредов графика подключен{Environment.NewLine}" :
          $"Модуль отслеживания тредов графика отключен. Не работает:{Environment.NewLine}" +
          $"1. Взаимодействие с ботом в крайних двух тредах графика дежурств.{Environment.NewLine}";
      message += Config.ModuleDirectMessage ?
          $"Модуль прямых сообщений подключен.{Environment.NewLine}" :
          $"Модуль прямых сообщений отключен. Не работает:{Environment.NewLine}" +
          $"1. Отслеживание сообщений в прямых диалогах с ботом.{Environment.NewLine}" +
          $"2. Нельзя получить график дежурств.{Environment.NewLine}" +
          $"3. Нельзя получить график поздравлений.{Environment.NewLine}" +
          $"4. Нельзя получить график отпусков.{Environment.NewLine}";
      message += Config.ModuleHappyBirthday ?
          $"Модуль поздравления с днём рождения подключен{Environment.NewLine}" :
          $"Модуль поздравления с днём рождения отключен. Не работает:{Environment.NewLine}" +
          $"1. Поиск именнинников в отделе.{Environment.NewLine}" +
          $"2. Отслеживание согласий на поздравление.{Environment.NewLine}" +
          $"3. Формирование задачи в ауре ответственному за поздравление.{Environment.NewLine}";


      var data = new
      {
        channel_id = channel,
        message = message,
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(msg, "done2", BotID);

    }

    /// <summary>
    /// Ручное изменение роли сотрудника в базе данных ТИМЛИД (ДА/НЕТ)
    /// </summary>
    /// <param name="channel">ID канала, откуда пришла команда</param>
    /// <param name="threadMessages">Список ID обработанных записей.</param>
    /// <param name="msg">Id сообщения.</param>
    /// <param name="currentMsg">Текст сообщения.</param>
    private static async void TeamleadCmd(string channel, List<string> threadMessages, string msg, string currentMsg)
    {
      //TODO: Запилить вывод информации о тимлидах
      User teamlead;
      Regex regexUsers = new Regex(@"@(\w*)");
      MatchCollection matchesUsers = regexUsers.Matches(currentMsg);
      if (matchesUsers.Count == 0)
      {
        var infomsg = "";
        using (ApplicationContext db = new ApplicationContext())
        {
          int index = 1;
          foreach (var usr in db.Users.Where(x => x.Teamlead).OrderBy(it => it.Team))
          {
            infomsg += $"{index}. Команда {usr.Team} - тимлид {usr.Fio};{Environment.NewLine}";
            index++;
          }
        }
        if (infomsg.Equals(""))
        {
          infomsg = "В базе бота отсутствует информация о тимлидах";
        }
        else
        {
          infomsg = "Список тимлидов по командам:" + Environment.NewLine + infomsg;
        }
        var text = new
        {
          channel_id = channel,
          message = infomsg,
        };
        await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, text, false);
        await ToMattermost.PutReactionPost(msg, "done2", BotID);
        threadMessages.Add(msg);
        return;
      }
      string targetUser = matchesUsers[0].Value.ToString().ToLower().Trim('@');
      currentMsg = regexUsers.Replace(currentMsg + " ", "").Trim();

      using (ApplicationContext db = new ApplicationContext())
      {
        teamlead = db.Users.Where(x => x.Login.ToLower().Equals(targetUser.ToLower()) && x.Employee_SPD).FirstOrDefault();
        //Рефакторинг
        //teamlead = db.Users.FromSqlRaw($"SELECT * FROM users " +
        //    $"where login ILIKE '{targetUser}' and employee_spd is true")
        //    .FirstOrDefault();
      }
      if (teamlead == null)
      {
        await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
        await ToMattermost.MsgToDirectChannel(channel, "Указанный сотрудник не найден в списке действующих сотрудников отдела", BotID);
        threadMessages.Add(msg);
        return;
      }
      using (ApplicationContext db = new ApplicationContext())
      {
        db.Users.Where(x => x.Id == teamlead.Id).First().Teamlead = !teamlead.Teamlead;
        if (!teamlead.Teamlead)
        {
          db.Users.Where(x => x.Id == teamlead.Id).First().Duty = false;
        }
        else
        {
          db.Users.Where(x => x.Id == teamlead.Id).First().Duty = true;
        }
        db.SaveChanges();
        //Рефакторинг
        /*
        string updateTeamLeadQuery = $"UPDATE users SET teamlead = {!teamlead.Teamlead} WHERE id = {teamlead.Id}";
        if (!teamlead.Teamlead)
        {
          string updateDutyQuery = $"UPDATE users SET duty = false WHERE id = {teamlead.Id}";
          db.Database.ExecuteSqlRaw(updateDutyQuery);
        }
        else
        {
          string updateDutyQuery = $"UPDATE users SET duty = true WHERE id = {teamlead.Id}";
          db.Database.ExecuteSqlRaw(updateDutyQuery);
        }
        db.Database.ExecuteSqlRaw(updateTeamLeadQuery);
        */
      }
      string message = "Готово, информация о тимлиде обновлена в БД";
      var data = new
      {
        channel_id = channel,
        message = message,
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(msg, "done2", BotID);

    }

    /// <summary>
    /// Обработка дублирующихся записей в БД бота
    /// </summary>
    private static async void removeAbsenceDouble()
    {
      using (ApplicationContext db = new ApplicationContext())
      {
        var users = db.Users.Select(x => x.Id).ToArray();
        foreach (var user in users)
        {
          var targetDate = new DateTime(2023, 09, 01);
          var endYear = new DateTime(2024, 01, 01);
          while (targetDate < endYear)
          {

            if (db.Absences.Where(x => x.Iduser == user && x.Date == targetDate).Count() > 1)
            {
              var absence = new Absence
              {
                Iduser = user,
                Date = targetDate,
                type = db.Absences.Where(x => x.Iduser == user && x.Date == targetDate).Select(x => x.type).FirstOrDefault()
              };
              db.Absences.RemoveRange(db.Absences.Where(x => x.Iduser == user && x.Date == targetDate));
              db.Absences.Add(absence);
              db.SaveChanges();
            }
            targetDate = targetDate.AddDays(1);
          }
        }
      }
    }
  }
}