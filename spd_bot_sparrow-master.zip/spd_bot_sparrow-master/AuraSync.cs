﻿using Microsoft.EntityFrameworkCore;
using NameCaseLib;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Information;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Channels;
using System.Threading.Tasks;
using static spd_bot_sparrow.AuraJson;

namespace spd_bot_sparrow
{
  internal class AuraSync
  {
    #region переменные
    private static string BotID { get { return Config.BotID; } }
    private static readonly List<string> spdTeams = new List<string>
        {
            "Sokongan",
            "СНГ",
            "АтЛас",
            "Бета",
            "ОГВ",
            "Аврора"
        };
    #endregion
    public static async void AuraSyncTask()
    {
      await Task.Run(() => StartSyncAura());
    }
    private static async Task StartSyncAura()
    {
#if DEBUG
      DateTime targetDateSyncWorkingCalendar = DateTime.Now;//test
      DateTime targetDateSyncEmployees = DateTime.Now;//test
      DateTime targetDateSyncAbsences = DateTime.Now;//test
      DateTime targetDateSyncVacation = DateTime.Now;//test
      DateTime targetDateSearchTeamWithoutLead = DateTime.Now;
#endif
#if !DEBUG
            DateTime targetDateSyncWorkingCalendar = DateTime.Today;
            DateTime targetDateSyncEmployees = DateTime.Today;
            DateTime targetDateSyncAbsences = DateTime.Today;
            DateTime targetDateSyncVacation = DateTime.Today;
						DateTime targetDateSearchTeamWithoutLead = DateTime.Today;
#endif
      Logger.WriteLog($"Синхронизации: календарь - {targetDateSyncWorkingCalendar}, " +
          $"пользователи - {targetDateSyncEmployees}, отсутствия - {targetDateSyncAbsences}");
      while (true)
      {
        //синхронизация календарей рабочего времени.
        if ((DateTime.Now >= targetDateSyncWorkingCalendar)
            && (DateTime.Now >= DateTime.Today.AddHours(5)) && (DateTime.Now <= DateTime.Today.AddHours(20)))
        {
          await Task.Run(() => SyncWorkingTimeCalendar());
          targetDateSyncWorkingCalendar = targetDateSyncWorkingCalendar.AddDays(7);
        }
        //Синхронизация сотрудников (создание новых в бд, актуализация данных, закрытие устаревших)
        if ((DateTime.Now >= targetDateSyncEmployees)
            && (DateTime.Now >= DateTime.Today.AddHours(6)) && (DateTime.Now <= DateTime.Today.AddHours(21)))
        {
          await Task.Run(() => SyncSpdEmployees());
          targetDateSyncEmployees = targetDateSyncEmployees.AddDays(1);
        }
        //поиск команд без тимлида, отправка уведомления ответственному за дежурства в отделе.
        using (ApplicationContext db = new ApplicationContext())
        {
          if ((DateTime.Now >= targetDateSearchTeamWithoutLead)
              && (DateTime.Now >= DateTime.Today.AddHours(10)) && (DateTime.Now <= DateTime.Today.AddHours(17))
              && db.Calendars.Where(x => x.Date == DateTime.Today).Select(x => x.Iswork).FirstOrDefault())
          {
            await Task.Run(() => SearchTeamWithoutLead());
            targetDateSearchTeamWithoutLead = DateTime.Today.AddDays(1).AddHours(10);
          }
        }
        //Задача на синхронизацию отсутствий (болезнь, отгул)
        if ((DateTime.Now >= targetDateSyncAbsences)
            && (DateTime.Now >= DateTime.Today.AddHours(7)) && (DateTime.Now <= DateTime.Today.AddHours(21)))
        {
          targetDateSyncAbsences = DateTime.Now.AddMinutes(60);
          await Task.Run(() => SyncAbsence());
        }
        //задача на синхронизацию отпусков
        if ((DateTime.Now >= targetDateSyncVacation)
            && (DateTime.Now >= DateTime.Today.AddHours(7).AddMinutes(15)) && (DateTime.Now <= DateTime.Today.AddHours(21)))
        {
          await Task.Run(() => SyncVacation());
          targetDateSyncVacation = DateTime.Now.AddDays(1);
        }

        //Thread.Sleep(60000); - пауза
        await Task.Delay(60000);
      }
    }

    /// <summary>
    /// синхронизатор календарей рабочих дней. Запускаем раз в неделю или при запуске бота
    /// </summary>
    private static async void SyncWorkingTimeCalendar()
    {
      Console.WriteLine($"{DateTime.Now}: Cинхронизация календарей рабочих дней начата.");
      Logger.WriteLog("Cинхронизация календарей рабочих дней начата.");
      List<DateTime> workingDaysInYear = new List<DateTime>();
      //string sqlQuery = "INSERT INTO calendar (date, iswork) VALUES ";
      string uri = Config.Aura + "IWorkingTimeCalendars";
      string auth = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(Config.AuraUser + ":" + Config.AuraPass));
      int idCalendarYear = 0;
      int countWorkingDaysInSparrowDataBase = 0;
      int targetYear = DateTime.Today.Year;
      DateTime startYear = new DateTime(targetYear, 1, 1);
      DateTime endYear = new DateTime(targetYear, 12, 31);

      //у тестовой ауры не строится цепочка сертификатов, не обращаем внимания
#if DEBUG
      HttpClientHandler clientHandler = new HttpClientHandler();
      clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
      HttpClient client = new HttpClient(clientHandler);
#endif
#if !DEBUG
            HttpClient client = new HttpClient();
#endif
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Basic " + auth);
      WorkingCalendarYears workingYears;
      try
      {
        workingYears = JsonSerializer.Deserialize<WorkingCalendarYears>((await client.GetStringAsync(uri)).ToString());
      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к сервисам интеграции при получении календарей рабочего времени по годам\n" +
        $"Текст ошибки:\n{ex}\n" +
        $"Синхронизация календарей рабочего времени по годам завершилась неудачно.\n");
        Console.WriteLine($"{DateTime.Now}: Синхронизация календарей рабочего времени по годам завершилась неудачно.");
        return;
      }

      foreach (var year in workingYears.value)
      {
        if (DateTime.Today.AddMonths(1).Year == (targetYear + 1))
        {
          targetYear++;
        }
        if ((year.Year == targetYear) && (!year.Name.Contains("(")) && (!year.Name.Contains(")")))
        {
          idCalendarYear = year.Id;
        }
      }
      uri = Config.Aura + "IWorkingTimeCalendars(" + idCalendarYear + ")?$select=id,name,year&$expand=Day($filter = Kind eq null)";
      WorkingCalendarDays workingCalendarDays;
      try
      {
        workingCalendarDays = JsonSerializer
            .Deserialize<WorkingCalendarDays>((await client.GetStringAsync(uri)).ToString());
      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к сервисам интеграции при получении календарей рабочего времени на текущий год\n" +
            $"Текст ошибки:\n{ex}\n" +
            $"Синхронизация календаря рабочего времени на {targetYear} завершилась неудачно.");
        Console.WriteLine($"{DateTime.Now}: Синхронизация календаря рабочего времени на {targetYear} завершилась неудачно.");
        return;
      }
      if (startYear.Year != targetYear)
      {
        startYear = startYear.AddYears(1);
      }
      if (endYear.Year != targetYear)
      {
        endYear = endYear.AddYears(1);
      }
      using (ApplicationContext db = new ApplicationContext())
      {
        countWorkingDaysInSparrowDataBase = db.Calendars.Where(x => x.Date >= startYear && x.Date <= endYear && x.Iswork).Count();
        //Рефакторинг
        //countWorkingDaysInSparrowDataBase = db.Calendars.FromSqlRaw($"SELECT * FROM calendar " +
        //    $"WHERE date BETWEEN '{startYear}' and '{endYear}' AND iswork is true").Count();
      }
      //подчистить таблицу, если общее количество рабочих дней расходится в ауре и базе
      if (countWorkingDaysInSparrowDataBase != workingCalendarDays.Day.Count())
      {
        using (ApplicationContext db = new ApplicationContext())
        {
          db.Calendars.RemoveRange(db.Calendars.Where(x => x.Date >= startYear && x.Date <= endYear));
          db.SaveChanges();
          //Рефакторинг
          //db.Database.ExecuteSqlRaw($"DELETE FROM calendar WHERE date BETWEEN '{startYear}' AND '{endYear}'");
        }
        workingDaysInYear.AddRange(workingCalendarDays.Day.Select(x => x.Day));

        using (ApplicationContext db = new ApplicationContext())
        {
          while (startYear <= endYear)
          {
            db.Calendars.Add(new Calendar
            {
              Date = startYear,
              Iswork = workingDaysInYear.Contains(startYear) ? true : false
            });
            startYear = startYear.AddDays(1);
          }
          db.SaveChanges();
        };
        //Рефакторинг
        /*
				foreach (var day in workingCalendarDays.Day)
				{
					workingDaysInYear.Add(day.Day);
					sqlQuery += $"('{day.Day.ToString("dd.MM.yyyy")}', 'true'),";
				}
				while (startYear <= endYear)
				{
					if (!workingDaysInYear.Contains(startYear))
						sqlQuery += $"('{startYear.ToString("dd.MM.yyyy")}', 'false'),";
					startYear = startYear.AddDays(1);
				}
				sqlQuery = sqlQuery.TrimEnd(',');
				using (ApplicationContext db = new ApplicationContext())
				{
					db.Database.ExecuteSqlRaw(sqlQuery);
				}*/
      }
      Console.WriteLine($"{DateTime.Now}: Cинхронизация календарей рабочих дней закончена успешно.");
      Logger.WriteLog("Cинхронизация календарей рабочих дней закончена успешно.");
    }

    /// <summary>
    /// синхронизатор новых и закрытых, делаем раз в сутки или при запуске бота, чаще не требуется
    /// </summary>
    private static async void SyncSpdEmployees()
    {
      Console.WriteLine($"{DateTime.Now}: Старт синхронизации сотрудников СПД с аурой");
      Logger.WriteLog("Старт синхронизации сотрудников СПД с аурой");
      SpdEmployees spdEmployees;
      List<User> newUser = new List<User>();
      List<int> auraEmployees = new List<int>();
      List<int> sparrowDatabaseEmployees = new List<int>();
      List<int> newEmployeesId = new List<int>();
      //string createQuery = "INSERT INTO users (login, fio, date_of_birth, employee_spd, duty, intern, team, idaura, rank) VALUES ";
      //string closeQuery = "UPDATE users SET employee_spd = false WHERE idaura in (";
      //string startUpdateQuery = "UPDATE users SET";
      //string endUpdateQuery = " WHERE idaura = ";
      //AdditionalStatus исчез из ауры, теперь нет допстатуса и не от куда брать тимлидов
      //string uri = Config.Aura + "IEmployees" +
      //    "?$select=Id,Name,email,login,rank,status,HireDate,AdditionalStatus" +
      //    "&$filter=Status eq 'Active' and contains(Department/Name, '" + Config.Department + "')" +
      //    "&$expand=Department($select=Name),MainTeam($select=Name),Person($select=DateOfBirth)";
      string uri = Config.Aura + "IEmployees" +
          "?$select=Id,Name,email,login,rank,status,HireDate" +
          "&$filter=Status eq 'Active' and contains(Department/Name, '" + Config.Department + "')" +
          "&$expand=Department($select=Name),MainTeam($select=Name),Person($select=DateOfBirth)";
      string auth = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(Config.AuraUser + ":" + Config.AuraPass));
      //у тестовой ауры не строится цепочка сертификатов, не обращаем внимания
#if DEBUG
      HttpClientHandler clientHandler = new HttpClientHandler();
      clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
      HttpClient client = new HttpClient(clientHandler);
#endif
#if !DEBUG
            HttpClient client = new HttpClient();
#endif
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Basic " + auth);
      try
      {
        spdEmployees = JsonSerializer.Deserialize<SpdEmployees>((await client.GetStringAsync(uri)).ToString());
      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к сервисам интеграции при получении списка сотрудников\n" +
            $"Текст ошибки:\n{ex}\n" +
            $"Синхронизация списка сотрудников СПД завершилась неудачно.");
        Console.WriteLine($"{DateTime.Now}: Синхронизация списка сотрудников СПД завершилась неудачно.");
        return;
      }
      foreach (var emp in spdEmployees.value)
      {
        auraEmployees.Add(emp.Id);
      }
      //синхроним новых и закрытых
      using (ApplicationContext db = new ApplicationContext())
      {
        bool isNewUsersInAura = false;
        bool isNeedClosedRecords = false;
        List<int> auraNewEmployees = new List<int>();
        List<int> sparrowDatabaseEmployeesForCloseRecord = new List<int>();
        var users = db.Users.ToList();
        //var users = db.Users.FromSqlRaw($"SELECT * FROM users").ToList();
        //пишем idaura из базы в список для дальнейщего поиска
        sparrowDatabaseEmployees.AddRange(users.Select(u => u.IdAura));
        sparrowDatabaseEmployeesForCloseRecord.AddRange(users.Select(u => u.IdAura));
        auraNewEmployees.AddRange(spdEmployees.value.Select(a => a.Id));
        //Рефакторинг
        /*
				foreach (var u in users)
				{
					sparrowDatabaseEmployees.Add(u.IdAura);
					sparrowDatabaseEmployeesForCloseRecord.Add(u.IdAura);
				}
				foreach (var auraId in auraEmployees)
				{
					auraNewEmployees.Add(auraId);
				}
				*/
        //закрываем пользака
        foreach (var sparrowEmployee in sparrowDatabaseEmployees)
        {
          //ищем пользователей, что отсутствуют в базе бота
          if (auraEmployees.Contains(sparrowEmployee))
          {
            auraNewEmployees.Remove(sparrowEmployee);
          }
        }
        foreach (var auraId in auraEmployees)
        {
          if (sparrowDatabaseEmployeesForCloseRecord.Contains(auraId))
          {
            sparrowDatabaseEmployeesForCloseRecord.Remove(auraId);
          }
        }
        if (sparrowDatabaseEmployeesForCloseRecord.Count > 0)
        {
          foreach (var closeRecord in sparrowDatabaseEmployeesForCloseRecord)
          {
            //TODO: фиксим лайфхаки от Гасимова.
            //db.Users.Where(x => x.IdAura == closeRecord).FirstOrDefault().Employee_SPD = false;
            var closedUser = db.Users.Where(x => x.IdAura == closeRecord).FirstOrDefault();
            if (closedUser == null)
              continue;
            closedUser.Employee_SPD = false;
            var congrats = db.BirthdayProcessings.Where(x => x.birthday > DateTime.Today && x.idbirthdayman == closedUser.Id).ToList();
            foreach (var congrat in congrats)
            {
              Logger.WriteLog($"Найдены задачи на поздравления людей, больше не являющихся сотрудниками отдела (" +
                $"{users.Where(x=> x.Id == congrat.idbirthdayman).Select(x=> x.Fio).FirstOrDefault()})");
              var tracks = db.BirthdayMessageTrackings.Where(x => x.id == congrat.idtracking).ToList();
              foreach (var track in tracks)
              {
                db.BirthdayMessageTrackings.Remove(track);
              }
              db.BirthdayProcessings.Remove(congrat);
            }
          }
          db.SaveChanges();
        }
        //формируем запрос на создание новеньких
        foreach (var u in spdEmployees.value)
        {
          if (auraNewEmployees.Contains(u.Id) && (u.MainTeam != null || u.HireDate <= DateTime.Today))
          {
            newUser.Add(new User
            {
              Login = u.Email.Remove(u.Email.LastIndexOf("@")),
              Fio = u.Name,
              Date_of_birth = u.Person.DateOfBirth,
              Employee_SPD = true,
              Duty = false,
              Intern = false,
              Team = u.MainTeam.Name,
              IdAura = u.Id,
              Rank = u.Rank
            });
          }
        }
        db.Users.AddRange(newUser);
        db.SaveChanges();
        users = db.Users.ToList();
        //пуляем запрос на создание новых пользаков
        //Рефакторинг
        /*
				if (auraNewEmployees.Count > 0)
				{
					db.SaveChanges();
				}
				//формируем запрос на закрытие записей сотрудников
				foreach (var closeRecord in sparrowDatabaseEmployeesForCloseRecord)
				{
					closeQuery += $"{closeRecord},";
					isNeedClosedRecords = true;
				}
				//пуляем запрос, если есть хоть 1 запись на закрытие
				if (isNeedClosedRecords)
				{
					closeQuery = closeQuery.TrimEnd(',');
					closeQuery += ')';
					db.Database.ExecuteSqlRaw(closeQuery);
				}

				//формируем запрос на создание новеньких
				foreach (var u in spdEmployees.value)
				{
					if (auraNewEmployees.Contains(u.Id))
					{
						if (u.MainTeam == null || u.HireDate > DateTime.Today)
						{
							continue;
						}
						createQuery += $"('{u.Email.Remove(u.Email.LastIndexOf("@"))}', '{u.Name}', " +
								$"'{u.Person.DateOfBirth.ToString("dd.MM.yyyy")}', 'true', 'false', 'false', " +
								$"'{u.MainTeam.Name}', '{u.Id}', '{u.Rank}'),";
						isNewUsersInAura = true;
					}
				}

				//пуляем запрос на создание новых пользаков
				if (isNewUsersInAura)
				{
					createQuery = createQuery.TrimEnd(',');
					db.Database.ExecuteSqlRaw(createQuery);
				}
				*/

        //перебираем данные ауры и сравниваем с данными бота, если отличаются - формируем запрос на обновление отличающихся полей
        foreach (var emp in spdEmployees.value)
        {
          if (emp.MainTeam == null || emp.HireDate > DateTime.Today)
          {
            continue;
          }
          //Рефакторинг
          //bool isNeedUpdateUser = false;
          //string sqlQuery = "" + startUpdateQuery;
          int index = users.FindIndex(user => user.IdAura == emp.Id);
          if (!users[index].Employee_SPD)
          {
            db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Employee_SPD = true;
            //Рефакторинг
            //sqlQuery += $" employee_spd = true,";
            //isNeedUpdateUser = true;
          }

          if (!users[index].Login.Equals(emp.Email.Remove(emp.Email.LastIndexOf("@"))))
          {
            db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Login = emp.Email.Remove(emp.Email.LastIndexOf("@"));
            //Рефакторинг
            //sqlQuery += $" login = '{emp.Email.Remove(emp.Email.LastIndexOf("@"))}',";
            //isNeedUpdateUser = true;
          }
          if (!users[index].Fio.Equals(emp.Name))
          {
            db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Fio = emp.Name;
            //Рефакторинг
            //sqlQuery += $" fio = '{emp.Name}',";
            //isNeedUpdateUser = true;
          }
          if (!users[index].Login.ToLower().Equals(Config.EternalDuty.ToLower()))
          {
            if ((emp.MainTeam != null) && (emp.MainTeam.Name != null) &&
                ((users[index].Team == null) || (!users[index].Team.Equals(emp.MainTeam.Name))))
            {
              db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Team = emp.MainTeam.Name;
              //Рефакторинг
              //sqlQuery += $" team = '{emp.MainTeam.Name}',";
              //isNeedUpdateUser = true;
            }
          }
          if ((emp.Rank == 0) && ((DateTime.Today - emp.HireDate).Days > 28) && (users[index].Rank.Equals(emp.Rank)))
          {
            db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Intern = emp.MainTeam.Name.ToLower().Equals("снг") ? false : true;
            //Рефакторинг
            /*
						if (emp.MainTeam.Name.ToLower().Equals("снг"))
						{
							sqlQuery += " intern = false,";
						}
						else
						{
							sqlQuery += " intern = true,";
						}
						isNeedUpdateUser = true;
						*/
          }
          //исчез допстатус
          //if ((emp.AdditionalStatus != null) && (users[index].Teamlead == false) && emp.AdditionalStatus.ToLower().Contains("тимлид"))
          //{
          //    sqlQuery += " teamlead = true,";
          //    isNeedUpdateUser = true;
          //}
          ////временная обработка для тимлидов
          //if ((emp.AdditionalStatus != null) && (users[index].Duty == null))
          //{
          //    sqlQuery += " duty = false,";
          //    isNeedUpdateUser = true;
          //}
          //обработка, если случайно изменится руководитель отдела.
          //if ((emp.AdditionalStatus == null) && (users[index].Duty != null))
          //{
          //    sqlQuery += " duty = null,";
          //    isNeedUpdateUser = true;
          //}
          if ((emp.MainTeam != null) && (emp.MainTeam.Name != null)
              && emp.MainTeam.Name.ToLower().Equals("снг"))
          {
            db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Duty = false;
            //Рефакторинг
            //sqlQuery += " duty = false,";
          }
          //формируем запрос на добвление дельты дежурств по отделу - выравниваем количество дежурств свежеаттетстованного сотрудника
          //и делаем его дежурным
          if ((emp.Rank == 2) && ((users[index].Rank == 1) || (users[index].Rank == 0)))
          {
            db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Duty = true;
            db.SaveChanges();
            //Рефакторинг
            //sqlQuery += " duty = true,";
            //isNeedUpdateUser = true;
            int summ = 0;
            int count = 0;
            var startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
            var endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31);
            foreach (var u in users)
            {
              if (u.Employee_SPD && (u.Duty == true) && (!u.Intern) && !u.Login.ToLower().Equals(Config.EternalDuty.ToLower()))
              {
                int tmpShiftsNumber = db.DutyHistorys.Where(x => x.Date >= startYear && x.Date <= endYear && x.Iduser == u.Id).Count();
                //Рефакторинг
                //int tmpShiftsNumber = db.DutyHistorys.FromSqlRaw($"SELECT id FROM DutyHistory " +
                //    $"where iduser = {u.Id} and date between '{startYear}' and '{endYear}'").Count();
                summ += tmpShiftsNumber;
                if (tmpShiftsNumber != 0)
                {
                  count++;
                }
              }
            }
            int targetUserCount = db.DutyHistorys.Where(x => x.Date >= startYear && x.Date <= endYear && x.Iduser == users[index].Id).Count();
            int delta = summ / count;
            delta = delta - targetUserCount + 1;
            for (int i = 0; i <= delta; i++)
            {
              db.DutyHistorys.Add(new DutyHistory
              {
                Date = startYear,
                Iduser = users[index].Id
              });
            }
            if (!db.Preferences.Any(x => x.Iduser == users[index].Id))
            {
              db.Preferences.Add(new Preference
              {
                Iduser = users[index].Id,
                Monday = true,
                Tuesday = true,
                Wednesday = true,
                Thursday = true,
                Friday = true,
                Saturday = true,
                Sunday = true
              });
            }
            if (!users[index].Rank.Equals(emp.Rank))
            {
              db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Intern = false;
              db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Rank = emp.Rank;
              //Рефакторинг
              //sqlQuery += " intern = false,";
              //sqlQuery += $" rank = '{emp.Rank}',";
              //isNeedUpdateUser = true;
            }
            //Рефакторинг
            /*
						int targetUserCount = db.DutyHistorys.FromSqlRaw($"SELECT id FROM DutyHistory " +
												$"where iduser = {users[index].Id} and date between '{startYear}' and '{endYear}'").Count();
						string insertQuery = $"INSERT INTO dutyhistory (date, iduser) VALUES";
						for (int i = 0; i <= delta; i++)
						{
							insertQuery += $" ('{startYear.ToString("dd.MM.yyyy")}', {users[index].Id}),";
						}
						insertQuery = insertQuery.TrimEnd(',');
						if (!db.Preferences.FromSqlRaw("select * from preferences").Any(x => x.Iduser == users[index].Id))
						{
							string updatePreference = $"insert into preferences (iduser, monday, tuesday, wednesday, thursday,friday, saturday, sunday) " +
							$"VALUES ({users[index].Id}, true,true,true,true, true,true,true)";
							db.Database.ExecuteSqlRaw(updatePreference);
						}
						if (delta > 0)
						{
							db.Database.ExecuteSqlRaw(insertQuery);
						}
					}
					//если надо обновиться - пуляем запрос
					if (isNeedUpdateUser)
					{
						sqlQuery = sqlQuery.TrimEnd(' ');
						sqlQuery = sqlQuery.TrimEnd(',');
						sqlQuery += endUpdateQuery + $"{emp.Id}";
						db.Database.ExecuteSqlRaw(sqlQuery);
					}
						*/
          }
          if (users[index].Rank != emp.Rank)
          {
            db.Users.Where(x => x.Id == users[index].Id).FirstOrDefault().Rank = emp.Rank;
            db.SaveChanges();
          }
        }
        db.SaveChanges();
      }
      Console.WriteLine($"{DateTime.Now}: Cинхронизация сотрудников СПД с аурой закончена успешно");
      Logger.WriteLog("Cинхронизация сотрудников СПД с аурой закончена успешно");
    }

    /// <summary>
    /// синхронизатор отсутствий работников СПД, отслеживаем раз в час
    /// </summary>
    private static async void SyncAbsence()
    {
      Console.WriteLine($"{DateTime.Now}: Старт синхронизации отсутствий работников");
      Logger.WriteLog("Старт синхронизации отсутствий работников");
      AbsenceEmployees EmployeeAbsences;
      WorkingCalendarYears workingYears;
      WorkingCalendarDays holidaysCurrentYears;
      WorkingCalendarDays holidaysNextYears;
      int idCalendarYear = 0;
      int idCalendarNextYear = 0;
      int targetYear = DateTime.Today.Year;
      DateTime startYear = new DateTime(targetYear, 1, 1);
      DateTime endYear = new DateTime(targetYear, 12, 31);
      List<DateTime> holidays = new List<DateTime>();
      string uriWorkingYears = Config.Aura + "IWorkingTimeCalendars";
      string auth = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(Config.AuraUser + ":" + Config.AuraPass));
#if DEBUG
      string uriAbcsence = Config.Aura + "IAbsences?$filter=End ge " +
          startYear.ToString("yyyy-MM-ddTHH:mm:ssZ") + " and " +
          "contains(Employee/Department/Name, '" + Config.Department + "')" +
          "&$expand=" +
          "Employee($select=Id,Name,Email;$expand=Department($select=Name))," +
          "AbsenceReason($select=Name,Note,Code)" +
          "&$orderby=Begin";
#endif
#if !DEBUG
            string uriAbcsence = Config.Aura + "IAbsences?$filter=End ge " +
                DateTime.Today.ToString("yyyy-MM-ddTHH:mm:ssZ") + " and " +
                "contains(Employee/Department/Name, '" + Config.Department + "')" +
                "&$expand=" +
                "Employee($select=Id,Name,Email;$expand=Department($select=Name))," +
                "AbsenceReason($select=Name,Note,Code)" +
                "&$orderby=Begin";
#endif
#if DEBUG
      //у тестовой ауры не строится цепочка сертификатов, не обращаем внимания
      HttpClientHandler clientHandler = new HttpClientHandler();
      clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
      HttpClient client = new HttpClient(clientHandler);
#endif
#if !DEBUG
            HttpClient client = new HttpClient();
#endif

      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Basic " + auth);

      try
      {
        workingYears = JsonSerializer.Deserialize<WorkingCalendarYears>((await client.GetStringAsync(uriWorkingYears)).ToString());
        EmployeeAbsences = JsonSerializer.Deserialize<AbsenceEmployees>((await client.GetStringAsync(uriAbcsence)).ToString());
      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к сервисам интеграции при получении списка отсутствий\n" +
            $"Текст ошибки:\n{ex}\n" +
            $"Синхронизация отсутствий работников завершилась неудачно.");
        Console.WriteLine($"{DateTime.Now}: Синхронизация отсутствий работников завершилась неудачно.");
        return;
      }

      foreach (var year in workingYears.value)
      {
        if ((year.Year == targetYear) && (!year.Name.Contains("(")) && (!year.Name.Contains(")")))
        {
          idCalendarYear = year.Id;
        }
        if ((year.Year == targetYear + 1) && (!year.Name.Contains("(")) && (!year.Name.Contains(")")))
        {
          idCalendarNextYear = year.Id;
        }
      }
      string uriCurrentHolidays = Config.Aura + "IWorkingTimeCalendars(" + idCalendarYear + ")" +
          "?$select=id,name,year&$expand=Day($filter = Kind eq 'Holiday')";
      string uriNextYearHolidays = Config.Aura + "IWorkingTimeCalendars(" + idCalendarNextYear + ")" +
          "?$select=id,name,year&$expand=Day($filter = Kind eq 'Holiday')";
      try
      {
        holidaysCurrentYears = JsonSerializer
            .Deserialize<WorkingCalendarDays>((await client.GetStringAsync(uriCurrentHolidays)).ToString());
        if (idCalendarNextYear != 0)
        {
          holidaysNextYears = JsonSerializer
          .Deserialize<WorkingCalendarDays>((await client.GetStringAsync(uriNextYearHolidays)).ToString());
        }
        else
        {
          holidaysNextYears = null;
        }

      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к сервисам интеграции при получении праздничных дней\n" +
            $"Текст ошибки:\n{ex}\n" +
            $"Синхронизация календаря рабочего времени на {targetYear} завершилась неудачно.");
        Console.WriteLine($"{DateTime.Now}: Синхронизация календаря рабочего времени на {targetYear} завершилась неудачно.");
        return;
      }
      foreach (var holiday in holidaysCurrentYears.Day)
      {
        holidays.Add(holiday.Day);
      }
      if (holidaysNextYears != null)
      {
        foreach (var holiday in holidaysNextYears.Day)
        {
          holidays.Add(holiday.Day);
        }
      }

      foreach (var empAbsence in EmployeeAbsences.value)
      {
        //string insertQuery = "INSERT INTO absence (date, iduser, type) VALUES ";
        int idUser = 0;
        string deleteQuery = "";
        //отпуска
        if (empAbsence.AbsenceReason.Name.Equals("Отпуск"))
        {
          int countHolidays = 0;
          DateTime inputDate = empAbsence.Begin;
          using (ApplicationContext db = new ApplicationContext())
          {
            //синхроним все отстуствия, все они пишутся как прочие

            //отпуска, работает через другой синхронизатор
            //if ((empAbsence.End - empAbsence.Begin).Days >= 5)
            //{
            //    countHolidays = db.Absences.FromSqlRaw($"SELECT * FROM absence " +
            //        $"WHERE date BETWEEN '{empAbsence.Begin}' and '{empAbsence.End}' " +
            //        $"AND iduser = (SELECT id FROM users WHERE idaura = {empAbsence.Employee.Id}) " +
            //        $"AND type = 'holiday'").Count();
            //}
            //else
            //{
            if ((empAbsence.End - empAbsence.Begin).Days < 7)
            {
              var user = db.Users.Where(x => x.IdAura == empAbsence.Employee.Id).FirstOrDefault();
              if (user == null)
              {
                Logger.WriteLog($"В базе данных бота не найден пользователь {empAbsence.Employee.Name}");
                continue;
              }
              countHolidays = db.Absences.Where(x => x.Date >= empAbsence.Begin && x.Date <= empAbsence.End
                                                && x.Iduser == user.Id && x.type.ToLower().Equals("other")).Count();
              //Рефакторинг
              //countHolidays = db.Absences.FromSqlRaw($"SELECT * FROM absence " +
              //    $"WHERE date BETWEEN '{empAbsence.Begin}' and '{empAbsence.End}' " +
              //    $"AND iduser = (SELECT id FROM users WHERE idaura = {empAbsence.Employee.Id}) " +
              //    $"AND type = 'other'").Count();
            }
          }
          while (inputDate <= empAbsence.End)
          {
            if (holidays.Contains(inputDate))
            {
              countHolidays++;
            }
            inputDate = inputDate.AddDays(1);
          }
          if (countHolidays != (empAbsence.End - empAbsence.Begin).Days + 1)
          {
            //отпуска, работает через другой синхронизатор
            //if ((empAbsence.End - empAbsence.Begin).Days >= 5)
            //{
            //    deleteQuery = $"DELETE FROM absence " +
            //        $"WHERE iduser = (SELECT id FROM users WHERE idaura = {empAbsence.Employee.Id}) " +
            //        $"AND date > '{empAbsence.Begin}' " +
            //        $"AND type = 'holiday'";
            //}
            //else
            //Рефакторинг
            //if ((empAbsence.End - empAbsence.Begin).Days < 7)
            //{
            //  deleteQuery = $"DELETE FROM absence " +
            //      $"WHERE iduser = (SELECT id FROM users WHERE idaura = {empAbsence.Employee.Id}) " +
            //      $"AND date > '{empAbsence.Begin}' " +
            //      $"AND type = 'other'";
            //}
            using (ApplicationContext db = new ApplicationContext())
            {
              var users = db.Users.Where(x => x.IdAura == empAbsence.Employee.Id).FirstOrDefault();
              if (users == null)
              {
                Logger.WriteLog($"В базе данных бота не найден пользователь {empAbsence.Employee.Name}");
                continue;
              }
              else
              {
                idUser = users.Id;
              }
              if ((empAbsence.End - empAbsence.Begin).Days < 7)
              {
                db.Absences.RemoveRange(db.Absences
                  .Where(x => x.Id == idUser && x.Date >= empAbsence.Begin && x.type.ToLower().Equals("other")));
                db.SaveChanges();
                //Рефакторинг
                //deleteQuery = $"DELETE FROM absence " +
                //    $"WHERE iduser = (SELECT id FROM users WHERE idaura = {empAbsence.Employee.Id}) " +
                //    $"AND date > '{empAbsence.Begin}' " +
                //    $"AND type = 'other'";
              }
              //Рефакторинг
              /*
							if (!deleteQuery.Equals(""))
							{
								db.Database.ExecuteSqlRaw(deleteQuery);
							}
							var users = db.Users.FromSqlRaw($"SELECT * FROM users WHERE idaura = {empAbsence.Employee.Id}").ToList();
							*/
            }
            //формируем запрос на вставку данных по отпускам/отгулам
            inputDate = empAbsence.Begin;
            var inputAbsences = new List<Absence>();
            while (inputDate <= empAbsence.End)
            {
              if (!holidays.Contains(inputDate))
              {
                //отпуска, работает через другой синхронизатор
                //if ((empAbsence.End - empAbsence.Begin).Days >= 5)
                //{
                //    insertQuery += $"('{inputDate.ToString("dd.MM.yyyy")}', {idUser}, 'holiday'),";
                //}
                //else
                //Рефакторинг
                /*
								if ((empAbsence.End - empAbsence.Begin).Days < 7)
								{
									insertQuery += $"('{inputDate.ToString("dd.MM.yyyy")}', {idUser}, 'other'),";
								}
								*/
                inputAbsences.Add(new Absence
                {
                  Date = inputDate,
                  Iduser = idUser,
                  type = "other"
                });
              }
              inputDate = inputDate.AddDays(1);
            }
            if (inputAbsences.Count > 0)
            {
              using (ApplicationContext db = new ApplicationContext())
              {
                db.Absences.AddRange(inputAbsences);
                db.SaveChanges();
              }
            }
            //Рефакторинг
            /*
						insertQuery = insertQuery.TrimEnd(',');
						if (!insertQuery.Equals("INSERT INTO absence (date, iduser, type) VALUES "))
						{
							using (ApplicationContext db = new ApplicationContext())
							{
								try
								{
									db.Database.ExecuteSqlRaw(insertQuery);
								}
								catch (Exception ex)
								{
									Logger.WriteLog($"Произошла ошибка при вставке данных по отпускам/отгулам в базу данных. Пользователя {empAbsence.Employee.Name}\n" +
											$"Текст ошибки: \n {ex}\n" +
											$"Текст текст запроса, на котором произошла ошибка: \n {insertQuery}");
								}
							}
						}*/
          }
        }

        //больничные absence
        if (empAbsence.AbsenceReason.Name.Equals("Больничный"))
        {
          int countAbsence = 0;
          DateTime inputDate = empAbsence.Begin;
          using (ApplicationContext db = new ApplicationContext())
          {
            //Рефакториг
            var user = db.Users.Where(x => x.IdAura == empAbsence.Employee.Id).FirstOrDefault();
            if (user == null)
            {
              Logger.WriteLog($"В базе данных бота не найден пользователь {empAbsence.Employee.Name}");
              continue;
            }
            countAbsence = db.Absences.Where(x => x.Date >= empAbsence.Begin && x.Date <= empAbsence.End
                                                && x.Iduser == user.Id && x.type.ToLower().Equals("absence")).Count();
            //Рефакторинг
            //countAbsence = db.Absences.FromSqlRaw($"SELECT * FROM absence " +
            //    $"WHERE date BETWEEN '{empAbsence.Begin}' and '{empAbsence.End}' " +
            //    $"AND iduser = (SELECT id FROM users WHERE idaura = {empAbsence.Employee.Id}) " +
            //    $"AND type = 'absence'").Count();
          }
          if (countAbsence != (empAbsence.End - empAbsence.Begin).Days + 1)
          {
            //Рефакторинг
            //deleteQuery = $"DELETE FROM absence " +
            //    $"WHERE iduser = (SELECT id FROM users WHERE idaura = {empAbsence.Employee.Id}) " +
            //    $"AND date > '{empAbsence.Begin}' " +
            //    $"AND type = 'absence'";
            using (ApplicationContext db = new ApplicationContext())
            {
              var users = db.Users.Where(x => x.IdAura == empAbsence.Employee.Id).FirstOrDefault();
              if (users == null)
              {
                Logger.WriteLog($"В базе данных бота не найден пользователь {empAbsence.Employee.Name}");
                continue;
              }
              else
              {
                idUser = users.Id;
              }
              db.Absences.RemoveRange(db.Absences
                                                .Where(x => x.Id == idUser
                                                        && x.Date >= empAbsence.Begin
                                                        && x.type.ToLower().Equals("absence")));
              db.SaveChanges();
              //Рефакторинг
              /*
							db.Database.ExecuteSqlRaw(deleteQuery);
							var users = db.Users.FromSqlRaw($"SELECT * FROM users WHERE idaura = {empAbsence.Employee.Id}").ToList();
							if (users.Count() == 0)
							{
								Logger.WriteLog($"В базе данных бота не найден пользователь {empAbsence.Employee.Name}");
								continue;
							}
							else
							{
								if (users.Count() > 1)
								{
									Logger.WriteLog($"В базе данных бота найдено больше одной записи с пользователем {empAbsence.Employee.Name}");
									continue;
								}
								if (users.Count() == 1)
								{
									idUser = users[0].Id;
								}
							}
							*/
            }

            //формируем запрос на вставку данных по болезни
            var inputAbsence = new List<Absence>();
            while (inputDate <= empAbsence.End)
            {
              inputAbsence.Add(new Absence
              {
                Date = inputDate,
                Iduser = idUser,
                type = "absence"
              });
              //Рефакторинг
              //insertQuery += $"('{inputDate.ToString("dd.MM.yyyy")}', {idUser}, 'absence'),";
              inputDate = inputDate.AddDays(1);
            }
            using (ApplicationContext db = new ApplicationContext())
            {
              db.Absences.AddRange(inputAbsence);
              db.SaveChanges();
            }
            //Рефакторинг
            //insertQuery = insertQuery.TrimEnd(',');
            /*using (ApplicationContext db = new ApplicationContext())
						{
							try
							{
								db.Database.ExecuteSqlRaw(insertQuery);
							}
							catch (Exception ex)
							{
								Logger.WriteLog($"Произошла ошибка при вставке данных по болезни в базу данных. Пользователя {empAbsence.Employee.Name}\n" +
										$"Текст ошибки: \n {ex}\n" +
										$"Текст текст запроса, на котором произошла ошибка: \n {insertQuery}");
							}
						}*/
          }
        }
        //прочие отсутствия other
        if (empAbsence.AbsenceReason.Name.Equals("Прочее"))
        {
          if (empAbsence.Begin.Hour.ToString().Equals("0") && empAbsence.End.Hour.ToString().Equals("0"))
          {
            //какой то код обработки
          }
        }
        //командировки errand
        if (empAbsence.AbsenceReason.Name.Equals("Командировка"))
        {
          int countAbsence = 0;
          DateTime inputDate = empAbsence.Begin;
          using (ApplicationContext db = new ApplicationContext())
          {
            //Рефакториг
            var user = db.Users.Where(x => x.IdAura == empAbsence.Employee.Id).FirstOrDefault();
            if (user == null)
            {
              Logger.WriteLog($"В базе данных бота не найден пользователь {empAbsence.Employee.Name}");
              continue;
            }
            else
            {
              idUser = user.Id;
            }
            countAbsence = db.Absences.Where(x => x.Date >= empAbsence.Begin && x.Date <= empAbsence.End
                                                && x.Iduser == user.Id && x.type.ToLower().Equals("errand")).Count();
            //countAbsence = db.Absences.FromSqlRaw($"SELECT * FROM absence " +
            //    $"WHERE date BETWEEN '{empAbsence.Begin}' and '{empAbsence.End}' " +
            //    $"AND iduser = (SELECT id FROM users WHERE idaura = {empAbsence.Employee.Id}) " +
            //    $"AND type = 'errand'").Count();
          }
          if (countAbsence != (empAbsence.End - empAbsence.Begin).Days + 1)
          {

            using (ApplicationContext db = new ApplicationContext())
            {
              db.Absences.RemoveRange(db.Absences
                                                .Where(x => x.Id == idUser
                                                        && x.Date >= empAbsence.Begin
                                                        && x.type.ToLower().Equals("errand")));
              db.SaveChanges();
              //Рефакторинг
              /*
							deleteQuery = $"DELETE FROM absence " +
								$"WHERE iduser = (SELECT id FROM users WHERE idaura = {empAbsence.Employee.Id}) " +
								$"AND date > '{empAbsence.Begin}' " +
								$"AND type = 'errand'";
							db.Database.ExecuteSqlRaw(deleteQuery);
							var users = db.Users.FromSqlRaw($"SELECT * FROM users WHERE idaura = {empAbsence.Employee.Id}").ToList();
							if (users.Count() == 0)
							{
								Logger.WriteLog($"В базе данных бота не найден пользователь {empAbsence.Employee.Name}");
								continue;
							}
							else
							{
								if (users.Count() > 1)
								{
									Logger.WriteLog($"В базе данных бота найдено больше одной записи с пользователем {empAbsence.Employee.Name}");
									continue;
								}
								if (users.Count() == 1)
								{
									idUser = users[0].Id;
								}
							}
							*/
            }
            //формируем запрос на вставку данных по болезни
            var inputAbsenses = new List<Absence>();
            while (inputDate <= empAbsence.End)
            {
              inputAbsenses.Add(new Absence
              {
                Date = inputDate,
                Iduser = idUser,
                type = "errand"
              });
              //Рефакторинг
              //insertQuery += $"('{inputDate.ToString("dd.MM.yyyy")}', {idUser}, 'errand'),";
              inputDate = inputDate.AddDays(1);
            }
            using (ApplicationContext db = new ApplicationContext())
            {
              db.Absences.AddRange(inputAbsenses);
              db.SaveChanges();
            }
            //Рефакторинг
            /*
						insertQuery = insertQuery.TrimEnd(',');
						using (ApplicationContext db = new ApplicationContext())
						{
							try
							{
								db.Database.ExecuteSqlRaw(insertQuery);
							}
							catch (Exception ex)
							{
								Logger.WriteLog($"Произошла ошибка при вставке данных по командировкам в базу данных. Пользователя {empAbsence.Employee.Name}\n" +
										$"Текст ошибки:\n{ex}\n" +
										$"Текст текст запроса, на котором произошла ошибка: \n {insertQuery}");
							}
						}
						*/
          }
        }
      }
      //окончание синхронизации, пишем в лог
      Console.WriteLine($"{DateTime.Now}: Cинхронизация отсутствий сотрудников СПД с аурой закончена успешно");
      Logger.WriteLog("Cинхронизация отсутствий сотрудников СПД с аурой закончена успешно, количество обработанных записей " + EmployeeAbsences.value.Count());
      if (SearchMissing())
      {
        Logger.WriteLog("Требуется обновление графика дежурств, имеются новые данные по отсутствию дежурных");
        await UpdateDutySchedule();
        Logger.WriteLog("График дежурств обновлен");
      }
    }

    /// <summary>
    /// Поиск дежурных, у которых появилось отсутствие
    /// </summary>
    /// <returns></returns>
    internal static bool SearchMissing()
    {
      DateTime endDateOfWeek = calculation.GetEndDateOfWeek();
      DateTime startDateOfWeek = calculation.GetFirstDateOfTargetWeek(endDateOfWeek);
      if (DateTime.Today > startDateOfWeek)
      {
        startDateOfWeek = DateTime.Today;
      }
      List<int> dutyList = new List<int>();
      using (ApplicationContext db = new ApplicationContext())
      {
        var dutyRecordInDutyHistory = db.DutyHistorys.Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek).ToList();
        //Рефакторинг
        //var dutyRecordInDutyHistory = db.DutyHistorys.FromSqlRaw
        //    (String.Format($"select * from dutyhistory " +
        //    $"where date between '{startDateOfWeek.ToString("dd.MM.yyyy")}' and '{endDateOfWeek.ToString("dd.MM.yyyy")}'")).ToList();
        foreach (var dutyDate in dutyRecordInDutyHistory)
        {
          dutyList.Add(dutyDate.Iduser);
        }
        while (startDateOfWeek <= endDateOfWeek)
        {
          foreach (var duty in dutyList)
          {
            int employeeAbsences = db.Absences.Where(x => x.Date == startDateOfWeek && x.Iduser == duty).Count();
            int employeeDutys = db.DutyHistorys.Where(x => x.Date == startDateOfWeek && x.Iduser == duty).Count();
            //Рефакторинг
            /*
						int employeeAbsences = db.Absences.FromSqlRaw
										(String.Format($"select * from absence " +
										$"where date = '{startDateOfWeek.ToString("dd.MM.yyyy")}' " +
										$"and iduser = {duty}")).Count();
						//добавил, что бы смотреть, дежурит ли в этот день человек
						int employeeDutys = db.DutyHistorys.FromSqlRaw
								(String.Format($"select * from dutyhistory " +
										$"where date = '{startDateOfWeek.ToString("dd.MM.yyyy")}' " +
										$"and iduser = {duty}")).Count();
						*/
            //если отсутствует в рассматриваемый день и должен дежурить, тогда надо перегенерировать график.
            if (employeeAbsences != 0 && employeeDutys != 0)
            {
              return true;
            }
          }
          startDateOfWeek = startDateOfWeek.AddDays(1);
        }
      }
      return false;
    }

    /// <summary>
    /// Обновить график дежурств
    /// </summary>
    /// <returns></returns>
    internal static async Task UpdateDutySchedule()
    {
      DateTime endDateOfWeek = calculation.GetEndDateOfWeek();
      DateTime startDateOfWeek = calculation.GetFirstDateOfTargetWeek(endDateOfWeek);
      DateTime startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
      DateTime endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31);
      List<Tuple<int, DateTime>> dutyList = new List<Tuple<int, DateTime>>();
      List<Tuple<int, int>> DutyListShifts = new List<Tuple<int, int>>();
      if (DateTime.Today > startDateOfWeek)
      {
        startDateOfWeek = DateTime.Today;
      }
      using (ApplicationContext db = new ApplicationContext())
      {
        var users = db.Users.ToList();
        var dutyRecordInDutyHistory = db.DutyHistorys.Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek).ToList();
        //Рефакторинг
        /*
				var dutyRecordInDutyHistory = db.DutyHistorys.FromSqlRaw
						(String.Format($"select * from dutyhistory " +
						$"where date between '{startDateOfWeek.ToString("dd.MM.yyyy")}' and '{endDateOfWeek.ToString("dd.MM.yyyy")}'")).ToList();
				var users = db.Users.FromSqlRaw("select * from users").ToList();
				*/
        foreach (var dutyDate in dutyRecordInDutyHistory)
        {
          dutyList.Add(new Tuple<int, DateTime>(dutyDate.Iduser, dutyDate.Date));
        }
        foreach (var duty in dutyList)
        {
          var employeeAbsences = db.Absences.Where(x => x.Date == duty.Item2 && x.Iduser == duty.Item1).ToList();
          //Рефакторинг
          //var employeeAbsences = db.Absences.FromSqlRaw(String.Format(
          //        ($"select * from absence where date = '{duty.Item2.ToString("dd.MM.yyyy")}' and iduser = {duty.Item1}"))).ToList();
          if (employeeAbsences.Count() == 0)
          {
            continue;
          }
          DutyListShifts.Clear();
          //удаляем к херам из дежурств больного/командированного/прогульщика
          db.DutyHistorys.RemoveRange(db.DutyHistorys.Where(x => x.Iduser == duty.Item1 && x.Date == duty.Item2));
          db.SaveChanges();
          //Рефакторинг
          /*
					string deleteQuery = $"DELETE FROM dutyhistory " +
										 $"WHERE iduser = {duty.Item1} " +
										 $"AND date = '{duty.Item2.ToString("dd.MM.yyyy")}'";
					db.Database.ExecuteSqlRaw(deleteQuery);
					*/
          //ищем кто может заменить в указанную дату человека
          List<int> employees = GetEmployees(startDateOfWeek, endDateOfWeek, duty);

          foreach (var emp in employees)
          {
            int tmpShiftsNumber = db.DutyHistorys.Where(x => x.Iduser == emp && x.Date >= startYear && x.Date <= endYear).Count();
            //Рефакторинг
            //int tmpShiftsNumber = db.DutyHistorys.FromSqlRaw($"SELECT id FROM DutyHistory " +
            //    $"where iduser = {emp} and date between '{startYear}' and '{endYear}'").Count();
            DutyListShifts.Add(new Tuple<int, int>(emp, tmpShiftsNumber));//id пользователя в БД и его количество дежурств за год
          }
          DutyListShifts = DutyListShifts.OrderBy(x => x.Item2).ToList();
          //Генерируем случайный номер для вставки
          Random rnd = new Random();
          //TODO: возможно, тут нужна доработка, что бы не ставить 1 дежурного 2 дня подряд. наверно забить на это надо, поменяются при необходимости
          int index = rnd.Next(0, DutyListShifts.Count() - 1);
          db.DutyHistorys.Add(new DutyHistory
          {
            Iduser = DutyListShifts[index].Item1,
            Date = duty.Item2
          });
          db.SaveChanges();
          //Рефакторинг
          /*
					string insertQuery = $"INSERT INTO dutyhistory (iduser, date)" +
										 $"VALUES ({DutyListShifts[index].Item1}, '{duty.Item2.ToString("dd.MM.yyyy")}' )";
					db.Database.ExecuteSqlRaw(insertQuery);
					*/
          List<string> intern = new List<string>();
          foreach (User u in users)
          {
            if (u.Employee_SPD && u.Intern)
            {
              intern.Add(u.Login.ToLower());
            }
          }
          var retiredDuty = db.Users.Where(x => x.Id == duty.Item1).ToList();
          var newDuty = db.Users.Where(x => x.Id == DutyListShifts[index].Item1).ToList();
          //Рефакторинг
          /*
					var retiredDuty = db.Users.FromSqlInterpolated($"SELECT * FROM users where id = {duty.Item1}").ToList();
					var newDuty = db.Users.FromSqlInterpolated($"SELECT * FROM users where id = {DutyListShifts[index].Item1}").ToList();
					*/
          List<Tuple<DateTime, string, string>> newDutyList = calculation.GetDutyList(intern, endDateOfWeek, calculation.GetFirstDateOfTargetWeek(endDateOfWeek));
          string post = GenerateMessage.GenerateDutyMsg(newDutyList, true);
          var data = new
          {
            is_pinned = true,
            message = post
          };
          Ru lang = new Ru();
          var tmpCase = lang.Q(retiredDuty[0].Fio);
          var gender = lang.GenderAutoDetect();
          string uriRewriteMessage = Config.ApiUrlPost + "/" + Interplay.MessageID + "/patch";
          ToMattermost.PutMsgAsync(uriRewriteMessage, data);
          await Task.Delay(100);
          string infoMsg = "@here Не может дежурить по объективным причинам @" + retiredDuty[0].Login +
              ", вместо " + ((gender == Gender.Man) ? "него" : "неё") + " назначается дежурным @" + newDuty[0].Login;
          ToMattermost.PutInfoMessage(infoMsg, BotID);
        }
      }
    }
    /// <summary>
    /// Поиск свободных людей, которые могут быть дежурными
    /// </summary>
    /// <param name="startDateOfWeek">начало недели</param>
    /// <param name="endDateOfWeek">конец недели</param>
    /// <param name="duty">отвалившийся дежурный</param>
    /// <param name="noBodyFree">признак, что нету свободных дежурных, используется в рекурсии, если не удалось найти свободных людей, которые не дежурят на текущей неделе, тогда отбираем из дежурящих</param>
    /// <returns>список ID людей, которые могут быть заменены</returns>
    private static List<int> GetEmployees(DateTime startDateOfWeek, DateTime endDateOfWeek, Tuple<int, DateTime> duty, bool noBodyFree = false)
    {
      List<int> employees = new List<int>();
      using (ApplicationContext db = new ApplicationContext())
      {
        var dutyEmployees = db.Users.Where(x => x.Employee_SPD && x.Duty == true).ToList();
        var users = db.Users.ToList();
        var dutyHistory = db.DutyHistorys.Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek).ToList();
        var absence = db.Absences.Where(x => x.Date == duty.Item2 || x.Date == DateTime.Today).ToList();
        //Рефакторинг
        //var dutyEmployees = db.Users.FromSqlRaw("SELECT * FROM users WHERE employee_spd is true and duty is true").ToList();
        //var users = db.Users.FromSqlRaw("select * from users").ToList();
        //var dutyHistory = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
        //                    "where date between '{0}' and '{1}'", startDateOfWeek, endDateOfWeek)).ToList();
        //var absence = db.Absences
        //  .FromSqlRaw(string.Format
        //  ("select * from absence where date in ('{0}', '{1}')", 
        //  duty.Item2.ToString("dd.MM.yyyy"), 
        //  DateTime.Now.ToString("dd.MM.yyyy"))).ToList();
        foreach (var d in dutyEmployees)
        {
          employees.Add(d.Id);
        }
        //добавил отбор и сегоднящнего дня, для проверки, что чел сегодня не отсутствует, иначе нельзя сказать уверенно, что чел не болеет и не продилит больничный

        var missingUsers = (from u in users
                            join a in absence on u.Id equals a.Iduser
                            select new { id = u.Id }).ToList();
        foreach (var miss in missingUsers)
        {
          if (employees.Contains(miss.id))
          {
            employees.Remove(miss.id);
          }
        }
        var dutyUsers = (from u in users
                         join d in dutyHistory on u.Id equals d.Iduser
                         select new { id = u.Id }).ToList();

        //если нету свободных людей, то не удаляем из списка уже дежурящих людей
        if (!noBodyFree)
        {
          foreach (var d in dutyUsers)
          {
            if (employees.Contains(d.id))
            {
              employees.Remove(d.id);
            }
          }
        }
      }
      if (employees.Count == 0)
      {
        employees = GetEmployees(startDateOfWeek, endDateOfWeek, duty, true);
      }
      return employees;
    }

    /// <summary>
    /// Синхронизация отпусков
    /// </summary>
    private static async void SyncVacation()
    {
      Logger.WriteLog("Старт синхронизации отпусков работников");
      int targetYear = DateTime.Today.Year;
      if (DateTime.Today.AddDays(18).Year == (targetYear + 1))
      {
        targetYear++;
      }
      int recordsProcessed = 0;
      DateTime startYear = new DateTime(targetYear, 1, 1);
      DateTime endYear = new DateTime(targetYear, 12, 31);
      List<DateTime> holidays = GetHolidays(targetYear).Result;
      Vacation empVacations;
      string auth = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(Config.AuraUser + ":" + Config.AuraPass));
#if DEBUG
      string uriVacation = Config.Aura +
          "IVacations?$select=Id,Status,PlanBegin,PlanEnd,FactBegin,FactEnd,VacationKind,Year,Employee" +
          "&$filter=Year eq " + targetYear + " " +
          "and status eq 'Active' " +
          "and PlanEnd ge " + startYear.ToString("yyyy-MM-ddTHH:mm:ssZ") + " " +
          "and contains(Employee/Department/Name, '" + Config.Department + "') " +
          "and VacationKind eq 'Vacation'" +
          "&$expand=Employee($select=Id,Name,Email;$expand=Department($select=Name))" +
          "&$orderby=PlanBegin";
#endif
#if !DEBUG
            string uriVacation = Config.Aura +
                "IVacations?$select=Id,Status,PlanBegin,PlanEnd,FactBegin,FactEnd,VacationKind,Year,Employee" +
                "&$filter=Year eq " + targetYear + " " +
                "and status eq 'Active' " +
                "and PlanEnd ge " + DateTime.Today.ToString("yyyy-MM-ddTHH:mm:ssZ") + " " +
                "and contains(Employee/Department/Name, '" + Config.Department + "') " +
                "and VacationKind eq 'Vacation'" +
                "&$expand=Employee($select=Id,Name,Email;$expand=Department($select=Name))" +
                "&$orderby=PlanBegin";
#endif
#if DEBUG
      //у тестовой ауры не строится цепочка сертификатов, не обращаем внимания
      HttpClientHandler clientHandler = new HttpClientHandler();
      clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
      HttpClient client = new HttpClient(clientHandler);
#endif
#if !DEBUG
            HttpClient client = new HttpClient();
#endif
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Basic " + auth);

      try
      {
        empVacations = JsonSerializer.Deserialize<Vacation>((await client.GetStringAsync(uriVacation)).ToString());
      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к сервисам интеграции при получении планируемых и фактических отпусков\n" +
            $"Текст ошибки:\n{ex}\n" +
            $"Синхронизация отпусков работников завершилась неудачно.");
        Console.WriteLine($"{DateTime.Now}: Синхронизация отпусков работников завершилась неудачно.");
        return;
      }

      foreach (var empVacation in empVacations.value)
      {
        int idUser = 0;
        int countHolidays = 0;
        DateTime startDate = (empVacation.FactBegin != null && empVacation.PlanBegin != empVacation.FactBegin ? (DateTime)empVacation.FactBegin : empVacation.PlanBegin);
        DateTime endDate = (empVacation.FactEnd != null && empVacation.PlanEnd != empVacation.FactEnd ? (DateTime)empVacation.FactEnd : empVacation.PlanEnd);
        DateTime inputDate = startDate;
        using (ApplicationContext db = new ApplicationContext())
        {
          idUser = db.Users.Where(x => x.IdAura == empVacation.Employee.Id)
            .Select(x => x.Id)
            .FirstOrDefault();
          //Рефакторинг
          //idUser = db.Users.FromSqlRaw($"SELECT * FROM users where idAura = {empVacation.Employee.Id}")
          //    .Select(x => x.Id)
          //    .FirstOrDefault();
          if (idUser == 0)
          {
            Logger.WriteLog($"Сотрудник {empVacation.Employee.Name} не найден в базе Бота, требуется синхронизация сотрудников. " +
                $"Данные об отпусках указанного сотрудника не внесены в базу Бота");
            continue;
          }
          countHolidays = db.Absences.Where(x => x.Iduser == idUser && x.Date >= startDate && x.Date <= endDate && x.type.ToLower().Equals("holiday"))
            .Count();
          //Рефакторинг
          //countHolidays = db.Absences.FromSqlRaw($"SELECT * FROM absence " +
          //    $"WHERE date BETWEEN '{startDate}' and '{endDate}' " +
          //    $"AND iduser = (SELECT id FROM users WHERE idaura = {empVacation.Employee.Id}) " +
          //    $"AND type = 'holiday'").Count();
          if (empVacation.FactBegin != null && empVacation.PlanBegin != empVacation.FactBegin)
          {
            int countOldStoris = db.Absences.Where(x => x.Iduser == idUser && x.Date >= empVacation.PlanBegin && x.Date <= empVacation.PlanEnd && x.type.ToLower().Equals("holiday"))
              .Count();
            //Рефакторинг
            //int countOldStoris = db.Absences.FromSqlRaw($"SELECT * FROM absence " +
            //    $"WHERE date BETWEEN '{empVacation.PlanBegin}' and '{empVacation.PlanEnd}' " +
            //    $"AND iduser = (SELECT id FROM users WHERE idaura = {empVacation.Employee.Id}) " +
            //    $"AND type = 'holiday'").Count();
            DateTime inputOldDate = empVacation.PlanBegin;
            while (inputOldDate <= empVacation.PlanEnd)
            {
              if (holidays.Contains(inputOldDate))
              {
                countOldStoris++;
              }
              inputOldDate = inputOldDate.AddDays(1);
            }
            if (countOldStoris == ((empVacation.PlanEnd - empVacation.PlanBegin).Days + 1))
            {
              db.Absences.RemoveRange(db.Absences.Where(x => x.Iduser == idUser && x.Date >= empVacation.PlanBegin && x.Date <= empVacation.PlanEnd && x.type.ToLower().Equals("holiday")));
              db.SaveChanges();
              //Рефакторинг
              /*
							string deleteQuery = $"DELETE FROM absence " +
											$"WHERE iduser = (SELECT id FROM users WHERE idaura = {empVacation.Employee.Id}) " +
											$"AND date between '{empVacation.PlanBegin}' and '{empVacation.PlanEnd}' " +
											$"AND type = 'holiday'";
							db.Database.ExecuteSqlRaw(deleteQuery);
							*/
            }
          }
        }
        while (inputDate <= endDate)
        {
          if (holidays.Contains(inputDate))
          {
            countHolidays++;
          }
          inputDate = inputDate.AddDays(1);
        }
        if (countHolidays != (endDate - startDate).Days + 1)
        {
          var inputHolidays = new List<Absence>();
          //Рефакторинг
          //string insertQuery = "INSERT INTO absence (date, iduser, type) VALUES ";
          while (startDate <= endDate)
          {
            if (!holidays.Contains(startDate))
            {
              inputHolidays.Add(new Absence
              {
                Date = startDate,
                Iduser = idUser,
                type = "holiday"
              });
              //Рефакторинг
              //insertQuery += $"('{startDate.ToString("dd.MM.yyyy")}', {idUser}, 'holiday'),";
            }
            startDate = startDate.AddDays(1);
          }
          //Рефакторинг
          //insertQuery = insertQuery.TrimEnd(',');
          using (ApplicationContext db = new ApplicationContext())
          {
            db.Absences.AddRange(inputHolidays);
            db.SaveChanges();
            //db.Database.ExecuteSqlRaw(insertQuery);
          }
          recordsProcessed++;
        }
      }
      Logger.WriteLog($"Синхронизация отпусков работников завершилось успешно, обработано записей: {recordsProcessed}");
    }

    /// <summary>
    /// Получить даты прадничных дней
    /// </summary>
    /// <param name="targetYear">Принимает на вход год</param>
    /// <returns>Возвращает список дат с прадничными днями по полученному году</returns>
    private static async Task<List<DateTime>> GetHolidays(int targetYear)
    {
      WorkingCalendarYears workingYears;
      WorkingCalendarDays holidaysTargetYears;
      int idCalendarTargetYear = 0;
      List<DateTime> holidays = new List<DateTime>();
      string uriWorkingYears = Config.Aura + "IWorkingTimeCalendars";
      string auth = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(Config.AuraUser + ":" + Config.AuraPass));
#if DEBUG
      //у тестовой ауры не строится цепочка сертификатов, не обращаем внимания
      HttpClientHandler clientHandler = new HttpClientHandler();
      clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
      HttpClient client = new HttpClient(clientHandler);
#endif
#if !DEBUG
            HttpClient client = new HttpClient();
#endif

      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Basic " + auth);

      try
      {
        workingYears = JsonSerializer.Deserialize<WorkingCalendarYears>((await client.GetStringAsync(uriWorkingYears)).ToString());
      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к сервисам интеграции при получении списка отсутствий\n" +
            $"Текст ошибки:\n{ex}\n" +
            $"Синхронизация отсутствий работников завершилась неудачно.");
        Console.WriteLine($"{DateTime.Now}: Синхронизация отсутствий работников завершилась неудачно.");
        return null;
      }

      foreach (var year in workingYears.value)
      {
        if ((year.Year == targetYear) && (!year.Name.Contains("(")) && (!year.Name.Contains(")")))
        {
          idCalendarTargetYear = year.Id;
        }
      }
      string uriCurrentHolidays = Config.Aura + "IWorkingTimeCalendars(" + idCalendarTargetYear + ")" +
          "?$select=id,name,year&$expand=Day($filter = Kind eq 'Holiday')";
      try
      {
        holidaysTargetYears = JsonSerializer
            .Deserialize<WorkingCalendarDays>((await client.GetStringAsync(uriCurrentHolidays)).ToString());
      }
      catch (Exception ex)
      {
        Logger.WriteLog($"Произошла ошибка при обращении к сервисам интеграции при получении праздничных дней\n" +
            $"Текст ошибки:\n{ex}\n" +
            $"Синхронизация календаря рабочего времени на {targetYear} завершилась неудачно.");
        Console.WriteLine($"{DateTime.Now}: Синхронизация календаря рабочего времени на {targetYear} завершилась неудачно.");
        return null;
      }
      foreach (var holiday in holidaysTargetYears.Day)
      {
        holidays.Add(holiday.Day);
      }
      return holidays;
    }
    /// <summary>
    /// синхронизатор календарей рабочих дней. Запускаем раз в неделю или при запуске бота
    /// </summary>
    private static async void SearchTeamWithoutLead()
    {
      Logger.WriteLog("Запущен поиск команд без тимлидов.");
      string text = "";
      string eternalDutyId = "";
      using (ApplicationContext db = new ApplicationContext())
      {
        var notTeamLogins = new List<string>()
        {
          Config.Supervisor.ToLower(),
          Config.EternalDuty.ToLower()
        };
        var teams = db.Users.Where(x => !notTeamLogins.Contains(x.Login.ToLower())).Select(x => x.Team).Distinct().ToList();
        foreach (var team in teams)
        {
          if (!db.Users.Where(x => x.Team.Equals(team) && x.Employee_SPD).Any(x => x.Teamlead))
            text += $"В базе данных бота для команды '{team}' отсутствует тимлид.{Environment.NewLine}";
        }
        if (!text.Equals(""))
        {
          eternalDutyId = db.DirectChannels.Where(x => x.Iduser == db.Users.Where(u => u.Login.ToLower().Equals(Config.EternalDuty.ToLower())).Select(u => u.Id).FirstOrDefault()).Select(x => x.Idchannel).FirstOrDefault();
        }
        else
        {
          Logger.WriteLog("Закончен поиск команд без тимлидов. Команд без тимлида не обнаружено.");
          return;
        }
      }
      if (eternalDutyId.Equals(""))
      {
        Logger.WriteLog("Закончен поиск команд без тимлидов. Не определен ответственный за дежурства в отделе.");
        return;
      }
      var infomsg = new
      {
        channel_id = eternalDutyId,
        message = text
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, infomsg, false);
      Logger.WriteLog("Закончен поиск команд без тимлидов. Ответветственному за дежурства отправлено уведомление о необходимости добавления информации о тимлиде команды.");
    }
  }
}