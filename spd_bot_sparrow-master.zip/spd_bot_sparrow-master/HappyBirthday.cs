﻿using Microsoft.EntityFrameworkCore;
using NameCaseLib;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using static spd_bot_sparrow.AuraJson;

namespace spd_bot_sparrow
{
  internal class HappyBirthday
  {
    private static string BotID { get { return Config.BotID; } }
    private static string AgreeMsg { get { return "Великолепно! Задача на поздравление отправлена тебе в АУРЕ"; } }
    private static string DisagreeMsg { get { return "Очень жаль, надеюсь в следующий раз ты согласишься поздравить коллегу с днем рождения!"; } }
    /// <summary>
    /// Положительные реакции.
    /// </summary>
    private static readonly List<string> allAgreeReactions = new List<string>
        {
            "heavy_check_mark",
            "ballot_box_with_check",
            "checkered_flag",
            "white_check_mark",
            "plus",
            "heavy_plus_sign",
            "ok",
            "ok_hand",
            "okay",
            "+1",
            "resolved"
        };
    /// <summary>
    /// Отрицательные реакции.
    /// </summary>
    private static readonly List<string> allDisagreeReactions = new List<string>
        {
            "minus",
            "heavy_minus_sign",
            "octagonal_sign",
            "black_square_for_stop",
            "x",
            "name_badge",
            "negative_squared_cross_mark",
        };

    //запуск асинхронника на поздравление
    public static async void TrackingBirthdays()
    {
      bool isWork = true;
      DateTime updateIsWorkToday = DateTime.Today.AddMinutes(30);
      DateTime targerSearchBirthday = DateTime.Today.AddHours(10);
      DateTime targetTrackingConsentTask = DateTime.Today.AddHours(9).AddMinutes(10);//prod
      DateTime targetDateUpdateChannels = DateTime.Today;
      DateTime targetDateProcessedRecordsClean = DateTime.Today;
      DateTime targetTrackingIgnoreCongrat = DateTime.Today.AddHours(10);
      DateTime targetTrackingProcessing = DateTime.Today.AddHours(8);
      DateTime targetTrackingDismissed = DateTime.Today.AddHours(6);
      List<string> directChannels = new List<string>();
      List<string> processedRecords = new List<string>();
      while (true)
      {
        if (DateTime.Now >= updateIsWorkToday)
        {
          using (ApplicationContext db = new ApplicationContext())
          {
            isWork = db.Calendars.Where(x => x.Date == DateTime.Today)
              .Select(x => x.Iswork)
                .FirstOrDefault();
            //Рефакторинг
            //isWork = db.Calendars.FromSqlRaw($"SELECT * FROM calendar WHERE date = '{DateTime.Today.ToString("dd.MM.yyyy")}'")
            //    .Select(x => x.Iswork)
            //    .FirstOrDefault();
          }
          updateIsWorkToday = DateTime.Today.AddDays(1);
          if (!isWork)
          {
            UpdateInputDateInWeekEnd();
          }
        }
        //поиск именинников
        if ((DateTime.Now >= targerSearchBirthday) &&
        (DateTime.Now >= DateTime.Today.AddHours(10)) && (DateTime.Now <= DateTime.Today.AddHours(15)) && isWork)
        {
          await Task.Run(() => SearchBirthday());
          targerSearchBirthday = DateTime.Today.AddDays(1).AddHours(10);
        }
        //отслеживание согласия на поздравление
        if ((DateTime.Now >= targetTrackingConsentTask)
            && (DateTime.Now >= DateTime.Today.AddHours(8)) && (DateTime.Now <= DateTime.Today.AddHours(20)))
        {
          await Task.Run(() => TrackingConsentTask());
          targetTrackingConsentTask = DateTime.Now.AddHours(1);
        }
        //отслеживание задач
        if ((DateTime.Now >= targetTrackingProcessing)
            && (DateTime.Now >= DateTime.Today.AddHours(9)) && (DateTime.Now <= DateTime.Today.AddHours(21)))
        {
          await Task.Run(() => TrackingProccessing());
          targetTrackingProcessing = DateTime.Now.AddHours(2);
        }
        //отслеживание количества отказов, метод не используется.
        /*
        if (isWork && (DateTime.Now >= DateTime.Today.AddHours(10))
            && (DateTime.Now <= DateTime.Today.AddHours(17)) && (DateTime.Now > targetTrackingIgnoreCongrat))
        {
            await TrackingIgnoreCongrat();
            targetTrackingIgnoreCongrat = targetTrackingIgnoreCongrat.AddDays(1);
        }
        */
        //отслеживание уволившихся
        if (DateTime.Now >= targetTrackingDismissed)
        {
          await Task.Run(() => TrackingDismissedBirthdayman());
          targetTrackingDismissed = DateTime.Today.AddDays(1).AddHours(6);
        }
        await Task.Delay(60000);//спим тупим что б цикл не молотил бесконечно и не нагружал проц
      }
    }

    /// <summary>
    /// Поиск ближайщих дней рождения сотрудников отдела.
    /// </summary>
    /// <returns></returns>
    private static async Task SearchBirthday()
    {
      Logger.WriteBirthdayLog($"Старт поиска именинников в отделе");
      int recordCount = 0;
      List<User> users;
      List<int> happyIgnores;
      int idCongartulatingEmployee = 0;
      using (ApplicationContext db = new ApplicationContext())
      {
        users = db.Users.Where(x => x.Employee_SPD).ToList();
        happyIgnores = db.HappyIgnores.Where(x => !x.NeedCongrat).Select(x => x.Iduser).ToList();
        //Рефакторинг
        //users = db.Users.FromSqlRaw("SELECT * FROM users WHERE employee_spd is true").ToList();
        //happyIgnores = db.HappyIgnores.FromSqlRaw("SELECT * FROM happyignore WHERE needcongrat is false").ToList().Select(x => x.Iduser).ToList();
        //удаляем тех сотрудников, которых не надо поздравлять (ищем в списке их id, если есть, то удаляем из списка юзеров запись)
        for (int index = users.Count() - 1; index >= 0; index--)
        {
          if (happyIgnores.Contains(users[index].Id))
          {
            users.RemoveAt(index);
          }
        }
      }
      foreach (var u in users)
      {
        u.Date_of_birth = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")),
            int.Parse(u.Date_of_birth.ToString("MM")), int.Parse(u.Date_of_birth.ToString("dd")));//преобразуем в ДР текущего года
        if (DateTime.Now >= u.Date_of_birth)
          u.Date_of_birth = u.Date_of_birth.AddYears(1);
      }
      foreach (var u in users.Where(x => x.Date_of_birth > DateTime.Today && x.Date_of_birth < DateTime.Today.AddDays(30)))
      {
        int inProcess = 0;
        using (ApplicationContext db = new ApplicationContext())
        {
          inProcess = db.BirthdayMessageTrackings.Where(x => x.idbirthdayman == u.Id
                                                        && x.status != false
                                                        && x.inputdate >= u.Date_of_birth.AddYears(-1)
                                                        && x.inputdate <= DateTime.Today.AddDays(30))
            .Count();
          //Рефакторинг
          //inProcess = db.BirthdayMessageTrackings.FromSqlRaw($"SELECT * FROM birthdaymessagetracking " +
          //    $"WHERE idbirthdayman = {u.Id} and status is not false " +
          //    $"and inputdate between '{u.Date_of_birth.AddYears(-1)}' and '{DateTime.Today.AddDays(30).ToString("dd.MM.yyyy")}'")
          //    .Count();
        }
        if (inProcess != 0)
        {
          continue;
        }
        recordCount++;
        string willCongrat = WillCongratilation(u.Id, u.Date_of_birth);
        Logger.WriteBirthdayLog($"Поздравлять с днем рождения {u.Fio} будет " +
            $"{users.Where(x => x.Login.ToLower().Equals(willCongrat.ToLower())).Select(x => x.Fio).FirstOrDefault()}");
        await GetConsentTask(willCongrat, u.Fio, u.Id, u.Date_of_birth);
      }
      Logger.WriteBirthdayLog($"Закончен поиск именинников в отделе, обработано записей: {recordCount}");
    }

    /// <summary>
    /// Поиск сотрудника, который будет организовывать поздравление.
    /// </summary>
    /// <param name="idBirthdayMan">Id именинника.</param>
    /// <param name="birthday">Дата дня рождения.</param>
    /// <param name="recurse">Номер рекурсивного вызова метода.</param>
    /// <returns>возвращает логин сотрудника, который будет заниматься поздравлением коллег.</returns>
    public static string WillCongratilation(int idBirthdayMan, DateTime birthday, int recurse = 0)
    {
      var startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
      var endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31);
      List<Tuple<string, int>> userCongrat = new List<Tuple<string, int>>();
      List<int> happyIgnores;
      using (ApplicationContext db = new ApplicationContext())
      {
        //Рефакторинг
        var users = db.Users.Where(x => x.Employee_SPD && x.Rank > 1).ToList();
        happyIgnores = db.HappyIgnores.Where(x => !x.WillCongrat).Select(x => x.Iduser).ToList();
        //var users = db.Users.FromSqlRaw("SELECT * FROM users WHERE employee_spd is true and rank > 1").ToList();
        //happyIgnores = db.HappyIgnores.FromSqlRaw("SELECT * FROM happyignore WHERE willcongrat is false").ToList().Select(x => x.Iduser).ToList();
        for (int index = users.Count() - 1; index >= 0; index--)
        {
          if (happyIgnores.Contains(users[index].Id))
          {
            users.RemoveAt(index);
          }
        }
        foreach (var u in users)
        {
          if (idBirthdayMan == u.Id) //не именнинник
          {
            continue;
          }
          int congrat = db.BirthdayProcessings.Where(x => x.birthday >= startYear && x.birthday <= endYear && x.iduser == u.IdAura).Count();
          int absenceBirthday = db.Absences.Where(x => x.Date >= birthday.AddDays(-3) && x.Date <= birthday.AddDays(3) && x.Iduser == u.Id).Count();
          int absenceToday = db.Absences.Where(x => x.Date == DateTime.Today && x.Iduser == u.Id).Count();
          int birthdayMsgTrack = db.BirthdayMessageTrackings.Where(x => x.iduser == u.Id && x.status == null).Count();
          int disagreeReaction = db.BirthdayMessageTrackings.Where(x => x.iduser == u.Id
                                                                   && x.idbirthdayman == idBirthdayMan
                                                                   && x.status == false
                                                                   && x.inputdate >= startYear
                                                                   && x.inputdate <= endYear).Count();
          //Рефакторинг
          /*
            int congrat = db.BirthdayProcessings.FromSqlRaw($"SELECT * FROM birthdayprocessing " +
              $"WHERE birthday between '{startYear}' and '{endYear}' and iduser = {u.IdAura}").Count();
          int absenceBirthday = db.Absences.FromSqlRaw($"SELECT * FROM absence " +
              $"WHERE date between '{birthday.AddDays(-3)}' and '{birthday.AddDays(3)}' and iduser = {u.Id}").Count();
          int absenceToday = db.Absences.FromSqlRaw($"SELECT * FROM absence " +
              $"WHERE date = '{DateTime.Today.ToString("dd.MM.yyyy")}' and iduser = {u.Id}").Count();
          int birthdayMsgTrack = db.BirthdayMessageTrackings.FromSqlRaw($"SELECT * FROM birthdaymessagetracking " +
              $"WHERE iduser = {u.Id} and status is null").Count();
          int disagreeReaction = db.BirthdayMessageTrackings.FromSqlRaw($"SELECT * FROM birthdaymessagetracking " +
              $"WHERE iduser = {u.Id} " +
              $"and idbirthdayman = {idBirthdayMan} " +
              $"and status is false " +
              $"and inputdate between '{startYear}' and '{endYear}'").Count();
          */
          if ((absenceToday == 0) && (absenceBirthday == 0)
              && (birthdayMsgTrack == 0) && (disagreeReaction == recurse))
          {
            userCongrat.Add(new Tuple<string, int>(u.Login, congrat)); // Логин : количество поздравлений за текущий год.
          }
        }
      }
      //если отобранных людей 0 - отправляем в рекурсию
      if (userCongrat.Count() == 0)
      {
        return WillCongratilation(idBirthdayMan, birthday, ++recurse);
      }
      int minValue = userCongrat.Min(x => x.Item2);
      List<Tuple<string, int>> userListMinCongrat = userCongrat.Where(x => x.Item2 == minValue).ToList();
      Random rng = new Random();
      return userListMinCongrat[rng.Next(0, userListMinCongrat.Count)].Item1;
    }

    /// <summary>
    /// Сообщение в ММ для получения согласия на организацию поздравления.
    /// </summary>
    /// <param name="loginWillCongrat">Логин поздравляющего.</param>
    /// <param name="birthdayMen">Именинник.</param>
    /// <param name="birthdayMenId">ID именинника.</param>
    /// <param name="birthday">Дата дня рождения в этом году.</param>
    /// <returns></returns>
    private static async Task GetConsentTask(string loginWillCongrat, string birthdayMen, int birthdayMenId, DateTime birthday)
    {
      HttpClient clientММ = new HttpClient();
      clientММ.DefaultRequestHeaders.Accept.Clear();
      clientММ.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      clientММ.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      string responsible = "";
      if (!loginWillCongrat.ToLower().Equals(Config.CongratulationsResponsible.ToLower()))
      {
        responsible = Config.CongratulationsResponsible.ToLower();
      }
      else
      {
        responsible = "chirkov_ro";
      }
      string msg = $"Наш коллега, {birthdayMen.Remove(birthdayMen.LastIndexOf(" "))}, празднует день рожденья {birthday.ToString("dd.MM.yyyy")}.\r\n" +
             $"Тебе выпала уникальная возможность организовать поздравление коллеги с днем рождения.\r\n" +
             $"Согласен ли ты взять на себя бремя поздравления коллеги?\r\n\r\n\r\n" +
             $"Для ответа необходимо поставить одну из следующих реакций под этим сообщением:\r\n" +
             $"Согласие: :heavy_check_mark:, :ballot_box_with_check:, :checkered_flag:, :white_check_mark:, " +
             $":plus:, :heavy_plus_sign:,:ok:, :ok_hand:, :okay:, :+1:,:resolved:\r\n" +
             $"В случае, если ты не хочешь или не можешь поздравить указанного коллегу, объясни причину " +
             $"своего отказа от поздравления в этом групповом диалоге @{responsible}.\r\n" +
             $"Если причина уважительная, @{responsible} выполнит текущее предложение с результатом отказ.\r\n" +
             $"Для отказа @{responsible} поставит одну из следующих реакций: :minus:, :heavy_minus_sign:, :octagonal_sign:, " +
             $":black_square_for_stop:, :x:, :name_badge:, :negative_squared_cross_mark:\r\n\r\n" +
             $"Отказ может поставить только ответственный, даже не пытайся смухлевать :smile:";
      User usr;
      DirectChannelInfo directInfo;
      List<UsersInfo> usersInfo;
      List<string> dialogList = new List<string>
            {
                BotID
            };
      List<string> userList = new List<string>
            {
                loginWillCongrat.ToLower(),
                responsible
            };
      try
      {
        var responseUsersList = await clientММ.PostAsJsonAsync(Config.ApiSearchUsersByName, userList);
        usersInfo = JArray.Parse(responseUsersList.Content.ReadAsStringAsync().Result).ToObject<List<UsersInfo>>();
      }
      catch (Exception ex)
      {
        Logger.WriteBirthdayLog("Произошла ошибка при обращении к api MatterMost. " +
        $"Текст ошибки:\r{ex}\r Обращение к API завершилось c ошибкой.");
        return;
      }
      foreach (var info in usersInfo)
      {
        dialogList.Add(info.id); //пользак
      }
      //создаем канал прямых сообщений на несколько человек
      try
      {
        var response = await clientММ.PostAsJsonAsync(Config.ApiUrlGroupChannel, dialogList);
        directInfo = JObject.Parse(response.Content.ReadAsStringAsync().Result).ToObject<DirectChannelInfo>();
      }
      catch (Exception ex)
      {
        Logger.WriteBirthdayLog("Произошла ошибка при обращении к api MatterMost\r" +
        $"Текст ошибки:\r{ex}\r Обращение к API завершилось c ошибкой.");
        return;
      }
      var data = new
      {
        channel_id = directInfo.id,
        message = msg
      };
      using (ApplicationContext db = new ApplicationContext())
      {
        usr = db.Users.Where(x => x.Login.ToLower().Equals(loginWillCongrat.ToLower())).FirstOrDefault();
        //Рефакторинг
        //usr = db.Users.FromSqlRaw($"SELECT * FROM users where login ilike '{loginWillCongrat}'").FirstOrDefault();
      }
      string msgId = await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      using (ApplicationContext db = new ApplicationContext())
      {
        db.BirthdayMessageTrackings.Add(new BirthdayMessageTracking
        {
          iduser = usr.Id,
          idbirthdayman = birthdayMenId,
          message = msgId,
          inputdate = DateTime.Now,
        });
        db.SaveChanges();
        //Рефакторинг
        //string insertQuery = $"INSERT INTO birthdaymessagetracking (iduser, idbirthdayman, message, inputdate) " +
        //    $"VALUES ({usr.Id}, {birthdayMenId}, '{msgId}', '{DateTime.Now}')";
        //db.Database.ExecuteSqlRaw(insertQuery);
      }
      Logger.WriteBirthdayLog($"Отправлено сообщение в групповой диалог с предложением поздравления {usr.Fio.Remove(usr.Fio.LastIndexOf(' '))}");
    }

    /// <summary>
    /// Создать групповой диалог с поздравляющим, ботом и ответственным за поздравление.
    /// </summary>
    /// <param name="loginWillCongrat">Логин поздравляющего.</param>
    /// <returns>ID группового диалога.</returns>
    private static async Task<string> GetGroupChannel(string loginWillCongrat)
    {
      HttpClient clientММ = new HttpClient();
      clientММ.DefaultRequestHeaders.Accept.Clear();
      clientММ.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      clientММ.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      DirectChannelInfo directInfo;
      List<UsersInfo> usersInfo;
      List<string> dialogList = new List<string>
            {
                BotID
            };
      List<string> userList = new List<string>
            {
                loginWillCongrat.ToLower(),
            };
      if (loginWillCongrat.ToLower().Equals(Config.CongratulationsResponsible.ToLower()))
      {
        userList.Add("chirkov_ro");
      }
      else
      {
        userList.Add(Config.CongratulationsResponsible.ToLower());
      }
      try
      {
        var responseUsersList = await clientММ.PostAsJsonAsync(Config.ApiSearchUsersByName, userList);
        usersInfo = JArray.Parse(responseUsersList.Content.ReadAsStringAsync().Result).ToObject<List<UsersInfo>>();
      }
      catch (Exception ex)
      {
        Logger.WriteBirthdayLog("Произошла ошибка при обращении к api MatterMost. " +
        $"Текст ошибки:\r{ex}\r Обращение к API завершилось c ошибкой.");
        return "";
      }
      foreach (var info in usersInfo)
      {
        dialogList.Add(info.id); //пользак
      }
      //создаем канал прямых сообщений на несколько человек
      try
      {
        var response = await clientММ.PostAsJsonAsync(Config.ApiUrlGroupChannel, dialogList);
        directInfo = JObject.Parse(response.Content.ReadAsStringAsync().Result).ToObject<DirectChannelInfo>();
      }
      catch (Exception ex)
      {
        Logger.WriteBirthdayLog("Произошла ошибка при обращении к api MatterMost\r" +
        $"Текст ошибки:\r{ex}\r Обращение к API завершилось c ошибкой.");
        return "";
      }
      return directInfo.id;
    }
    /// <summary>
    /// Отслеживание сообщения в ММ для получения согласия на организацию поздравления
    /// </summary>
    /// <returns></returns>
    private static async Task TrackingConsentTask()
    {
      Logger.WriteBirthdayLog("Старт задачи по отслеживанию реакций на сообщениях с предложением поздравить коллегу");
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      List<string> trackingMsgID = new List<string>();
      List<User> users;
      List<BirthdayMessageTracking> trackingMsg;
      using (ApplicationContext db = new ApplicationContext())
      {
        users = db.Users.Where(x => x.Employee_SPD).ToList();
        trackingMsg = db.BirthdayMessageTrackings.Where(x => x.status == null).ToList();
        //Рефакторинг
        //users = db.Users.FromSqlRaw("SELECT * FROM users WHERE employee_spd is true").ToList();
        //trackingMsg = db.BirthdayMessageTrackings.FromSqlRaw("SElECT * FROM birthdaymessagetracking WHERE status is null").ToList();
        foreach (var track in trackingMsg)
        {
          if (DateTime.Now > track.inputdate.AddDays(1).AddHours(2))
          {
            List<string> directChannel = new List<string>();
            db.BirthdayMessageTrackings.Where(x => x.id == track.id).FirstOrDefault().status = false;
            db.SaveChanges();
            //Рефакторинг
            //string updateQuery = $"UPDATE birthdaymessagetracking set status = false WHERE id = {track.id}";
            //db.Database.ExecuteSqlRaw(updateQuery);
            Logger.WriteBirthdayLog($"Пользователь с ID {track.iduser} не ответил вовремя на запрос поздравления. " +
                $"Запущен новый поиск поздравляюшего");
            string channel = GetGroupChannel(users.Where(x => x.Id == track.iduser).Select(x => x.Login).FirstOrDefault()).Result;
            if (channel.Equals(""))
            {
              continue;
            }
            var data = new
            {
              channel_id = channel,
              message = "Не дождался от тебя ответа в течении суток, очень жаль, предложу поздравить другого человека в следующий раз."
            };
            await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
            await ToMattermost.PutReactionPost(track.message, "no_entry_sign", BotID);
            await SearchBirthday();
            continue;
          }
          trackingMsgID.Add(track.message);
        }
      }
      foreach (var msgId in trackingMsgID)
      {
        if (!IsSPDEmployee(trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.iduser).FirstOrDefault())
            || !IsSPDEmployee(trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.idbirthdayman).FirstOrDefault()))
        {
          using (ApplicationContext db = new ApplicationContext())
          {
            db.BirthdayMessageTrackings.Remove(
              db.BirthdayMessageTrackings.Where(x => x.message == msgId).FirstOrDefault()
              );
            db.SaveChanges();
            //Рефакторинг
            //string updateQuery1 = $"DELETE FROM birthdaymessagetracking WHERE message = '{msgId}'";
            //db.Database.ExecuteSqlRaw(updateQuery1);
          }
          Logger.WriteBirthdayLog($"{users.Where(x => x.Id == trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.iduser).FirstOrDefault()).Select(x => x.Fio).FirstOrDefault()} " +
              $"больше не является сотрудником СПД." +
              $"Запущен новый поиск поздравляюшего");
          await SearchBirthday();
          continue;
        }
        string emojiName = "";
        string updateQuery = "";
        int targetUserId = trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.iduser).FirstOrDefault();
        int CongratulationsResponsible = users.Where(x => x.Login.ToLower().Equals(Config.CongratulationsResponsible.ToLower()))
            .Select(x => x.Id).FirstOrDefault();
        bool goodReaction = false;
        bool badReaction = false;
        JArray jsonReactions;
        string uriReactions = Config.ApiUrlPost + "/" + msgId + "/reactions";
        await Task.Delay(500);
        try
        {
          jsonReactions = JArray.Parse(await client.GetStringAsync(uriReactions));
        }
        catch (Exception)
        {
          continue;
        }
        foreach (var jString in jsonReactions)
        {
          dynamic jsonReaction = JObject.Parse(jString.ToString());
          emojiName = jsonReaction["emoji_name"];
          string tmpUserId = jsonReaction["user_id"];
          string emojiAuthor = ToMattermost.GetUserNameByID(tmpUserId).Result;
          int recipient = trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.iduser).FirstOrDefault();
          int emojiAuthorId = users.Where(x => x.Login.ToLower().Equals(emojiAuthor.ToLower()))
              .Select(x => x.Id).FirstOrDefault();
          if (recipient == CongratulationsResponsible)
          {
            CongratulationsResponsible = users.Where(x => x.Login.ToLower().Equals("chirkov_ro")).Select(x => x.Id).FirstOrDefault();
          }
          if (allAgreeReactions.Contains(emojiName) && (emojiAuthorId == targetUserId)) //если реакция поставлена положительная, то стартуем задачу
          {
            goodReaction = true;
          }
          if (allDisagreeReactions.Contains(emojiName) && (emojiAuthorId == CongratulationsResponsible))
          {
            badReaction = true;
          }
        }
        if (goodReaction) //если реакция поставлена положительная, то стартуем задачу
        {
          int iduser = trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.iduser).FirstOrDefault();
          int idUsrAura = users.Where(x => x.Id.Equals(iduser)).Select(x => x.IdAura).FirstOrDefault();
          int idbirthdayman = trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.idbirthdayman).FirstOrDefault();
          DateTime birthday = users.Where(x => x.Id.Equals(idbirthdayman)).Select(x => x.Date_of_birth).FirstOrDefault();
          birthday = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), int.Parse(birthday.ToString("MM")), int.Parse(birthday.ToString("dd")));
          if (DateTime.Now >= birthday)
          {
            birthday = birthday.AddYears(1);
          }
          using (ApplicationContext db = new ApplicationContext())
          {
            db.BirthdayMessageTrackings.Where(x => x.message.ToLower().Equals(msgId.ToLower())).FirstOrDefault().status = true;
            db.SaveChanges();
            //Рефакаторинг
            //updateQuery = $"UPDATE birthdaymessagetracking set status = true WHERE message = '{msgId}'";
            //db.Database.ExecuteSqlRaw(updateQuery);
          }
          await ToMattermost.PutReactionPost(msgId, "done2", BotID);
          Logger.WriteBirthdayLog($"{users.Where(x => x.Id.Equals(iduser)).Select(x => x.Fio).FirstOrDefault()} " +
              $"согласился поздравить коллегу {users.Where(x => x.Id.Equals(idbirthdayman)).Select(x => x.Fio).FirstOrDefault()}.");
          CreateNewAuraTask(idUsrAura, idbirthdayman, birthday, trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.id).FirstOrDefault());
        }
        if (!goodReaction && badReaction) //если реакция поставлена отрицательная - начинаем новую генерацию на создравление
        {
          int iduser = trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.iduser).FirstOrDefault();
          int idbirthdayman = trackingMsg.Where(x => x.message.Equals(msgId)).Select(x => x.idbirthdayman).FirstOrDefault();
          using (ApplicationContext db = new ApplicationContext())
          {
            db.BirthdayMessageTrackings.Where(x => x.message.ToLower().Equals(msgId.ToLower())).FirstOrDefault().status = false;
            db.SaveChanges();
            //Рефакторинг
            //updateQuery = $"UPDATE birthdaymessagetracking set status = false WHERE message = '{msgId}'";
            //db.Database.ExecuteSqlRaw(updateQuery);
          }
          await ToMattermost.PutReactionPost(msgId, "no_entry_sign", BotID);
          await SearchBirthday();
          Logger.WriteBirthdayLog($"{users.Where(x => x.Id.Equals(iduser)).Select(x => x.Fio).FirstOrDefault()} отказался поздравлять коллегу." +
              $"Запущен новый поиск поздравляюшего");
        }
      }
      Logger.WriteBirthdayLog("Завершена задача по отслеживанию реакций на сообщениях с предложением поздравить коллегу");
    }
    /// <summary>
    /// Апдейтим табличку с отслеживанием сообщений на согласие поздравлять коллегу, 
    /// если день окончания отслеживания попадает на выходной
    /// </summary>
    /// <returns></returns>
    private static async void UpdateInputDateInWeekEnd()
    {
      using (ApplicationContext db = new ApplicationContext())
      {
        var trackingMsg = db.BirthdayMessageTrackings.Where(x => x.status == null);
        //Рефакторинг
        //var trackingMsg = db.BirthdayMessageTrackings.FromSqlRaw("SElECT * FROM birthdaymessagetracking WHERE status is null").ToList();
        foreach (var track in trackingMsg)
        {
          track.inputdate = track.inputdate.AddDays(1);
          db.SaveChanges();
          //Рефакторинг
          //string updateQuery = $"UPDATE birthdaymessagetracking set inputdate = '{track.inputdate.AddDays(1)}' WHERE id = {track.id}";
          //db.Database.ExecuteSqlRaw(updateQuery);
        }
      }
    }

    /// <summary>
    /// Создания задачи на поздравление в ауре, отправляем задачу поздравляющему и уведомление ответственному за поздравления.
    /// </summary>
    /// <returns></returns>
    internal static async Task CreateNewAuraTask(int idUsrAura, int birthdayMenId, DateTime Birthday, int idTracking)
    {
      Logger.WriteBirthdayLog("Создаем задачу в ауре с поздравлением коллеги");
      string birthdayManFamilyName = "";
      Ru lang = new Ru();
      int idCongratMan = 0;
      using (ApplicationContext db = new ApplicationContext())
      {
        birthdayManFamilyName = db.Users.Where(x => x.Employee_SPD && x.Id == birthdayMenId).Select(x => x.Fio).FirstOrDefault();
        idCongratMan = db.Users
          .Where(x => x.Employee_SPD && x.Login.ToLower().Equals(Config.CongratulationsResponsible.ToLower()))
          .Select(x => x.IdAura)
          .FirstOrDefault();
        //Рефакторинг
        //birthdayManFamilyName = db.Users.FromSqlRaw($"SELECT * FROM users " +
        //  $"where employee_spd is true and id = {birthdayMenId}").Select(x => x.Fio).FirstOrDefault();
        //idCongratMan = db.Users.FromSqlRaw($"SELECT * FROM users where employee_spd is true")
        //    .Where(x => x.Login.ToLower().Equals(Config.CongratulationsResponsible.ToLower()))
        //    .Select(x => x.IdAura).FirstOrDefault();
      }
      birthdayManFamilyName = birthdayManFamilyName.Remove(birthdayManFamilyName.LastIndexOf(" "));
      var FamilyName = lang.Q(birthdayManFamilyName);
      string uri = Config.Aura + "ISimpleTasks?$expand=Texts";
      string auth = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(Config.AuraUser + ":" + Config.AuraPass));
#if DEBUG
      //у тестовой ауры не строится цепочка сертификатов, не обращаем внимания
      HttpClientHandler clientHandler = new HttpClientHandler();
      clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
      HttpClient client = new HttpClient(clientHandler);
#endif
#if !DEBUG
            HttpClient client = new HttpClient();
#endif
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Basic " + auth);
      //тело запроса к ауре на создание задачи
      var createTask = new
      {
        Subject = $"Поздравить {FamilyName[3]} с Днем Рождения ({Birthday.ToString("dd.MM.yyyy")})",
        Deadline = $"{Birthday.AddDays(14).AddHours(12).ToString("yyyy-MM-ddTHH:mm:ssZ")}",
        Importance = "High",
        NeedsReview = false,
        RouteSteps = new[]
          {
                    new
                    {
                        Deadline = $"{Birthday.AddDays(14).AddHours(12).ToString("yyyy-MM-ddTHH:mm:ssZ")}",
                        AssignmentType = "Assignment",
                        Performer = new
                        {
                            Id = idUsrAura
                        }
                    },
                    new
                    {
                        Deadline = $"{Birthday.AddDays(14).AddHours(12).ToString("yyyy-MM-ddTHH:mm:ssZ")}",
                        AssignmentType = "Notice",
                        Performer = new
                        {
                            Id = idCongratMan
                        }
                    }
                }
      };
      //текст задачи
      var textTask = new
      {
        Body = "План такой:\r\n\r\n" +
          $"1. Выясняешь, что {FamilyName[0].Remove(0, FamilyName[0].IndexOf(" ")).Trim()} хочет получить в подарок. В помощь есть еще Пул подарков DIRECTUM (https://people.directum.ru/gift). " +
          "Компания компенсирует часть суммы в соответствии с документом Положение о выплате различных компенсаций сотрудникам (https://aura.npo-comp.ru/Sungero?type=ceeeaa89-35bd-426e-b800-3663f53612a9&id=128906).\r\n" +
          "2. Придумываешь торжественно-развлекательную часть поздравления - желательно, чтобы было оригинально, " +
          "весело и не слишком затянуто по времени.\r\n" +
          "3. Согласовываешь с именинником дату и время поздравления.\r\n" +
          "4. Собираешь всех заблаговременно в аутлуке.\r\n" +
          "5. Поздравляешь.\r\n" +
          "Если возникнут какие-то вопросы, то обращайся к ответственному за поздравления коллег в отделе."
      };
      CreatedTask createdTask;
      try
      {
        var response = await client.PostAsync(uri, createTask.AsJson());
        createdTask = JObject.Parse(response.Content.ReadAsStringAsync().Result).ToObject<CreatedTask>();
        uri = Config.Aura + "ISimpleTasks(" + createdTask.Id + ")/Texts(" + createdTask.Texts[0].Id + ")";
        await client.PatchAsync(uri, textTask.AsJson());
        uri = Config.Aura + "Docflow/StartTask";
        var taskId = new { taskId = createdTask.Id };
        await client.PostAsync(uri, taskId.AsJson());
      }
      catch (Exception ex)
      {
        Logger.WriteBirthdayLog($"Произошла ошибка при обращении к сервисам интеграции при создании задачи\n" +
        $"Текст ошибки:\n{ex}\n" +
        $"Создание задачи завершилась неудачно.\n");
        return;
      }
      using (ApplicationContext db = new ApplicationContext())
      {
        db.BirthdayProcessings.Add(new BirthdayProcessing
        {
          iduser = idUsrAura,
          idbirthdayman = birthdayMenId,
          task = createdTask.Id,
          birthday = Birthday,
          complited = false,
          idtracking = idTracking
        });
        db.SaveChanges();
        //Рефакторинг
        //string insertQuery = $"INSERT INTO birthdayprocessing (iduser, idbirthdayman, task, birthday, complited, idtracking) " +
        //    $"VALUES ({idUsrAura}, {birthdayMenId}, {createdTask.Id}, '{Birthday}', false, {idtracking})";
        //db.Database.ExecuteSqlRaw(insertQuery);
      }
      Logger.WriteBirthdayLog("Задача отправлена.");
    }

    /// <summary>
    /// метод для отслеживания задачи на поздравление сотрудника, варианты: 
    /// 1. Если выполнена, то закрываем задачу. +
    /// 2. Если не выполнена, продолжаем отслеживание +
    /// 3. Если пропущен срок (MaxDeadLine), отправляем сообщение поздравляющему о пропуске сроков по задаче (варианты уведомления: почта, ММ)
    /// 4. Если пропущен срок более чем на 1 неделю: уведомляем ответственного за поздравления в отделе 
    /// </summary>
    /// <returns>Ничего не возвращает, хотя и может.</returns>
    private static async Task TrackingProccessing()
    {
      Logger.WriteBirthdayLog("Старт задачи по отслеживанию запущенных задач на поздравление");
      int workingTask = 0;
      string auth = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(Config.AuraUser + ":" + Config.AuraPass));//prod
#if DEBUG
      //у тестовой ауры не строится цепочка сертификатов, не обращаем внимания
      HttpClientHandler clientHandler = new HttpClientHandler();
      clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
      HttpClient client = new HttpClient(clientHandler);
#endif
#if !DEBUG
            HttpClient client = new HttpClient();
#endif
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Basic " + auth);
      HttpClient clientММ = new HttpClient();
      clientММ.DefaultRequestHeaders.Accept.Clear();
      clientММ.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      clientММ.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      List<BirthdayProcessing> taskList = new List<BirthdayProcessing>();
      List<User> users = new List<User>();
      using (ApplicationContext db = new ApplicationContext())
      {
        taskList = db.BirthdayProcessings.Where(x => !x.complited).ToList();
        users = db.Users.ToList();
        //Рефакторинг
        //taskList = db.BirthdayProcessings.FromSqlRaw("SELECT * FROM birthdayprocessing WHERE complited is false").ToList();
        //users = db.Users.FromSqlRaw("SELECT * FROM users").ToList();
      }
      workingTask = taskList.Count();
      foreach (var task in taskList)
      {
        string uri = Config.Aura + "ISimpleTasks(" + task.task + ")";//prod
        CreatedTask createdTask;
        try
        {
          var response = await client.GetAsync(uri);
          createdTask = JObject.Parse(response.Content.ReadAsStringAsync().Result).ToObject<CreatedTask>();
        }
        catch (Exception ex)
        {
          Logger.WriteBirthdayLog($"Произошла ошибка при получении информации о задаче из ауры\n" +
              $"Текст ошибки:\n{ex}\n" +
              $"Получение информации о задаче завершилось неудачно.\n");
          continue;
        }
        if (createdTask.Status.ToLower().Equals("completed"))
        {
          using (ApplicationContext db = new ApplicationContext())
          {
            db.BirthdayProcessings.Where(x => x.id == task.id).FirstOrDefault().complited = true;
            db.SaveChanges();
            //Рефакторинг
            //string updateQuery = $"UPDATE birthdayprocessing set complited = true WHERE id = {task.id}";
            //db.Database.ExecuteSqlRaw(updateQuery);
          }
        }
        if (createdTask.Status.ToLower().Equals("inprocess"))//задача в работе
        {
          if ((!IsSPDEmployee(users.Where(x => x.IdAura == task.iduser).Select(x => x.Id).FirstOrDefault())
              || !IsSPDEmployee(users.Where(x => x.Id == task.idbirthdayman).Select(x => x.Id).FirstOrDefault()))
              && DateTime.Now < task.birthday)
          {
            using (ApplicationContext db = new ApplicationContext())
            {
              db.BirthdayProcessings.Remove(db.BirthdayProcessings.Where(x => x.id == task.id).FirstOrDefault());
              db.BirthdayMessageTrackings.Remove(db.BirthdayMessageTrackings.Where(x => x.id == task.idtracking).FirstOrDefault());
              db.SaveChanges();
            }
            //Рефакторинг
            //List<string> deleteQuery = new List<string>
            //            {
            //                $"DELETE FROM birthdayprocessing WHERE id = {task.id}",
            //                $"DELETE FROM birthdaymessagetracking WHERE id = {task.idtracking}"
            //            };
            //foreach (var query in deleteQuery)
            //{
            //  using (ApplicationContext db = new ApplicationContext())
            //  {
            //    db.Database.ExecuteSqlRaw(query);
            //  }
            //}
            await SearchBirthday();
            Logger.WriteBirthdayLog($"{users.Where(x => x.IdAura == task.iduser).Select(x => x.Fio).FirstOrDefault()} " +
                $"больше не является сотрудником СПД." +
                $"Запущен новый поиск поздравляюшего");
            continue;
          }

          //проверим, что сегодня рабочий день, если выходной - не производим вычисления.
          bool isWork = false;
          using (ApplicationContext db = new ApplicationContext())
          {
            isWork = db.Calendars.Where(x => x.Date == DateTime.Today)
                .Select(x => x.Iswork)
                .FirstOrDefault();
            //isWork = db.Calendars.FromSqlRaw($"SELECT * FROM calendar WHERE date = '{DateTime.Today.ToString("dd.MM.yyyy")}'")
            //    .Select(x => x.Iswork)
            //    .FirstOrDefault();
          }
          if (!isWork)
          {
            return;
          }

          //отслеживаем выполнение задачи
          /*
          if (DateTime.Now > createdTask.MaxDeadline) //если профакаплен дедлайн, то кто то ахуел.
          {
              if (DateTime.Now > createdTask.MaxDeadline.AddDays(7)) //если профакаплен более чем на неделю - уведомление ответственному за поздравления
              {
                  string msg = $"Нашим коллегой " +
                      $"{users.Where(x => x.IdAura == task.iduser).Select(x => x.Fio).FirstOrDefault()} " +
                      $"пропушен срок выполнения задачи более чем на 1 неделю.";
                  DirectChannelInfo directInfo;
                  List<UsersInfo> usersInfo;
                  List<string> idMsg = new List<string>();
                  List<string> dialogList = new List<string>
                  {
                      BotID
                  };
                  List<string> userList = new List<string>
                  {
                      users.Where(x => x.IdAura == task.iduser).Select(x => x.Login).FirstOrDefault().ToLower(),
                      Config.CongratulationsResponsible.ToLower()
                  };
                  //получаем ID пользователей по списку
                  try
                  {
                      var responseUsersList = await clientММ.PostAsJsonAsync(Config.ApiSearchUsersByName, userList);
                      usersInfo = JArray.Parse(responseUsersList.Content.ReadAsStringAsync().Result).ToObject<List<UsersInfo>>();
                  }
                  catch (Exception ex)
                  {
                      Logger.WriteBirthdayLog("Произошла ошибка при обращении к api MatterMost\r" +
                      $"Текст ошибки:\r{ex}\r Обращение к API завершилось c ошибкой.");
                      return;
                  }
                  foreach (var info in usersInfo)
                  {
                      dialogList.Add(info.id); //пользак
                  }
                  //создаем канал прямых сообщений на несколько человек
                  try
                  {
                      var response = await clientММ.PostAsJsonAsync(Config.ApiUrlGroupChannel, dialogList);
                      directInfo = JObject.Parse(response.Content.ReadAsStringAsync().Result).ToObject<DirectChannelInfo>();
                  }
                  catch (Exception ex)
                  {
                      Logger.WriteBirthdayLog("Произошла ошибка при обращении к api MatterMost\r" +
                      $"Текст ошибки:\r{ex}\r Обращение к API завершилось c ошибкой.");
                      return;
                  }
                  //просматриваем все сообщения за 7 дней, и, если уже есть сообщение в канале, то выходим из метода
                  uri = Config.ApiUrlChannel + "/" + directInfo.id + "/posts?since=" + DateTimeOffset.Now.AddDays(-7).ToUnixTimeMilliseconds();
                  dynamic json = JObject.Parse((await clientММ.GetStringAsync(uri)).ToString());
                  foreach (dynamic obj in json.order)
                  {
                      idMsg.Add(obj.ToString());
                  }
                  foreach (var id in idMsg)
                  {
                      uri = Config.ApiUrlPost + "/" + id;
                      try
                      {
                          json = JObject.Parse((await clientММ.GetStringAsync(uri)).ToString());
                          await Task.Delay(200);
                      }
                      catch (Exception ex)
                      {
                          await Task.Delay(200);
                          continue;
                      }
                      if ((json["user_id"] == BotID) && (json["delete_at"] == 0) && (json["message"].ToString().Contains("пропушен срок выполнения задачи")))
                      {
                          return;
                      }
                  }
                  //если же такого сообщения не нашлось, то генерируем сообщение в этот канал, дальше пусть разбираются, нас не колышит
                  var data = new
                  {
                      channel_id = directInfo.id,
                      message = msg
                  };
                  await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
              }
              else //если профакаплен менее недели - уведомление в ЛС поздравляющему.
              {
                  string msg = $"Привет. Я вижу, что ты всё ещё не выполнил задачу на поздравление коллеги в ауре. " +
                      $"Прошу проверить, поздравил ли ты коллегу с днем рождения и выполнить задачу.";
                  List<string> idMsg = new List<string>();
                  string idDirectChannel = "";
                  using (ApplicationContext db = new ApplicationContext())
                  {
                      idDirectChannel = db.DirectChannels.FromSqlRaw("SELECT * FROM directchannel")
                          .Where(x => x.Iduser == users.Where(x => x.IdAura == task.iduser).Select(x => x.Id).FirstOrDefault())
                          .Select(x => x.Idchannel)
                          .FirstOrDefault();
                  }

                  //просматриваем все сообщения за 2 дня, и, если уже есть сообщение в канале, то выходим из метода
                  uri = Config.ApiUrlChannel + "/" + idDirectChannel + "/posts?since=" + DateTimeOffset.Now.AddDays(-2).ToUnixTimeMilliseconds();
                  dynamic json = JObject.Parse((await clientММ.GetStringAsync(uri)).ToString());
                  foreach (dynamic obj in json.order)
                  {
                      idMsg.Add(obj.ToString());
                  }
                  foreach (var id in idMsg)
                  {
                      uri = Config.ApiUrlPost + "/" + id;
                      try
                      {
                          json = JObject.Parse((await clientММ.GetStringAsync(uri)).ToString());
                          await Task.Delay(200);
                      }
                      catch (Exception ex)
                      {
                          await Task.Delay(200);
                          continue;
                      }
                      if ((json["user_id"] == BotID) && (json["delete_at"] == 0)
                          && (json["message"].ToString().Contains("Привет. Я вижу, что ты всё ещё не выполнил задачу")))
                      {
                          return;
                      }
                  }

                  var data = new
                  {
                      channel_id = idDirectChannel,
                      message = msg
                  };
                  await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
              }
          }*/
        }
      }
      Logger.WriteBirthdayLog($"Задачи по отслеживанию запущенных задач на поздравление выполнена, задач в работе: {workingTask}");
    }

    #region Отслеживание количества отказов на поздравление коллег, разработанный метод не используется.
    /// <summary>
    /// Отслеживание количества отказов на поздравление коллег, разработанный метод не используется.
    /// </summary>
    /// <returns></returns>
    private static async Task TrackingIgnoreCongrat()
    {
      Logger.WriteBirthdayLog("Старт задачи по отслеживанию количества отказов");
      List<User> users = new List<User>();
      DateTime startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
      DateTime endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31);
      //Смотрим, было ли уже такое сообщение в текущем году
      using (ApplicationContext db = new ApplicationContext())
      {
        users = db.Users.FromSqlRaw("SELECT * FROM users").ToList();
      }
      foreach (var u in users.Where(x => x.Employee_SPD == true))
      {
        int countIgnoreCongrat = 0;
        int isHaveMsgCurrentYear = 0;
        //преобразуем в ДР текущего года
        u.Date_of_birth = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")),
            int.Parse(u.Date_of_birth.ToString("MM")),
            int.Parse(u.Date_of_birth.ToString("dd")));
        //отбираем количество отказов
        using (ApplicationContext db = new ApplicationContext())
        {
          //если было согласие на поздравление, то чел законопослушный, пропускаем в этом году
          countIgnoreCongrat = db.BirthdayMessageTrackings.FromSqlRaw($"SELECT * FROM birthdaymessagetracking " +
              $"WHERE status is true and inputdate between '{startYear}' and '{endYear}'")
              .Where(x => x.iduser == u.Id).Count();
          if (countIgnoreCongrat != 0)
          {
            continue;
          }
          //если не было согласий, то начинаем разбираться
          countIgnoreCongrat = db.BirthdayMessageTrackings.FromSqlRaw($"SELECT * FROM birthdaymessagetracking " +
              $"WHERE status is false and inputdate between '{startYear}' and '{endYear}'")
              .Where(x => x.iduser == u.Id).Count();

          //Если уже было информационное сообщение в этом году, то не смотрим пользователя
          isHaveMsgCurrentYear = db.InfoMsgs.FromSqlRaw($"SELECT * FROM infomsg " +
              $"WHERE date between '{startYear}' and '{endYear}' and iduser = {u.Id} and msgtype = 'fackup'").Count();

          if (isHaveMsgCurrentYear != 0)
          {
            continue;
          }
        }
        if (countIgnoreCongrat >= 5)
        {
          HttpClient client = new HttpClient();
          client.DefaultRequestHeaders.Accept.Clear();
          client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
          int count = 1;
          List<int> fackUpList;
          DirectChannelInfo directInfo;
          List<UsersInfo> usersInfo;
          List<string> dialogList = new List<string>
                            {
                                BotID
                            };
          List<string> userList = new List<string>
                            {
                                u.Login.ToLower(),
                                Config.Supervisor.ToLower(),
                            };
          if (!u.Login.ToLower().Equals(Config.CongratulationsResponsible.ToLower()))
          {
            userList.Add(Config.CongratulationsResponsible.ToLower());
          }
          if (u.Team != null)
          {
            userList.Add(users.Where(x => x.Duty == null && x.Team.Equals(u.Team))
                        .Select(x => x.Login).FirstOrDefault());
          }
          string msg = "Добрый день коллеги.\r\n" +
              $"{u.Fio.Remove(u.Fio.LastIndexOf(' '))} отказался организовать поздравление коллеги {countIgnoreCongrat} раз.\r\n" +
              $"Предлагаю разобраться в причинах этих отказов.\r\n" +
              $"Коллеги, которых {u.Fio.Remove(u.Fio.LastIndexOf(' '))} отказался поздравлять с днём рождения:\r\n";
          using (ApplicationContext db = new ApplicationContext())
          {
            fackUpList = db.BirthdayMessageTrackings.FromSqlRaw($"SELECT * FROM birthdaymessagetracking " +
            $"WHERE status is false and inputdate between '{startYear}' and '{endYear}'")
                .Where(x => x.iduser == u.Id).Select(x => x.idbirthdayman).ToList();
          }
          foreach (int id in fackUpList)
          {
            msg += count + ". " + users.Where(x => x.Id == id).Select(x => x.Fio).FirstOrDefault() +
                " День Рождения " + users.Where(x => x.Id == id)
                .Select(x => x.Date_of_birth).FirstOrDefault().ToString("dd.MM.yyyy") + "\r\n";
            count++;
          }

          //работа с каналом сообщений
          try
          {
            var responseUsersList = await client.PostAsJsonAsync(Config.ApiSearchUsersByName, userList);
            usersInfo = JArray.Parse(responseUsersList.Content.ReadAsStringAsync().Result).ToObject<List<UsersInfo>>();
          }
          catch (Exception ex)
          {
            Logger.WriteBirthdayLog("Произошла ошибка при обращении к api MatterMost при получении ID пользователей\r" +
            $"Текст ошибки:\r{ex}\r Обращение к API завершилось c ошибкой.");
            continue;
          }
          foreach (var info in usersInfo)
          {
            dialogList.Add(info.id); //пользак
          }
          //создаем канал прямых сообщений на несколько человек
          try
          {
            var response = await client.PostAsJsonAsync(Config.ApiUrlGroupChannel, dialogList);
            directInfo = JObject.Parse(response.Content.ReadAsStringAsync().Result).ToObject<DirectChannelInfo>();
          }
          catch (Exception ex)
          {
            Logger.WriteBirthdayLog("Произошла ошибка при обращении к api MatterMost при создании канала групповых сообщений\r" +
            $"Текст ошибки:\r{ex}\r Обращение к API завершилось c ошибкой.");
            continue;
          }
          var data = new
          {
            channel_id = directInfo.id,
            message = msg
          };
          await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
          string insertQuery = $"INSERT INTO infomsg (date, msgtype, iduser) VALUES ('{DateTime.Now}', 'fackup', {u.Id})";
          using (ApplicationContext db = new ApplicationContext())
          {
            db.Database.ExecuteSqlRaw(insertQuery);
          }
        }
      }
      Logger.WriteBirthdayLog("Задачи по отслеживанию количества отказов выполнена успешно.");
    }
    #endregion


    /// <summary>
    /// проверка, является ли запрашиваемый на данный момент сотрудником СПД
    /// </summary>
    /// <returns>статус сотрудника отдела (true - сотрудник, иначе не сотрудник отдела)</returns>
    private static bool IsSPDEmployee(int id)
    {
      List<User> users = new List<User>();
      using (ApplicationContext db = new ApplicationContext())
      {
        users = db.Users.ToList();
        //Рефакторинг
        //users = db.Users.FromSqlRaw("select * from users").ToList();
      }
      return users.Where(x => x.Id == id).Select(x => x.Employee_SPD).FirstOrDefault();
    }

    /// <summary>
    /// Отслеживание отправленных задач по именинникам, которые уволились до даты ДР.
    /// </summary>
    private static async void TrackingDismissedBirthdayman()
    {
      List<BirthdayProcessing> taskLists = new List<BirthdayProcessing>();
      List<User> users = new List<User>();
      using (ApplicationContext db = new ApplicationContext())
      {
        taskLists = db.BirthdayProcessings.Where(x => !x.complited).ToList();
        users = db.Users.ToList();
        //Рефакторинг
        //taskLists = db.BirthdayProcessings.FromSqlRaw("SELECT * FROM birthdayprocessing WHERE complited is false").ToList();
        //users = db.Users.FromSqlRaw("SELECT * FROM users").ToList();
      }
      foreach (var taskList in taskLists)
      {
        if (!users.Where(x => x.Id == taskList.idbirthdayman).Select(x => x.Employee_SPD).FirstOrDefault()
            && DateTime.Today < taskList.birthday)
        {

          string uri = Config.Aura + "Shell/AbortTask";
          string auth = Convert.ToBase64String(Encoding.GetEncoding("ISO-8859-1").GetBytes(Config.AuraUser + ":" + Config.AuraPass));
#if DEBUG
          //у тестовой ауры не строится цепочка сертификатов, не обращаем внимания
          HttpClientHandler clientHandler = new HttpClientHandler();
          clientHandler.ServerCertificateCustomValidationCallback = (sender, cert, chain, sslPolicyErrors) => { return true; };
          HttpClient client = new HttpClient(clientHandler);
#endif
#if !DEBUG
                    HttpClient client = new HttpClient();
#endif
          client.DefaultRequestHeaders.Accept.Clear();
          client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          client.DefaultRequestHeaders.Add("Authorization", "Basic " + auth);
          var abortTaskId = new
          {
            taskId = taskList.task
          };
          try
          {
            var response = await client.PostAsync(uri, abortTaskId.AsJson());
          }
          catch (Exception ex)
          {
            Logger.WriteBirthdayLog($"Произошла ошибка при обращении к сервисам интеграции при прекращении задачи\n" +
            $"Текст ошибки:\n{ex.Message}\n" +
            $"Прекращение задачи завершилась неудачно.\n");
            continue;
          }

          using (ApplicationContext db = new ApplicationContext())
          {
            db.BirthdayProcessings.Remove(db.BirthdayProcessings.Where(x => x.id == taskList.id).FirstOrDefault());
            db.BirthdayMessageTrackings.Remove(db.BirthdayMessageTrackings.Where(x => x.id == taskList.idtracking).FirstOrDefault());
            db.SaveChanges();
            //Рефакторинг
            //List<string> sqlQuerys = new List<string>
            //        {
            //            $"DELETE FROM birthdayprocessing WHERE id = {taskList.id}",
            //            $"DELETE FROM birthdaymessagetracking WHERE id = {taskList.idtracking}"
            //        };
            //foreach (var sqlQuery in sqlQuerys)
            //{
            //  db.Database.ExecuteSqlRaw(sqlQuery);
            //}
          }
          Logger.WriteBirthdayLog($"Сотрудник " +
              $"{users.Where(x => x.Id == taskList.idbirthdayman).Select(x => x.Fio).FirstOrDefault()} больше не является " +
              $"сотрудником отдела, отслеживание задачи прекращается, " +
              $"согласие на поздравление удалено из БД, задача удалена из БД, задача в АУРЕ прекращена");
        }
      }
    }
  }
}
