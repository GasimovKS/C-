﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace spd_bot_sparrow
{
  //Сначала проверяем, соответствует ли база разработке, если нет, то добавляем новый столбец.
  internal class UpdateDatabase
  {
    //Обновление от августа.
    public static void syncDatabase()
    {
      try
      {
        using (ApplicationContext db = new ApplicationContext())
        {
          var users = db.Users.First();
        }
      }
      catch (Exception ex)
      {
        Logger.WriteLog("Таблица Users не соответствует разработке, добавляем недостающие столбцы");
        using (ApplicationContext db = new ApplicationContext())
        {
          db.Database.ExecuteSqlRaw("ALTER TABLE users ADD COLUMN teamlead bool NOT NULL DEFAULT(false)");
        }
      }
    }
  }
}