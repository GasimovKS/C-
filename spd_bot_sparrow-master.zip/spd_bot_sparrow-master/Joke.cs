﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{
    /// <summary>
    /// класс для шутех, не реализовано.
    /// </summary>
    internal class Joke
    {
    }
}
