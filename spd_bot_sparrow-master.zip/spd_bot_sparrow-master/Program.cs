﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{
  //старый коп расширение для студии
  internal class Program
  {
    public static DateTime StartTime { get; set; }
    static void Main(string[] args)
    {
      //Создать пользователей в ММ, если их там нет, применяется единожды для тестовых разработок.
      //Task createUsersTask = CreateUsers();
      //createUsersTask.Wait();
      //UpdateDatabase.syncDatabase();
      StartTime = DateTime.Now;
      Console.WriteLine($"{StartTime}: Начало работы бота");
      using CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
      var tasks = new List<Task>();
      if (Config.ModuleAuraSync)
      {
        tasks.Add(new Task(() => AuraSync.AuraSyncTask()));
        Console.WriteLine("Модуль синхронизации с аурой подключен");
      }
      else
        Console.WriteLine("Модуль синхронизации с аурой отключен");
      if (Config.ModuleGenerateSchedule)
      {
        tasks.Add(new Task(() => GenerateDutyList.DutyWeek()));
        Console.WriteLine("Модуль генерации графика дежурств подключен");
      }
      else
        Console.WriteLine("Модуль генерации графика дежурств отключен");
      if (Config.ModuleInterplay)
      {
        tasks.Add(new Task(() => Interplay.TrackingNewMessagesInPost()));
        Console.WriteLine("Модуль отслеживания тредов графика подключен");
      }
      else
        Console.WriteLine("Модуль отслеживания тредов графика отключен");
      if (Config.ModuleDirectMessage)
      {
        tasks.Add(new Task(() => DirectMessage.TrackingDirectMessages()));
        Console.WriteLine("Модуль прямых сообщений подключен");
      }
      else
        Console.WriteLine("Модуль прямых сообщений отключен");
      if (Config.ModuleHappyBirthday)
      {
        tasks.Add(new Task(() => HappyBirthday.TrackingBirthdays()));
        Console.WriteLine("Модуль поздравления с днём рождения подключен");
      }
      else
        Console.WriteLine("Модуль поздравления с днём рождения отключен");
      foreach (var task in tasks)
      {
        task.Start();
      }
      while (true)
      {
        Thread.Sleep(60000);
      }
    }
    /// <summary>
    /// Первичное наполнение БД Маттермоста, для тестовых баз, в проде НЕ использовать. 
    /// </summary>
    private static async Task CreateUsers()
    {
      HttpClient client = new HttpClient();
      client.DefaultRequestHeaders.Accept.Clear();
      client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
      client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
      string uri = "http://romesh.ddns.net:8065/api/v4/users";
      List<User> users;
      using (ApplicationContext db = new ApplicationContext())
      {
        users = db.Users.Where(x => x.Employee_SPD).ToList();
      }
      foreach (var user in users)
      {
        if (user.Login.ToLower().Equals("chirkov_ro"))
          continue;
        var data = new
        {
          email = user.Login + "@izhtgt.local",
          username = user.Login,
          auth_service = "",
          password = "1Qwerty",
          nickname = user.Fio,
          first_name = user.Fio.Remove(user.Fio.IndexOf(' ')),
          last_name = user.Fio.Remove(0, user.Fio.IndexOf(' ') + 1)
        };
        var response = await client.PostAsync(uri, data.AsJson());
        Console.WriteLine(user.Login + ": " + response.StatusCode);
        if (!response.IsSuccessStatusCode)
        {
          continue;
        }
      }
    }
  }
}