﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using System.Text.RegularExpressions;

namespace spd_bot_sparrow
{
  /// <summary>
  /// класс для взаимодейтвия бота с пользователями в тредах сообщения
  /// </summary>
  internal class Interplay
  {
    #region Глобальные переменные, списки реакций и сообщения для ответа
    public static string MessageID { get; set; }
    public static string PreviousMessageID { get; set; }
    private static string BotID { get { return Config.BotID; } }
    private static string ErrMsg { get { return "Неверный формат команды, отказано"; } }
    private static string ErrCmdMsg { get { return "Команда не найдена, повторите попытку"; } }
    private static string ErrAuthorNotDuty { get { return " не дежурит на этой неделе."; } }
    private static string ErrPrivilageCommand { get { return " Отказано. Командой могу воспользоваться только тимлиды или ответственный за дежурство в отделе. "; } }
    private static string ErrDate { get { return "Запрещена замена/подмена на даты дежурств, которые уже прошли"; } }
    private static string JokeMsg { get { return "А ты шутник, отказано."; } }
    private static string NotEmployeesSPD { get { return "Указаный сотрудник не является действующим сотрудником СПД, отказано"; } }
    private static string NotSmirnov { get { return " это эксклюзивная команда, доступная только @smirnov_ra, смирись"; } }
    private static string NotDolina { get { return " это эксклюзивная команда, доступная только @dolina_pi, смирись"; } }
    private static string UserRefusal { get { return " отказался от замены"; } }
    /// <summary>
    /// Положительные реакции
    /// </summary>
    private static readonly List<string> allAgreeReactions = new List<string>
        {
            "heavy_check_mark",
            "ballot_box_with_check",
            "checkered_flag",
            "white_check_mark",
            "plus",
            "heavy_plus_sign",
            "ok",
            "ok_hand",
            "okay",
            "+1",
            "resolved"
        };
    /// <summary>
    /// Отрицательные реакции.
    /// </summary>
    private static readonly List<string> allDisagreeReactions = new List<string>
        {
            "minus",
            "heavy_minus_sign",
            "octagonal_sign",
            "black_square_for_stop",
            "x",
            "name_badge",
            "negative_squared_cross_mark",
        };
    #endregion
    internal static async void TrackingNewMessagesInPost()
    {
      await Task.Run(() => TrackingNewMessages());
    }
    private static async Task TrackingNewMessages()
    {
      List<string> threadMessages = new List<string>();
      List<string> threadPreviousMessages = new List<string>();
      List<string> teamLeads = new List<string>();
      List<string> employees = new List<string>();
      List<string> intern = new List<string>();
      DateTime targetResearch = new DateTime();
      DateTime endDateOfWeek = calculation.GetEndDateOfWeek();
      DateTime endPreviousDateOfWeek = calculation.GetEndDateOfWeek(calculation.GetFirstDateOfTargetWeek(endDateOfWeek).AddDays(-1));
      targetResearch = DateTime.Today;
      if ((MessageID == null) || MessageID.Equals(""))
      {
        using (ApplicationContext db = new ApplicationContext())
        {
          MessageID = db.InfoMsgs.Where(x => x.msgtype.ToLower().Equals("nextschedule")).Select(x => x.value).FirstOrDefault();
          PreviousMessageID = db.InfoMsgs.Where(x => x.msgtype.ToLower().Equals("previousschedule")).Select(x => x.value).FirstOrDefault();
          //Рефакторинг
          /*
          MessageID = db.InfoMsgs.FromSqlRaw("SELECT* FROM infomsg").ToList().
              Where(x => x.msgtype.Equals("nextschedule")).Select(x => x.value).FirstOrDefault();
          PreviousMessageID = db.InfoMsgs.FromSqlRaw("SELECT* FROM infomsg").ToList().
              Where(x => x.msgtype.Equals("previousschedule")).Select(x => x.value).FirstOrDefault();
          */
        }
      }
      //Старая реализация, когда получали только ID актуального графика
      while (true)
      {
        if ((MessageID == null) || MessageID.Equals(""))
        {
          Logger.WriteLog($"Отсутствует ID Целевого сообщения");
          MessageID = ToMattermost.PinnedMessage(BotID).Result; //Получаем ID крайнего сообщения бота о графике дежурств
          if (MessageID == "")
          {
            await Task.Delay(10000);
            continue;
          }
          using (ApplicationContext db = new ApplicationContext())
          {
            var prev = db.InfoMsgs.Where(x => x.msgtype.ToLower().Equals("previousschedule")).FirstOrDefault();
            var next = db.InfoMsgs.Where(x => x.msgtype.ToLower().Equals("nextschedule")).FirstOrDefault();
            if (prev != null || prev.value.ToLower().Equals(""))
            {
              db.InfoMsgs.Remove(prev);
            }
            if (next == null)
            {
              db.InfoMsgs.Add(new InfoMsg
              {
                date = DateTime.Now,
                value = MessageID,
                msgtype = "nextschedule"
              });
            }
            else
            {
              next.date = DateTime.Now;
              next.value = MessageID;
            }
            db.SaveChanges();
            //Рефакторинг
            /*
            List<string> querys = new List<string>
                        {
                            "DELETE FROM infomsg WHERE msgtype in ('previousschedule', 'nextschedule')",
                            $"INSERT INTO infomsg (date, msgtype, value) VALUES ('{DateTime.Now}', 'nextschedule', '{MessageID}')"
                        };
            foreach (string query in querys)
            {
              db.Database.ExecuteSqlRaw(query);
            }*/
          }
        }
        else
        {
          break;
        }
        await Task.Delay(5000);
      }
      if (PreviousMessageID == null)
      {
        PreviousMessageID = "";
      }
      string targetMessageID = MessageID;
      string targetPreviousMessageID = PreviousMessageID;
      Console.WriteLine($"{DateTime.Now}: График дежурств, треды которого отслеживаются: " + targetMessageID);
      Console.WriteLine($"{DateTime.Now}: Предыдущий график дежурств, треды которого отслеживаются: " + targetPreviousMessageID);
      Logger.WriteLog($"График дежурств, треды которого отслеживаются: {targetMessageID}");
      Logger.WriteLog($"Предыдущий график дежурств, треды которого отслеживаются: {targetPreviousMessageID}");
      while (true)
      {
        if ((DateTime.Now >= DateTime.Today.AddHours(5)) && (DateTime.Now <= DateTime.Today.AddHours(24)))
        {
          List<string> idMsg = new List<string> { };
          List<string> idPreviousMsg = new List<string> { };
          if (DateTime.Now > targetResearch)
          {
            teamLeads.Clear();
            employees.Clear();
            intern.Clear();
            using (ApplicationContext db = new ApplicationContext())
            {
              //получаем список тим-лидов, им разрешены замены без согласия
              var users = db.Users.Where(x => x.Employee_SPD).ToList();
              foreach (User u in users)
              {
                if (u.Teamlead || u.Login.ToLower().Equals(Config.Supervisor))
                {
                  teamLeads.Add(u.Login.ToLower());
                }
                if (u.Intern)
                {
                  intern.Add(u.Login.ToLower());
                }
                employees.Add(u.Login.ToLower());
              }
            }
            teamLeads.Add(Config.DutysResponsible.ToLower());
            teamLeads.Add(Config.Supervisor.ToLower());
            employees.Add("sparrow");
            employees.Add("Sparrow");
            targetResearch = DateTime.Now.AddDays(1);
          }
          if (string.Compare(targetMessageID, MessageID) != 0)
          {
            targetMessageID = MessageID;
            targetPreviousMessageID = PreviousMessageID;
            threadPreviousMessages = new List<string>(threadMessages);
            threadMessages.Clear();
            endPreviousDateOfWeek = endDateOfWeek;
            endDateOfWeek = calculation.GetEndDateOfWeek();
            Console.WriteLine("Новое график, треды которого отслеживаем: " + targetMessageID);
            Console.WriteLine("Предыдущий график, треды которого отслеживаем: " + targetPreviousMessageID);
          }
          string uri = Config.ApiUrlPost + "/" + targetMessageID + "/thread";
          HttpClient client = new HttpClient();
          client.DefaultRequestHeaders.Accept.Clear();
          client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
          client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
          dynamic json;
          try
          {
            json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
          }
          catch (Exception e)
          {
            Logger.WriteLog($"Произошла ошибка при обращении к API mattermost, текст ошибки: \r\n{e.Message}");
            await Task.Delay(3000);
            continue;
          }
          foreach (dynamic order in json.order)
          {
            if (order.ToString() != targetMessageID)
            {
              idMsg.Add(order.ToString());
            }
          }
          if (threadMessages.Count() <= idMsg.Count())
          {
            for (int index = idMsg.Count() - 1; index >= 0; index--)
            {
              foreach (string threadMsg in threadMessages)
              {
                if (string.Compare(threadMsg, idMsg[index]) == 0)
                {
                  idMsg.RemoveAt(index);
                  break;
                }
              }
            }
          }
          if (idMsg.Count() > 0)
          {
            await Task.Run(() => TrackingNewMessage(teamLeads, threadMessages, idMsg, employees, intern, endDateOfWeek, targetMessageID));
          }
          if (!PreviousMessageID.Equals(""))
          {
            //предыдущий график
            uri = Config.ApiUrlPost + "/" + targetPreviousMessageID + "/thread";
            try
            {
              json = JObject.Parse((await client.GetStringAsync(uri)).ToString());
            }
            catch (Exception e)
            {
              Logger.WriteLog($"Произошла ошибка при обращении к API mattermost, текст ошибки: \r\n{e.Message}");
              await Task.Delay(300000);
              continue;
            }
            foreach (dynamic order in json.order)
            {
              if (order.ToString() != targetPreviousMessageID)
              {
                idPreviousMsg.Add(order.ToString());
              }
            }

            if (threadPreviousMessages.Count() <= idPreviousMsg.Count())
            {
              for (int index = idPreviousMsg.Count() - 1; index >= 0; index--)
              {
                foreach (string threadMsg in threadPreviousMessages)
                {
                  if (string.Compare(threadMsg, idPreviousMsg[index]) == 0)
                  {
                    idPreviousMsg.RemoveAt(index);
                    break;
                  }
                }
              }
            }
            if (idPreviousMsg.Count() > 0)
            {
              await Task.Run(() => TrackingNewMessage(teamLeads, threadPreviousMessages, idPreviousMsg, employees, intern, endPreviousDateOfWeek, targetPreviousMessageID));
            }
          }
        }
        await Task.Delay(9000);
      }
    }

    /// <summary>
    /// Отслеживание новых сообщений боту в тредах графика.
    /// </summary>
    /// <param name="teamLeads">Список тимлидов.</param>
    /// <param name="threadMessages">Список обработанных сообщений в треде.</param>
    /// <param name="idMsg">Список необработанных сообщений в треде.</param>
    /// <param name="employees">Список сотрудников отдела.</param>
    /// <param name="intern">Список стажеров.</param>
    /// <param name="endDateOfWeek">Дата конца недели рассматриваемого графика.</param>
    /// <param name="targetMessageID">ID сообщения с графиком.</param>
    /// <returns>Ничего не возвращает.</returns>
    private static async Task TrackingNewMessage(List<string> teamLeads, List<string> threadMessages,
                                                List<string> idMsg, List<string> employees, List<string> intern,
                                                DateTime endDateOfWeek, string targetMessageID)
    {
      string patternBotName = "@sparrow";
      foreach (var msg in idMsg)
      {
        List<Tuple<string, string>> msgReactions = new List<Tuple<string, string>>(); // Пользователь | реакция
        string uri = Config.ApiUrlPost + "/" + msg;
        bool isBotReactions = false;
        HttpClient client = new HttpClient();
        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Config.BotToken);
        dynamic jsonMsg;
        try
        {
          jsonMsg = JObject.Parse((await client.GetStringAsync(uri)).ToString());
        }
        catch (Exception ex)
        {
          Logger.WriteLog($"Произошла ошибка при обращении к API mattermost, текст ошибки: {Environment.NewLine}{ex.Message}");
          await Task.Delay(5000);
          return;
        }
        string currentMsg = jsonMsg["message"];
        string authorMsgId = jsonMsg["user_id"];
        string authorMsg = ToMattermost.GetUserNameByID(authorMsgId).Result;
        //обработка, что сообщение не сотрудника СПД, что бы код дальше не исполнялся.
        if (!employees.Contains(authorMsg.ToLower()))
        {
          threadMessages.Add(msg);
          await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
          continue;
        }
        //Если это сообщение бота, то добавляем в обработанные, реакции не ставим
        if (authorMsgId.ToLower().Equals(BotID.ToLower()))
        {
          threadMessages.Add(msg);
          continue;
        }
        //Рефакторинг
        /*
        if (!employees.Contains(authorMsg.ToLower()))
        {
          threadMessages.Add(msg);
          await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
          continue;
        }
        */
        int tmpValue = jsonMsg["delete_at"];
        if (tmpValue == 0)
        {
          Regex regex = new Regex(patternBotName, RegexOptions.IgnoreCase);
          MatchCollection matches = regex.Matches(currentMsg);
          if (matches.Count != 0)
          {
            string uriReactions = Config.ApiUrlPost + "/" + msg + "/reactions";
            try
            {
              JArray jsonReactions = JArray.Parse(await client.GetStringAsync(uriReactions));
              await Task.Delay(500);
              foreach (var jString in jsonReactions)
              {
                dynamic jsonReaction = JObject.Parse(jString.ToString());
                string tmpUsrId = jsonReaction["user_id"];
                string emojiName = jsonReaction["emoji_name"];
                if ((string.Compare(tmpUsrId, BotID) == 0) &&
                    (string.Compare(emojiName, "no_entry_sign") == 0 || string.Compare(emojiName, "done2") == 0 ||
                    string.Compare(emojiName, "skoratov") == 0 || string.Compare(emojiName, "ed_dovolen") == 0))
                {
                  threadMessages.Add(msg);
                  isBotReactions = true;
                }
                msgReactions.Add(new Tuple<string, string>(ToMattermost.GetUserNameByID(tmpUsrId).Result, emojiName));
              }
              if (isBotReactions)
              {
                continue;
              }
            }
            catch (Exception)
            {
            }
            currentMsg = regex.Replace(currentMsg.ToLower(), "");
            currentMsg = currentMsg.Trim();

            //отсюда начиная ищем команды
            Regex regexCommand = new Regex(@"^!(\w*)");
            MatchCollection matchesCommand = regexCommand.Matches(currentMsg);
            currentMsg = regexCommand.Replace(currentMsg + " ", "");
            if (matchesCommand.Count != 0)
            {
              switch (matchesCommand[0].Value.ToLower())
              {
                case "!change": //поменяться местами с дежурным
                  ReplacingDuty(msgReactions, teamLeads, intern, threadMessages, employees, targetMessageID, authorMsg, msg, currentMsg, endDateOfWeek);
                  break;
                case "!variant": //список людей на замену
                  DutyChangeOptions(threadMessages, targetMessageID, authorMsg, msg, endDateOfWeek);
                  break;
                case "!rating": //рейтинг дежурных за текущий год.
                  GenerateRating(threadMessages, targetMessageID, msg);
                  break;
                case "!substitution": //замена дежурящего человека
                  ReplacingDuty(msgReactions, teamLeads, intern, threadMessages, employees, targetMessageID, authorMsg, msg, currentMsg, endDateOfWeek, true);
                  break;
                case "!intern": //добавление стажера без фиксации в истории (например новички 1 категории)
                  if (authorMsg.ToLower().Equals(Config.DutysResponsible.ToLower())
                      || authorMsg.ToLower().Equals("chirkov_ro") || teamLeads.Contains(authorMsg.ToLower()))
                  {
                    EternalDutyHelper(threadMessages, employees, teamLeads, intern, targetMessageID, authorMsg, msg, currentMsg, endDateOfWeek, true);
                  }
                  else
                  {
                    await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrPrivilageCommand, BotID);
                    await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
                  }
                  break;
                case "!reserve": //добавление доп.дежурного к уже имеющимся без фиксации в истории
                  if (authorMsg.ToLower().Equals(Config.DutysResponsible.ToLower())
                      || authorMsg.ToLower().Equals("chirkov_ro") || teamLeads.Contains(authorMsg.ToLower()))
                  {
                    EternalDutyHelper(threadMessages, employees, teamLeads, intern, targetMessageID, authorMsg, msg, currentMsg, endDateOfWeek, false);
                  }
                  else
                  {
                    await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrPrivilageCommand, BotID);
                    await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
                  }
                  break;
                case "!help": //список команд
                  if (employees.Contains(authorMsg))
                  {
                    HelpCmd(targetMessageID, threadMessages, msg);
                  }
                  else
                  {
                    await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrCmdMsg, BotID);
                    await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
                  }
                  break;
                case "!заебал": //отправка 5 прямых сообщений с текстом указанному человеку
                  if (authorMsg.ToLower().Equals("chirkov_ro"))
                  {
                    ZaebaCmd(threadMessages, msg, currentMsg, authorMsg);
                  }
                  else
                  {
                    await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrCmdMsg, BotID);
                    await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
                  }
                  break;
                default:
                  Logger.WriteDirectLog($"{DateTime.Now}: Пришла следующая неопознанная команда в треды графика дежурств:\r{matchesCommand[0].Value.ToLower()}");
                  await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrCmdMsg, BotID);
                  await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
                  break;
              }
            }
            else
            {
              threadMessages.Add(msg);
            }
          }
          else
          {
            threadMessages.Add(msg);
          }
        }
        else
        {
          threadMessages.Add(msg);
        }
      }
    }

    /// <summary>
    /// Справка по командам бота в тредах
    /// </summary>
    /// <param name="targetMessageID">ID графика дежурств.</param>
    /// <param name="threadMessages">Список с ID обработанных сообщений.</param>
    /// <param name="msg">ID обрабатываемого сообщения.</param>
    private static async void HelpCmd(string targetMessageID, List<string> threadMessages, string msg)
    {
      string message = "Доступные команды бота:\n\r" +
          "**!change** - команда для взаимной замены дежурных (если оба дежурных дежурят на текущей неделе) или свободного дежурного. " +
          "Инициатором замены должен выступать инженер, которого требуется заменить. Формат команды @sparrow !change **@на кого поменять** \n\r" +

          "**!variant** - команда предоставляет список сотрудников, которые потенциально могут подменить инициатора запроса. В список не попадают " +
          "сотрудники, находящиеся в отпусках, на больничных, а так же дежурящие на этой неделе\n\r" +

          "**!rating** - команда выводит количество отдежуренных смен инженерами по возрастанию общего количества за год\n\r" +

          "**!substitution** - замена дежурного, дежурящего на текущей неделе без учета, дежурит ли на этой неделе подменяемый. Инициатором подмены " +
          "должен выступать инженер, которого требуется заменить. Формат команды @sparrow !substitution **@на кого поменять**\n\r" +

          "**!reserve** - добавление в график дежурств инженера СПД без фиксации в исторических данных в качестве запасного дежурного\n\r" +

          "**!intern** - добавление в график дежурств инженера СПД без фиксации в исторических данных в качестве регистрирующего общую папку\n\r\n\r" +

          "При выполнении действий с дежурными, исторические данные так же обновляются.";

      var data = new
      {
        channel_id = Config.DutyChannalID,
        message = message,
        root_id = targetMessageID
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(msg, "done2", BotID);
      threadMessages.Add(msg);
    }

    /// <summary>
    /// Реализация замены или подмены дежурного.
    /// </summary>
    /// <param name="msgReactions">реации под рассматриваемым собщением</param>
    /// <param name="teamLeads">Список тимлидов, плюс руководитель и вечный дежурный</param>
    /// <param name="intern">список стажеров</param>
    /// <param name="threadMessages">список тредов</param>
    /// <param name="employees">список сотрудников</param>
    /// <param name="targetMessageID">ID главного сообщения (root) - сообщение с графиком дежурств</param>
    /// <param name="authorMsg">Автор сообщения</param>
    /// <param name="msg">ID рассматриваемого сообщения</param>
    /// <param name="currentMsg">текст рассматриваемого сообщения</param>
    /// <param name="endDateOfWeek">крайняя дата, внесенная в историю дежурств в БД - совпадает 
    /// с крайним рабочим днем недели активного графика дежурств</param>
    /// <param name="isSubstitutionDutyCmd">параметр, указывающий, в каком режиме испольщуется метод: 
    /// по-умолчанию - замена (false) или подмена (true)</param>
    /// <returns>Метод ничего не возвращает</returns>
    private static async Task ReplacingDuty(List<Tuple<string, string>> msgReactions, List<string> teamLeads, List<string> intern,
                                        List<string> threadMessages, List<string> employees, string targetMessageID, string authorMsg,
                                        string msg, string currentMsg, DateTime endDateOfWeek, bool isSubstitutionDutyCmd = false)
    {
      string replacing = ""; //кто меняет
      string duty = ""; //кого меняем
      DateTime startDateOfWeek = calculation.GetFirstDateOfTargetWeek(endDateOfWeek);
      Regex regexUsers = new Regex(@"@(\w*)");
      MatchCollection matchesUsers = regexUsers.Matches(currentMsg);
      if (matchesUsers.Count != 0)
      {
        bool isNotSpdEmployees = false;
        foreach (var user in matchesUsers)
        {
          //проверим, что пользак является сотрудником СПД
          if (!employees.Contains(user.ToString().ToLower().Trim('@')))
          {
            await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, NotEmployeesSPD, BotID);
            await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
            threadMessages.Add(msg);
            isNotSpdEmployees = true;
            break;
          }
        }
        if (isNotSpdEmployees)
        {
          return;
        }

        switch (matchesUsers.Count)
        {
          case 1:
            if (!teamLeads.Contains(authorMsg))
            {
              duty = authorMsg.ToLower();
              replacing = matchesUsers[0].Value.Trim('@').ToLower();
              if (string.Compare(authorMsg, Config.EternalDuty) == 0)
              {
                await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, " перестань хулиганить!", BotID);
                await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
                threadMessages.Add(msg);
              }
            }
            else
            {
              await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrMsg, BotID);
              await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
              threadMessages.Add(msg);
              return;
            }
            break;
          case 2:
            if (authorMsg.ToLower().Equals(matchesUsers[0].Value.Trim('@').ToLower()))
            {
              duty = matchesUsers[0].Value.Trim('@').ToLower();
              replacing = matchesUsers[1].Value.Trim('@').ToLower();
            }
            else
            {
              if (authorMsg.ToLower().Equals(matchesUsers[1].Value.Trim('@').ToLower()))
              {
                duty = matchesUsers[1].Value.Trim('@').ToLower();
                replacing = matchesUsers[0].Value.Trim('@').ToLower();
              }
              else
              {
                if (teamLeads.Contains(authorMsg))
                {
                  duty = matchesUsers[0].Value.Trim('@').ToLower();
                  replacing = matchesUsers[1].Value.Trim('@').ToLower();
                }
                else
                {
                  await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrMsg, BotID);
                  await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
                  threadMessages.Add(msg);
                  return;
                }
              }
            }
            break;
          default:
            await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrMsg, BotID);
            await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
            threadMessages.Add(msg);
            return;
        }

        if (duty != Config.EternalDuty.ToLower())
        {
          if (teamLeads.Contains(replacing) || intern.Contains(replacing) ||
              teamLeads.Contains(duty) || intern.Contains(duty))
          {
            await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, JokeMsg, BotID);
            await ToMattermost.PutReactionPost(msg, "skoratov", BotID);
            threadMessages.Add(msg);
            return;
          }
        }
        else
        {
          if (teamLeads.Contains(replacing) || intern.Contains(replacing) ||
              intern.Contains(duty))
          {
            await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, JokeMsg, BotID);
            await ToMattermost.PutReactionPost(msg, "skoratov", BotID);
            threadMessages.Add(msg);
            return;
          }
        }

        bool needReplacingReaction = true;
        if (!teamLeads.Contains(authorMsg))
        {
          foreach (var reaction in msgReactions)
          {
            if (string.Compare(reaction.Item1.ToLower(), replacing.ToLower()) == 0)
            {
              if (allAgreeReactions.Contains(reaction.Item2))
              {
                ToMattermost.RemoveReactionPost(msg, "question");
                needReplacingReaction = false;
                break;
              }
              else
              {
                if (allDisagreeReactions.Contains(reaction.Item2))
                {
                  ToMattermost.RemoveReactionPost(msg, "question");
                  ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, replacing + " " + UserRefusal, BotID);
                  ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
                  threadMessages.Add(msg);
                  return;
                }
              }
            }
          }
        }
        else
        {
          ToMattermost.RemoveReactionPost(msg, "question");
          needReplacingReaction = false;
        }
        if (needReplacingReaction)
        {
          await ToMattermost.PutReactionPost(msg, "question", BotID);
          return;
        }

        int dutyIdRecordInDutyHistory = 0;
        int replacingIdRecordInDutyHistory = 0;
        using (ApplicationContext db = new ApplicationContext())
        {
          var usr = db.Users.Where(x => x.Login.ToLower().Equals(duty.ToLower())).FirstOrDefault();
          var dutyRecordInDutyHistory = db.DutyHistorys
            .Where(x => x.Iduser == usr.Id && x.Date >= startDateOfWeek && x.Date <= endDateOfWeek)
            .ToList();
          //Рефакторинг
          //var dutyRecordInDutyHistory = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
          //    "where date between '{0}' and '{1}' and iduser = (select id from users where login ILIKE '{2}')",
          //    startDateOfWeek, endDateOfWeek, duty)).ToList();
          if (dutyRecordInDutyHistory.Count > 0)
          {
            if (dutyRecordInDutyHistory.Count > 1)
            {
              dutyRecordInDutyHistory = dutyRecordInDutyHistory.OrderBy(itm => itm.Date).ToList();
              dutyIdRecordInDutyHistory = dutyRecordInDutyHistory[0].Id;
            }
            else
            {
              dutyIdRecordInDutyHistory = dutyRecordInDutyHistory[0].Id;
            }
          }
          else
          {
            await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, duty + ErrAuthorNotDuty, BotID);
            await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
            threadMessages.Add(msg);
            return;
          }
          if (dutyRecordInDutyHistory[0].Date < DateTime.Today)
          {
            await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrDate, BotID);
            await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
            threadMessages.Add(msg);
            return;
          }
          if (!isSubstitutionDutyCmd)
          {
            var usrReplace = db.Users.Where(x => x.Login.ToLower().Equals(replacing.ToLower())).FirstOrDefault();
            var replacingRecordInDutyHistory = db.DutyHistorys
              .Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek && x.Iduser == usrReplace.Id)
              .ToList();
            //Рефакторинг.
            //var replacingRecordInDutyHistory = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
            //    "where date between '{0}' and '{1}' and iduser = (select id from users where login ILIKE '{2}')",
            //    startDateOfWeek, endDateOfWeek, replacing)).ToList();
            if ((replacingRecordInDutyHistory.Count != 0) && (replacingRecordInDutyHistory[0].Date < DateTime.Today))
            {
              await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrDate, BotID);
              await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
              threadMessages.Add(msg);
              return;
            }
            if (replacingRecordInDutyHistory.Count > 0)
            {
              if (replacingRecordInDutyHistory.Count > 1)
              {
                replacingRecordInDutyHistory = replacingRecordInDutyHistory.OrderByDescending(itm => itm.Date).ToList();
                replacingIdRecordInDutyHistory = replacingRecordInDutyHistory[0].Id;
              }
              else
              {
                replacingIdRecordInDutyHistory = replacingRecordInDutyHistory[0].Id;
              }
            }
          }
        }
        if (!isSubstitutionDutyCmd && ((replacingIdRecordInDutyHistory == 0) || (dutyIdRecordInDutyHistory == 0)))
        {
          await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrMsg, BotID);
          await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
          threadMessages.Add(msg);
          return;
        }
        if (isSubstitutionDutyCmd && (dutyIdRecordInDutyHistory == 0))
        {
          await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrMsg, BotID);
          await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
          threadMessages.Add(msg);
          return;
        }

        using (ApplicationContext db = new ApplicationContext())
        {
          if (dutyIdRecordInDutyHistory != 0)
          {
            var replaceUsr = db.Users.Where(x => x.Login.ToLower().Equals(replacing.ToLower())).FirstOrDefault();
            var newDuty = db.DutyHistorys.Where(x => x.Id == dutyIdRecordInDutyHistory).FirstOrDefault();
            newDuty.Iduser = replaceUsr.Id;
            db.SaveChanges();
            //Рефакторинг
            /*
            string query = string.Format("update dutyhistory set " +
                "iduser = (select id from users where login ILIKE '{0}') where id = {1}",
                replacing, dutyIdRecordInDutyHistory);
            db.Database.ExecuteSqlRaw(query);
            */
          }
          if (!isSubstitutionDutyCmd || replacingIdRecordInDutyHistory != 0)
          {
            var replaceUsr = db.Users.Where(x => x.Login.ToLower().Equals(duty.ToLower())).FirstOrDefault();
            var newDuty = db.DutyHistorys.Where(x => x.Id == replacingIdRecordInDutyHistory).FirstOrDefault();
            newDuty.Iduser = replaceUsr.Id;
            db.SaveChanges();
            //Рефакторинг.
            /*
            string query = string.Format("update dutyhistory set " +
                "iduser = (select id from users where login ILIKE '{0}') where id = {1}",
                duty, replacingIdRecordInDutyHistory);
            db.Database.ExecuteSqlRaw(query);
            */
          }

        }

        //сформировать сообщение, которое будет отправлено на редактирование имеющегося графика.
        List<Tuple<DateTime, string, string>> newDutyList = calculation.GetDutyList(intern, endDateOfWeek, startDateOfWeek);
        string post = GenerateMessage.GenerateDutyMsg(newDutyList, true);
        var data = new
        {
          is_pinned = true,
          message = post
        };
        string uriRewriteMessage = Config.ApiUrlPost + "/" + targetMessageID + "/patch";
        ToMattermost.PutMsgAsync(uriRewriteMessage, data);
        Console.WriteLine(string.Format("Инициатор замены: {0}. Заменяющий: {1}, заменяемый: {2}",
                        authorMsg, replacing, duty));
        await ToMattermost.PutReactionPost(msg, "done2", BotID);
      }
      else
      {
        await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrMsg, BotID);
        await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
        threadMessages.Add(msg);
      }
    }

    /// <summary>
    /// Варианты для замены 
    /// </summary>
    /// <param name="threadMessages">Список с ID обработанных сообщений.</param>
    /// <param name="targetMessageID">ID графика дежурств.</param>
    /// <param name="authorMsg">Автор сообщения.</param>
    /// <param name="msg">ID обрабатываемого сообщения.</param>
    /// <param name="endDateOfWeek">Дата конца недели графика дежурств.</param>
    /// <returns></returns>
    private static async Task DutyChangeOptions(List<string> threadMessages, string targetMessageID, string authorMsg,
                                                string msg, DateTime endDateOfWeek)
    {
      List<string> employees = new List<string>();
      string message = "Доступные варианты замены в день твоего дежурства:\n\r";
      using (ApplicationContext db = new ApplicationContext())
      {
        DateTime startDateOfWeek = calculation.GetFirstDateOfTargetWeek(endDateOfWeek);
        var usr = db.Users.Where(x => x.Login.ToLower().Equals(authorMsg.ToLower())).FirstOrDefault();
        var dutyDays = db.DutyHistorys
          .Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek && x.Iduser == usr.Id)
          .ToList();
        //рефакторинг
        //var dutyDays = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
        //      "where date between '{0}' and '{1}' and iduser = (select id from users where login ILIKE '{2}')",
        //      startDateOfWeek, endDateOfWeek, authorMsg)).ToList();
        if (dutyDays.Count() == 0)
        {
          await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, authorMsg + ErrAuthorNotDuty, BotID);
          await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
          threadMessages.Add(msg);
          return;
        }
        DateTime dutyDay = DateTime.Today;
        foreach (var d in dutyDays)
        {
          if (dutyDay < d.Date)
          {
            dutyDay = d.Date;
          }
        }
        var users = db.Users.Where(x => x.Employee_SPD && x.Duty == true).ToList();
        //Рефакторинг
        //var users = db.Users.FromSqlRaw("select * from users where Employee_SPD is true and duty is true").ToList();
        foreach (var user in users)
        {
          employees.Add(user.Login);
        }
        users = db.Users.ToList();
        var dutyHistory = db.DutyHistorys.Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek).ToList();
        var absence = db.Absences.Where(x => x.Date == dutyDay).ToList();
        //users = db.Users.FromSqlRaw("select * from users").ToList();
        //var dutyHistory = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
        //                    "where date between '{0}' and '{1}'", startDateOfWeek, endDateOfWeek)).ToList();
        //var absence = db.Absences.FromSqlRaw(string.Format("select * from absence where date = '{0}'", dutyDay)).ToList();
        var missingUsers = (from u in users
                            join a in absence on u.Id equals a.Iduser
                            select new { login = u.Login }).ToList();
        foreach (var miss in missingUsers)
        {
          if (employees.Contains(miss.login))
          {
            employees.Remove(miss.login);
          }
        }
        var dutyUsers = (from u in users
                         join d in dutyHistory on u.Id equals d.Iduser
                         select new { login = u.Login }).ToList();
        foreach (var duty in dutyUsers)
        {
          if (employees.Contains(duty.login))
          {
            employees.Remove(duty.login);
          }
        }
        foreach (var user in users)
        {
          if (employees.Contains(user.Login))
          {
            employees.Remove(user.Login);
            employees.Add(user.Fio);
          }
        }
      }
      employees.Sort();
      int index = 0;
      foreach (var employee in employees)
      {
        index++;
        message += index + ". " + employee + "\n\r";
      }

      var data = new
      {
        channel_id = Config.DutyChannalID,
        message = "@" + authorMsg + "\n\r" + message,
        root_id = targetMessageID
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(msg, "done2", BotID);
      threadMessages.Add(msg);
    }

    /// <summary>
    /// Вклинивание в график дежурств стажеров и доп дежурных без учета количества их отдежуренных смен данные вносятся во временную таблицу.
    /// </summary>
    /// <param name="threadMessages">Список с ID обработанных сообщений.</param>
    /// <param name="employees">Список сотрудников.</param>
    /// <param name="intern">Список стажеров.</param>
    /// <param name="targetMessageID">ID сообщения с графиком дежурств.</param>
    /// <param name="authorMsg">Автор сообщения.</param>
    /// <param name="msg">ID сообщения.</param>
    /// <param name="currentMsg">Текст сообщения.</param>
    /// <param name="endDateOfWeek">Дата конца недели графика дежурств.</param>
    /// <param name="isIntern">Cтажер (TRUE) или допдежурный (FALSE)</param>
    /// <returns></returns>
    private static async Task EternalDutyHelper(List<string> threadMessages, List<string> employees, List<string> teamLeads,
                                                List<string> intern, string targetMessageID, string authorMsg,
                                                string msg, string currentMsg, DateTime endDateOfWeek, bool isIntern)
    {

      DateTime startDateOfWeek = calculation.GetFirstDateOfTargetWeek(endDateOfWeek);
      List<DateTime> dutyDays = calculation.CurrentWorkingWeek(startDateOfWeek);
      List<DateTime> temporaryDutyDays = new List<DateTime> { };
      string temporaryDayOfWeek = "";
      Regex regexUsers = new Regex(@"@(\w*)");
      MatchCollection matchesUsers = regexUsers.Matches(currentMsg);
      string targetUser = "";
      if (matchesUsers.Count == 1)
      {
        bool isSpdEmployees = false;
        foreach (var user in matchesUsers)
        {
          //проверим, что пользак является сотрудником СПД
          if (!employees.Contains(user.ToString().ToLower().Trim('@')))
          {
            await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, NotEmployeesSPD, BotID);
            await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
            threadMessages.Add(msg);
            isSpdEmployees = true;
            break;
          }
        }
        if (isSpdEmployees)
        {
          return;
        }
      }
      else
      {
        await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, ErrMsg, BotID);
        await ToMattermost.PutReactionPost(msg, "no_entry_sign", BotID);
        threadMessages.Add(msg);
        return;
      }
      targetUser = matchesUsers[0].Value.ToString().ToLower().Trim('@');
      if (teamLeads.Contains(targetUser) || targetUser.Equals(Config.DutysResponsible.ToLower())
          || targetUser.Equals(Config.Supervisor) || targetUser.Equals("chirkov_ro"))
      {
        await ToMattermost.ErrorMsgReplace(targetMessageID, authorMsg, JokeMsg, BotID);
        await ToMattermost.PutReactionPost(msg, "skoratov", BotID);
        return;
      }
      currentMsg = regexUsers.Replace(currentMsg.ToLower(), "");
      currentMsg = currentMsg.Trim();
      Regex regexDutyDays = new Regex(@"(\w*)");
      MatchCollection matchDutyDays = regexDutyDays.Matches(currentMsg);
      foreach (var targetDutyDay in matchDutyDays)
      {
        string tmpDate = calculation.textToDayFormat(targetDutyDay.ToString());
        if (tmpDate != "")
        {
          temporaryDutyDays.Add(calculation.GetDayOfWeek(tmpDate, dutyDays));
        }
      }
      List<TmpDutyNotHistory> tmpDutyHistory = new List<TmpDutyNotHistory>();
      using (ApplicationContext db = new ApplicationContext())
      {
        tmpDutyHistory = db.TmpDutyNotHistorys.ToList();
        //Рефакторинг
        //tmpDutyHistory = db.TmpDutyNotHistorys.FromSqlRaw("SELECT * FROM tmpdutynothistory").ToList();
      }

      foreach (var dutyDay in temporaryDutyDays)
      {
        bool isDouble = false;
        using (ApplicationContext db = new ApplicationContext())
        {
          if (tmpDutyHistory.Count != 0)
          {
            foreach (var tmpDuty in tmpDutyHistory)
            {
              if (tmpDuty.login.ToLower().Equals(targetUser.ToLower())
                  && (tmpDuty.date == dutyDay) && (tmpDuty.isIntern == isIntern))
              {
                isDouble = true;
                continue;
              }
            }
          }
          if (isDouble)
          {
            continue;
          }
          ///EF не работает нормально с таблицыами без первичных ключей, надо использовать вьюху и корректировать DBConf
          //db.TmpDutyNotHistorys.Add(new TmpDutyNotHistory
          //{
          //  date = dutyDay,
          //  login = targetUser,
          //  isIntern = isIntern
          //});
          //db.SaveChanges();
          string query = string.Format("INSERT INTO tmpDutyNotHistory (date, login, isintern) VALUES ('{0}','{1}', {2})",
              dutyDay.ToString("yyyy-MM-dd"), targetUser, isIntern);
          db.Database.ExecuteSqlRaw(query);
        }
        temporaryDayOfWeek += ", " + dutyDay.DayOfWeek;
      }
      List<Tuple<DateTime, string, string>> DutyList = calculation.GetDutyList(intern, endDateOfWeek, startDateOfWeek);
      string post = GenerateMessage.GenerateDutyMsg(DutyList, true);
      var data = new
      {
        is_pinned = true,
        message = post
      };
      string uriRewriteMessage = Config.ApiUrlPost + "/" + targetMessageID + "/patch";
      ToMattermost.PutMsgAsync(uriRewriteMessage, data);
      temporaryDayOfWeek = temporaryDayOfWeek.Trim(',');
      Console.WriteLine(string.Format("Инициатор добавления в дежурства: {0}. Добавлен в график {1}: {2}. Дни дежурства:{3}",
                      authorMsg, isIntern ? "стажер" : "дополнительный дежурный", targetUser, temporaryDayOfWeek));
      await ToMattermost.PutReactionPost(msg, "done2", BotID);
      threadMessages.Add(msg);
    }

    /// <summary>
    /// Cписок людей и количество отдежурненных смен в текущем году.
    /// </summary>
    /// <param name="threadMessages">Список с ID обработанных сообщений.</param>
    /// <param name="targetMessageID">ID графика дежурств.</param>
    /// <param name="msg">ID обрабатываемого сообщения.</param>
    /// <returns></returns>
    private static async Task GenerateRating(List<string> threadMessages, string targetMessageID, string msg)
    {
      List<UsersList> dutyList = new List<UsersList> { };
      List<string> employees = new List<string>();
      int index = 1;
      string message = $"Количество дежурств по состоянию на {DateTime.Now}:\n\r";
      using (ApplicationContext db = new ApplicationContext())
      {
        var login = db.Users.Where(x => x.Employee_SPD && !x.Intern).ToList();
        //Рефакторинг
        //var login = db.Users.FromSqlRaw("SELECT * FROM users where Employee_SPD is true and intern is false").ToList();
        foreach (User u in login)
        {
          var startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
          var endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31);
          int tmpShiftsNumber = db.DutyHistorys.Where(x => x.Iduser == u.Id && x.Date >= startYear && x.Date <= endYear).Count();
          //рефакторинг
          //int tmpShiftsNumber = db.DutyHistorys.FromSqlRaw($"SELECT id FROM DutyHistory " +
          //    $"where iduser = {u.Id} and date between '{startYear}' and '{endYear}'").Count();
          if (!u.Login.ToLower().Equals(Config.EternalDuty.ToLower()))
          {
            dutyList.Add(new UsersList(u.Login, tmpShiftsNumber, u.Team, u.Fio));
          }
        }
        dutyList = dutyList.OrderBy(itm => itm.shiftsNumber).ToList();
      }
      foreach (var duty in dutyList)
      {
        if (duty.shiftsNumber != 0)
        {
          message += index + ". " + duty.fio.Remove(duty.fio.LastIndexOf(" ")) + " - " + duty.shiftsNumber + "\n\r";
          index++;
        }
      }
      var data = new
      {
        channel_id = Config.DutyChannalID,
        message = message,
        root_id = targetMessageID
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(msg, "done2", BotID);
      threadMessages.Add(msg);
    }

    /// <summary>
    /// Шуточная команда для отправки сообщения в личные сообщения указанного человека от имени бота.
    /// </summary>
    /// <param name="threadMessages">Список ID обработанных сообщений.</param>
    /// <param name="msg">ID сообщения с командой.</param>
    /// <param name="currentMsg">Текст сообщения.</param>
    private static async void ZaebaCmd(List<string> threadMessages, string msg, string currentMsg, string author)
    {
      string message = "Да ты заебал!";
      string channel = "";
      User usr;
      Regex regexUsers = new Regex(@"@(\w*)");
      MatchCollection matchesUsers = regexUsers.Matches(currentMsg);
      if (matchesUsers.Count == 0)
      {
        await ToMattermost.PutReactionPost(msg, "skoratov", BotID);
        threadMessages.Add(msg);
        return;
      }
      string targetUser = matchesUsers[0].Value.ToString().ToLower().Trim('@');
      using (ApplicationContext db = new ApplicationContext())
      {
        usr = db.Users.Where(x => x.Login.ToLower().Equals(targetUser.ToLower())).FirstOrDefault();
        if (usr == null)
        {
          await ToMattermost.PutReactionPost(msg, "skoratov", BotID);
          threadMessages.Add(msg);
          return;
        }
        channel = db.DirectChannels.Where(x => x.Iduser == usr.Id)
          .Select(x => x.Idchannel)
          .FirstOrDefault();
        //Рефакторинг
        //channel = db.DirectChannels.FromSqlRaw($"SELECT * FROM directchannel " +
        //    $"where iduser = (select id from users where login ILIKE '{targetUser}')")
        //    .Select(x => x.Idchannel)
        //    .FirstOrDefault();
      }
      if (channel == null)
      {
        await ToMattermost.PutReactionPost(msg, "skoratov", BotID);
        threadMessages.Add(msg);
        return;
      }
      var data = new
      {
        channel_id = channel,
        message = message,
      };
      await ToMattermost.PostMsgAsync(Config.ApiUrlPost, BotID, data, false);
      await ToMattermost.PutReactionPost(msg, "ed_dovolen", BotID);
      threadMessages.Add(msg);
      Logger.WriteDirectLog($"{author} попросил отправить бота сообщение {usr.Login} о том, что он его заебал.");
    }
  }
}