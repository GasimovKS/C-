﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using static System.Net.WebRequestMethods;

namespace spd_bot_sparrow
{
  internal class calculation
  {
    /// <summary>
    /// Метод для получения крайнего дня дежурств в БД.
    /// </summary>
    /// <param name="endDateOfWeek"></param>
    /// <returns>Возращает крайний день в графике дежурств</returns>
    public static DateTime GetEndDateOfWeek(DateTime endDateOfWeek = default(DateTime))
    {
      if (endDateOfWeek == default(DateTime))
      {
        using (ApplicationContext db = new ApplicationContext())
        {
          var tmpList = new List<DateTime>();
          endDateOfWeek = db.DutyHistorys.Select(x => x.Date).Max();
          //Рефакторинг
          /*var tmp = db.DutyHistorys.FromSqlRaw("select * from dutyhistory order by date desc limit 20").ToList();
          foreach (var item in tmp)
          {
            tmpList.Add(item.Date);
          }
          endDateOfWeek = tmpList.Max();*/
        }
      }
      else
      {
        using (ApplicationContext db = new ApplicationContext())
        {

          endDateOfWeek = db.DutyHistorys.Where(x => x.Date <= endDateOfWeek).Select(x => x.Date).Max().Date;
          //Рефакторинг
          /*
          var tmpList = new List<DateTime>();
          var tmp = db.DutyHistorys.FromSqlRaw($"select * from dutyhistory where date <= '{endDateOfWeek}' order by date desc limit 20").ToList();
          foreach (var item in tmp)
          {
            tmpList.Add(item.Date);
          }
          endDateOfWeek = tmpList.Max();*/
        }
      }
      return endDateOfWeek;
    }

    /// <summary>
    /// Метод предназначен для вычисления даты понедельника следующей недели.
    /// </summary>
    /// <returns>Метод возвращает дату понедельника следующей недели в формате 01.01.0001 00:00:00</returns>
    public static DateTime GetFirstDateOfNextWeek(DateTime firstDay = default(DateTime))
    {
      if (firstDay == default(DateTime))
      {
        firstDay = DateTime.Today.AddDays(7);
      }
      while (firstDay.DayOfWeek != DayOfWeek.Monday)
        firstDay = firstDay.AddDays(-1); //понедельник следующей недели
      return firstDay;
    }
    /// <summary>
    /// Метод предназначен для вычисления даты понедельника недели
    /// </summary>
    /// <returns>Метод возвращает дату понедельника следующей недели в формате 01.01.0001 00:00:00</returns>
    public static DateTime GetFirstDateOfTargetWeek(DateTime firstDay)
    {
      while (firstDay.DayOfWeek != DayOfWeek.Monday)
        firstDay = firstDay.AddDays(-1); //понедельник недели
      return firstDay;
    }
    /// <summary>
    /// Метод предназначен для вычисления даты крайнего рабочего дня текущей недели
    /// </summary>
    /// <returns>Метод возвращает дату понедельника следующей недели в формате 01.01.0001 00:00:00</returns>
    public static DateTime GetLastDateOfThisWeek()
    {
      return CurrentWorkingWeek().Max();
    }
    /// <summary>
    /// Выполняет проверку наличия в СПД "Вечного" дежурного в принципе и, при наличии, проверяет находится ли он в отпуке или на больничном
    /// </summary>
    /// <returns>Возвращает True, если есть "Вечный" дежурный и он не отпустствует</returns>
    public static bool EternalDuty(DateTime currentDay)
    {
      if (Config.EternalDuty != "")
      {
        using (ApplicationContext db = new ApplicationContext())
        {
          int idEternal = db.Users.Where(x => x.Login.ToLower().Equals(Config.EternalDuty.ToLower())).Select(x => x.Id).FirstOrDefault();
          if (idEternal == 0)
            return false;
          int countAbsence = db.Absences.Where(x => x.Date == currentDay && x.Iduser == idEternal).Count();
          //Рефкторинг
          /*int countAbsence = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
              $"(select users.id from users where users.login = '{Config.EternalDuty.ToLower()}') and date = '{currentDay}'").Count();
          DateTime lastDay = GetLastDateOfThisWeek();
          int countWednesday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
              $"(select users.id from users where users.login = '{Config.EternalDuty}') and date = '{DateTime.Now.AddDays(-2)}'").Count();
          int countThursday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
              $"(select users.id from users where users.login = '{Config.EternalDuty.ToLower()}') and date = '{lastDay.AddDays(-1)}'").Count();
          int countFriday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
              $"(select users.id from users where users.login = '{Config.EternalDuty.ToLower()}') and date = '{lastDay}'").Count();
          если отсутствует 2 дня подряд, включая день публикации графика, то может более или в отпуске, тогда следующую неделю не дежурит, удаляем из списка
          if ((countThursday != 0) && (countFriday != 0)) //((countWednesday != 0) && (countThursday != 0) && (countFriday != 0))
          {
            return false;
          }*/
          if (countAbsence == 0)
            return true;
          else
            return false;
        }
      }
      else
        return false;
    }
    /// <summary>
    /// Получаем рабочие дни текущей недели из календаря рабочих дней в БД
    /// </summary>
    /// <returns>Возвращает список рабочих дней на следующей неделе типа List</returns>
    public static List<DateTime> CurrentWorkingWeek(DateTime firstDayOfDutyWeek = default(DateTime))
    {
      var dateList = new List<DateTime>();
      if (firstDayOfDutyWeek == default(DateTime))
      {
        firstDayOfDutyWeek = GetFirstDateOfNextWeek().AddDays(-7);
      }
      using (ApplicationContext db = new ApplicationContext())
      {
        dateList = db.Calendars.Where(x => x.Iswork && x.Date >= firstDayOfDutyWeek && x.Date <= firstDayOfDutyWeek.AddDays(6))
          .Select(x => x.Date).ToList();
        //Рефакторинг        
        /*var calendar = db.Calendars.FromSqlRaw(string.Format("select * from calendar where date between '{0}' and '{1}' and iswork is true",
        //firstDayOfDutyWeek.ToString("dd.MM.yyyy"), firstDayOfDutyWeek.AddDays(6).ToString("dd.MM.yyyy"))).ToList();
        foreach (Calendar cal in calendar)
        {
          dateList.Add(cal.Date);
        }*/
      }
      if (dateList.Count == 0)
      {
        dateList = CurrentWorkingWeek(firstDayOfDutyWeek.AddDays(7));
      }
      return dateList;
    }

    /// <summary>
    /// Получаем рабочие дни на будущей неделе из календаря рабочих дней в БД
    /// </summary>
    /// <returns>Возвращает список рабочих дней на следующей неделе типа List</returns>
    public static List<DateTime> NextWorkingWeek(DateTime firstDayOfDutyWeek = default(DateTime))
    {
      var dateList = new List<DateTime>();
      if (firstDayOfDutyWeek == default(DateTime))
      {
        firstDayOfDutyWeek = GetFirstDateOfNextWeek();
      }
      using (ApplicationContext db = new ApplicationContext())
      {
        dateList = db.Calendars.Where(x => x.Iswork && x.Date >= firstDayOfDutyWeek && x.Date <= firstDayOfDutyWeek.AddDays(6))
                  .Select(x => x.Date).ToList();
        //Рефакторинг
        /*var calendar = db.Calendars.FromSqlRaw(string.Format("select * from calendar where date between '{0}' and '{1}' and iswork is true",
        firstDayOfDutyWeek.ToString("dd.MM.yyyy"), firstDayOfDutyWeek.AddDays(6).ToString("dd.MM.yyyy"))).ToList();
        foreach (Calendar cal in calendar)
        {
          dateList.Add(cal.Date);
        }*/
      }
      if (dateList.Count == 0)
      {
        dateList = NextWorkingWeek(firstDayOfDutyWeek.AddDays(7));
      }
      dateList.Sort();
      return dateList;
    }
    /// <summary>
    /// Генерирует даты конца следующей рабочей недели.
    /// </summary>
    /// <returns>Возвращает дату и время следующего запуска генерации списка дежурств</returns>
    public static async Task<DateTime> NextGeneratingDate()
    {
#if !DEBUG
      if (DateTime.Today < CurrentWorkingWeek().Max())
      {
        return CurrentWorkingWeek().Max().AddHours(8);
      }
      else
      if (DateTime.Today == CurrentWorkingWeek().Max())
      {
        var uri = Config.ApiUrlChannel + "/" + Config.DutyChannalID + "/posts";
        uri += "?since=" + DateTimeOffset.Now.AddHours(-20).ToUnixTimeMilliseconds();
        Int64 unixTime = DateTimeOffset.Now.AddHours(-20).ToUnixTimeMilliseconds();
        string top = "";
        string userID = Config.BotID;
        Int64 timeTopMsg;
        top = (await ToMattermost.FindLastBotMessage(uri, userID)).ToString();
        uri = Config.ApiUrlPost + "/" + top;
        if (top == "")
        {
          return DateTime.Today.AddHours(8);
        }
        else
        {
          timeTopMsg = (await ToMattermost.GetMessageTime(uri, userID));
          if (timeTopMsg < unixTime)
          {
            return DateTime.Now;
          }
          else
          {
            return NextWorkingWeek().Max().AddHours(8);
          }
        }
      }
      else
      {
        return NextWorkingWeek().Max().AddHours(8);
      }

#endif
#if DEBUG
      return DateTime.Now.AddMinutes(10);
#endif

    }


    /// <summary>
    /// вычисляем график дежурств
    /// </summary>
    /// <param name="dateList"></param>
    /// <returns></returns>
    public static void GenerateList(List<DateTime> dateList, List<Tuple<DateTime, string, string>> duty)
    {
      List<UsersList> dutyList = new List<UsersList>();

      using (ApplicationContext db = new ApplicationContext())
      {
        //Получаем список людей, которые могут быть дежурными и их количество отдежуренных смен
        var login = db.Users.Where(x => x.Duty == true && x.Employee_SPD).ToList();
        //Рефакторинг
        //var login = db.Users.FromSqlRaw("SELECT * FROM users where Employee_SPD is true and duty is true").ToList();
        foreach (User u in login)
        {
          if (u.Login.ToLower() == Config.EternalDuty.ToLower())
          {
            continue;
          }
          var startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
          var endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31);
          //Рефакторинг
          int tmpShiftsNumber = db.DutyHistorys.Where(x => x.Iduser == u.Id && x.Date >= startYear && x.Date <= endYear).Count();
          //int tmpShiftsNumber = db.DutyHistorys.FromSqlRaw($"SELECT id FROM DutyHistory " +
          //    $"where iduser = {u.Id} and date between '{startYear}' and '{endYear}'").Count();
          dutyList.Add(new UsersList(u.Login, tmpShiftsNumber, u.Team, u.Fio));
        }
        dutyList = dutyList.OrderBy(itm => itm.shiftsNumber).ToList();
      }
      var tmpDateList = NextWorkingWeek();
      tmpDateList.Sort();
      for (int indexDate = 0; indexDate < dateList.Count; indexDate++)
      {
        bool secondPass = duty.Exists(d => d.Item1 == dateList[indexDate]);
        for (int index = 0; index < dutyList.Count; index++)
        {
          int countAbsence, countFriday, countThursday;
          int countPreferences = 0;

          using (ApplicationContext db = new ApplicationContext())
          {
            /* to prod
            countAbsence = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{dateList[indexDate]}'").Count();
            //countWednesday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                //$"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{DateTime.Now.AddDays(-2)}'").Count();
            countThursday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{DateTime.Now.AddDays(-1)}'").Count();
            countFriday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{DateTime.Now}'").Count();
            countPreferences = db.Preferences.FromSqlRaw($"SELECT * FROM Preferences where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and {dateList[indexDate].DayOfWeek} is true").Count();
            */

            //for debug
            DateTime lastDay = GetLastDateOfThisWeek();
            int idDuty = db.Users.Where(x => x.Login.ToLower().Equals(dutyList[index].userLogin.ToLower())).Select(x => x.Id).First();
            countAbsence = db.Absences.Where(x => x.Iduser == idDuty && x.Date == dateList[indexDate]).Count();
            countThursday = db.Absences.Where(x => x.Iduser == idDuty && x.Date == lastDay.AddDays(-1)).Count();
            countFriday = db.Absences.Where(x => x.Iduser == idDuty && x.Date == lastDay).Count();
            var userPreferences = db.Preferences.Where(x => x.Iduser == idDuty).FirstOrDefault();
            if (userPreferences != null)
            {
              switch (dateList[indexDate].DayOfWeek)
              {
                case DayOfWeek.Sunday:
                  if (userPreferences.Sunday)
                    countPreferences++;
                  break;
                case DayOfWeek.Monday:
                  if (userPreferences.Monday)
                    countPreferences++;
                  break;
                case DayOfWeek.Tuesday:
                  if (userPreferences.Tuesday)
                    countPreferences++;
                  break;
                case DayOfWeek.Wednesday:
                  if (userPreferences.Wednesday)
                    countPreferences++;
                  break;
                case DayOfWeek.Thursday:
                  if (userPreferences.Thursday)
                    countPreferences++;
                  break;
                case DayOfWeek.Friday:
                  if (userPreferences.Friday)
                    countPreferences++;
                  break;
                case DayOfWeek.Saturday:
                  if (userPreferences.Saturday)
                    countPreferences++;
                  break;
                default:
                  break;
              }
            }
            /*
            countAbsence = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{dateList[indexDate]}'").Count();
            countThursday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{lastDay.AddDays(-1)}'").Count();
            countFriday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{lastDay}'").Count();
            countPreferences = db.Preferences.FromSqlRaw($"SELECT * FROM Preferences where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and {dateList[indexDate].DayOfWeek} is true").Count();
            */
          }
          //если отсутствует 2 дня подряд, включая день публикации графика, то может более или в отпуске, тогда следующую неделю не дежурит, удаляем из списка
          if ((countThursday != 0) && (countFriday != 0)) //((countWednesday != 0) && (countThursday != 0) && (countFriday != 0))
          {
            dutyList.Remove(new UsersList { userLogin = dutyList[index].userLogin, shiftsNumber = dutyList[index].shiftsNumber, team = dutyList[index].team, fio = dutyList[index].fio });
            index--;
            continue;
          }
          //если отсутствует только в день публикации графика, то не дежурит в первый рабочий день недели.
          if ((countFriday != 0) && (dateList[indexDate] == tmpDateList.Min()))
          {
            continue;
          }
          if ((countAbsence == 0) && (countPreferences == 1) && (duty.Count == 0 ? true : duty[duty.Count - 1].Item2 != dutyList[index].userLogin))
          {
            if (duty.Exists(tmp => tmp.Item2 == dutyList[index].userLogin))
            {
              dutyList.Remove(new UsersList { userLogin = dutyList[index].userLogin, shiftsNumber = dutyList[index].shiftsNumber, team = dutyList[index].team, fio = dutyList[index].fio });
              index--;
              continue;
            }
            else
            {
              if (duty.Exists(d => d.Item1 == dateList[indexDate]) &&
                  ((duty.Find(d => d.Item1 == dateList[indexDate]).Item2 == dutyList[index].userLogin) ||
                  (duty.Find(d => d.Item1 == dateList[indexDate]).Item3 == dutyList[index].team)))
              {
                continue;
              }
              duty.Add(new Tuple<DateTime, string, string>(dateList[indexDate], dutyList[index].userLogin, dutyList[index].team));
              dutyList.Remove(new UsersList { userLogin = dutyList[index].userLogin, shiftsNumber = dutyList[index].shiftsNumber, team = dutyList[index].team, fio = dutyList[index].fio });
              if (EternalDuty(dateList[indexDate]) || secondPass)
              {
                dateList.RemoveAt(indexDate);
                indexDate--;
                break;
              }

              else
              {
                secondPass = true;
              }
            }
          }
          if (dutyList.Count == 0)
          {
            break;
          }
        }
        if (dateList.Count == 0)
        {
          break;
        }

        //подумать над этими условиями, где то тут бага

      }
      //return duty;
    }
    /// <summary>
    /// При генерации не учитываются пожелания, т.к. не хватает сотрудников (прошло 3 итерации заполнения списка)
    /// </summary>
    /// <param name="tmpDateList">Список дат, на которые надо заполнить дежурных</param>
    /// <returns></returns>
    public static void GenerateWithoutPreference(List<DateTime> dateList, List<Tuple<DateTime, string, string>> duty, int iteration = 0)
    {
      List<UsersList> dutyList = new List<UsersList>();
      using (ApplicationContext db = new ApplicationContext())
      {
        //Получаем список людей, которые могут быть дежурными и их количество отдежуренных смен
        var login = db.Users.Where(x => x.Duty == true && x.Employee_SPD).ToList();
        //Рефакторинг
        //var login = db.Users.FromSqlRaw("SELECT * FROM users where Employee_SPD is true and duty is true").ToList();
        foreach (User u in login)
        {
          if (u.Login.ToLower() == Config.EternalDuty.ToLower())
            continue;
          var startYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 1, 1);
          var endYear = new DateTime(int.Parse(DateTime.Today.ToString("yyyy")), 12, 31);
          int tmpShiftsNumber = db.DutyHistorys.Where(x => x.Iduser == u.Id && x.Date >= startYear && x.Date <= endYear).Count();
          //int tmpShiftsNumber = db.DutyHistorys.FromSqlRaw($"SELECT id FROM DutyHistory " +
          //    $"where iduser = {u.Id} and date between '{startYear}' and '{endYear}'").Count();
          dutyList.Add(new UsersList(u.Login, tmpShiftsNumber, u.Team, u.Fio));
        }
        dutyList = dutyList.OrderBy(itm => itm.shiftsNumber).ToList();
      }
      var tmpDateList = NextWorkingWeek();

      for (int indexDate = 0; indexDate < dateList.Count; indexDate++)
      {
        bool secondPass = duty.Exists(d => d.Item1 == dateList[indexDate]);
        for (int index = 0; index < dutyList.Count; index++)
        {
          int countAbsence, countPreferences, countFriday, countThursday;

          using (ApplicationContext db = new ApplicationContext())
          {
            /*prod
            countAbsence = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{dateList[indexDate]}'").Count();
            //countWednesday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = (select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{DateTime.Now.AddDays(-2)}'").Count();
            countThursday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{DateTime.Now.AddDays(-1)}'").Count();
            countFriday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{DateTime.Now}'").Count();
            //countPreferences = db.Preferences.FromSqlRaw($"SELECT * FROM Preferences where iduser = (select users.id from users where users.login = '{dutyList[index].userLogin}') and {dateList[indexDate].DayOfWeek} is true").Count();
            */
            DateTime lastDay = GetLastDateOfThisWeek();
            int idDuty = db.Users.Where(x => x.Login.ToLower().Equals(dutyList[index].userLogin.ToLower())).Select(x => x.Id).First();
            countAbsence = db.Absences.Where(x => x.Iduser == idDuty && x.Date == dateList[indexDate]).Count();
            countThursday = db.Absences.Where(x => x.Iduser == idDuty && x.Date == lastDay.AddDays(-1)).Count();
            countFriday = db.Absences.Where(x => x.Iduser == idDuty && x.Date == lastDay).Count();

            /*countAbsence = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{dateList[indexDate]}'").Count();
            countThursday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{lastDay.AddDays(-1)}'").Count();
            countFriday = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and date = '{lastDay}'").Count();
            countPreferences = db.Preferences.FromSqlRaw($"SELECT * FROM Preferences where iduser = " +
                $"(select users.id from users where users.login = '{dutyList[index].userLogin}') and {dateList[indexDate].DayOfWeek} is true").Count();
            */
          }
          //если отсутствует 3 дня подряд, включая день публикации графика, то может более или в отпуске, тогда следующую неделю не дежурит, удаляем из списка
          if ((countThursday != 0) && (countFriday != 0)) //((countWednesday != 0) && (countThursday != 0) && (countFriday != 0))
          {
            dutyList.Remove(new UsersList { userLogin = dutyList[index].userLogin, shiftsNumber = dutyList[index].shiftsNumber, team = dutyList[index].team, fio = dutyList[index].fio });
            index--;
            continue;
          }
          //если отсутствует в день публикации, то не дежурит в первый рабочий день недели.
          if ((countFriday != 0) && (dateList[indexDate] == tmpDateList.Min()))
          {
            continue;
          }

          if ((countAbsence == 0) && (duty.Count == 0 ? true : duty[duty.Count - 1].Item2 != dutyList[index].userLogin))
          {
            if ((iteration <= 3) && duty.Exists(tmp => tmp.Item2 == dutyList[index].userLogin))
            {
              dutyList.Remove(new UsersList { userLogin = dutyList[index].userLogin, shiftsNumber = dutyList[index].shiftsNumber, team = dutyList[index].team, fio = dutyList[index].fio });
              index--;
              continue;
            }
            else
            {
              if ((iteration <= 3) && duty.Exists(d => d.Item1 == dateList[indexDate]) &&
                  ((duty.Find(d => d.Item1 == dateList[indexDate]).Item2 == dutyList[index].userLogin) ||
                  (duty.Find(d => d.Item1 == dateList[indexDate]).Item3 == dutyList[index].team)))
              {
                continue;
              }
              if (duty.Exists(d => d.Item1 == dateList[indexDate]) &&
                  (duty.Find(d => d.Item1 == dateList[indexDate]).Item2 == dutyList[index].userLogin))
              {
                continue;
              }

              duty.Add(new Tuple<DateTime, string, string>(dateList[indexDate], dutyList[index].userLogin, dutyList[index].team));
              dutyList.Remove(new UsersList { userLogin = dutyList[index].userLogin, shiftsNumber = dutyList[index].shiftsNumber, team = dutyList[index].team, fio = dutyList[index].fio });
              if (EternalDuty(dateList[indexDate]) || secondPass)
              {
                dateList.RemoveAt(indexDate);
                indexDate--;
                break;
              }
              else
              {
                secondPass = true;
              }
            }

          }
          if (duty.Count == 0)
          {
            break;
          }
        }

      }
    }
    /// <summary>
    /// Метод генерирует список дежурных с датами дежурств из сгенерированного сообщения
    /// </summary>
    /// <returns>Возвращает отпаршенный график дежурств с днями и дежурными</returns>
    public static List<Tuple<DateTime, string>> ParseDutyListAsync()
    {
      var dateList = NextWorkingWeek();
      while (true)
      {
        if ((Interplay.MessageID == null) || Interplay.MessageID.Equals(""))
        {
          Thread.Sleep(60000);
        }
        else
        {
          break;
        }
      }
      string uri = Config.ApiUrlPost + "/" + Interplay.MessageID; //формируем строку для получения тела сообщения
      List<Tuple<DateTime, string>> duty = new List<Tuple<DateTime, string>>();
      List<string> DutyMsg = new List<string>(ToMattermost.GetMessage(uri).Result.Split("\r\n")); //получаем тело сообещения и парсим строку в список
      DutyMsg.RemoveAt(0);
      DutyMsg.RemoveAt(DutyMsg.Count - 1);
      DutyMsg.RemoveAt(DutyMsg.Count - 1);
      DutyMsg.RemoveAt(DutyMsg.Count - 1);
      try
      {
        int indexDate = 0;
        foreach (var l in DutyMsg)
        {
          Regex regex = new Regex(@"@(\w*)");
          MatchCollection matches = regex.Matches(l);
          if (matches.Count > 0)
            foreach (Match match in matches)
              duty.Add(new Tuple<DateTime, string>(dateList[indexDate], match.Value.TrimStart('@')));
          indexDate++;
        }
      }
      catch (Exception e)
      {
        duty.Clear();
        Console.WriteLine("{0}. Количестово дней в списке рабочих дней значительно больше чем рабочих дней в графике дежурств. " +
            "Ошибка:", DateTime.Now);
        Console.WriteLine(e);
        Console.WriteLine("Данные истории не записаны");
        Logger.WriteLog($"Количестово дней в списке рабочих дней значительно больше чем рабочих дней в графике дежурств. Ошибка: \r " +
            $"{e}\r Данные истории не записаны");
        return duty;
      }
      return duty;
    }
    /// <summary>
    /// Генерирация списка стажеров 
    /// </summary>
    /// <param name="isRewriteSchedule">Перегенерация существующего графика</param>
    /// <returns>Возвращает список стажеров для генерации графика</returns>
    public static List<string> GenerateInternList(bool isRewriteSchedule = false, bool isPreviously = false)
    {

      List<DateTime> dateList = new List<DateTime>();
      List<string> intern = new List<string>();
      if (isRewriteSchedule)
      {
        DateTime endDateOfWeek = GetEndDateOfWeek();
        if (isPreviously)
        {
          endDateOfWeek = GetEndDateOfWeek(GetFirstDateOfTargetWeek(endDateOfWeek).AddDays(-1));
        }
        DateTime startDateOfWeek = GetFirstDateOfTargetWeek(endDateOfWeek);
        using (ApplicationContext db = new ApplicationContext())
        {
          var dutyHistorys = db.DutyHistorys.Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek).ToList();
          //Рефакторинг
          //var dutyHistorys = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
          //            "where date between '{0}' and '{1}'", startDateOfWeek, endDateOfWeek)).ToList();
          foreach (var dutyHistory in dutyHistorys)
          {
            if (!dateList.Contains(dutyHistory.Date))
            {
              dateList.Add(dutyHistory.Date);
            }
          }
        }

      }
      else
      {
        dateList = NextWorkingWeek();
      }
      dateList.Sort();
      using (ApplicationContext db = new ApplicationContext())
      {
        var users = db.Users.Where(x => x.Intern && x.Employee_SPD).ToList();
        //Рефакторинг
        //var users = db.Users.FromSqlRaw("SELECT * FROM users where intern is true and Employee_SPD is true").ToList();
        foreach (DateTime targetDate in dateList)
        {
          string tmpStr = "";
          foreach (User u in users)
          {
            int tmpCount = db.Absences.Where(x => x.Date == targetDate && x.Iduser == u.Id).Count();
            //Рефакторинг
            //var tmpCount = db.Absences.FromSqlRaw($"SELECT * FROM absence where iduser = " +
            //    $"(select users.id from users where users.login = '{u.Login}') and date = '{targetDate}'").Count();
            if (tmpCount == 0)
            {
              if (tmpStr == "")
                tmpStr += "@" + u.Login;
              else
                tmpStr += " / @" + u.Login;
            }
          }
          //string tmpstr = string.Format("SELECT * FROM tmpdutynothistory where isintern is true and date = '{0}'", targetDate);
          var tmpInterns = db.TmpDutyNotHistorys.Where(x => x.isIntern && x.date == targetDate).ToList();
          //var tmpInterns = db.TmpDutyNotHistorys.FromSqlRaw($"SELECT * FROM tmpdutynothistory where isintern is true and date = '{targetDate}'").ToList();
          if (tmpInterns.Count != 0)
          {
            foreach (var tmpIntern in tmpInterns)
            {
              if (tmpIntern.date.Equals(targetDate))
              {
                if (tmpStr == "")
                  tmpStr += "@" + tmpIntern.login;
                else
                  tmpStr += " / @" + tmpIntern.login;
              }
            }
          }
          if (tmpStr == "")
            tmpStr = "Оба дежурных регистрируют общую папку";
          else
            tmpStr += " - регистрация общей папки";
          intern.Add(tmpStr);
        }
        return intern;
      }
    }
    /// <summary>
    /// Метод генерирует список временных (не постоянных) дежурных, к примеру, сотрудников первой категории на пару дней дежурств
    /// </summary>
    /// <param name="isRewriteSchedule"></param>
    /// <returns>возвращает список временных дежурных для практики</returns>
    public static List<string> GenerateTmpDutyList(bool isRewriteSchedule = false, bool isPreviously = false)
    {
      List<string> tmpDutyList = new List<string> { };
      List<DateTime> dateList = new List<DateTime>();
      if (isRewriteSchedule)
      {
        DateTime endDateOfWeek = calculation.GetEndDateOfWeek();
        if (isPreviously)
        {
          endDateOfWeek = calculation.GetEndDateOfWeek(calculation.GetFirstDateOfTargetWeek(endDateOfWeek).AddDays(-1));
        }
        DateTime startDateOfWeek = calculation.GetFirstDateOfTargetWeek(endDateOfWeek);
        using (ApplicationContext db = new ApplicationContext())
        {
          var dutyHistorys = db.DutyHistorys.Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek).ToList();
          //Рефакторинг
          //var dutyHistorys = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
          //            "where date between '{0}' and '{1}'", startDateOfWeek, endDateOfWeek)).ToList();
          foreach (var dutyHistory in dutyHistorys)
          {
            if (!dateList.Contains(dutyHistory.Date))
            {
              dateList.Add(dutyHistory.Date);
            }
          }
        }

      }
      else
      {
        dateList = NextWorkingWeek();
      }
      dateList.Sort();
      using (ApplicationContext db = new ApplicationContext())
      {
        foreach (DateTime targetDate in dateList)
        {
          string tmpStr = "";
          var tmpDutys = db.TmpDutyNotHistorys.Where(x => !x.isIntern && x.date == targetDate).ToList();
          //Рефакторинг
          //var tmpDutys = db.TmpDutyNotHistorys.FromSqlRaw($"SELECT * FROM tmpdutynothistory where isintern is false and date = '{targetDate}'").ToList();
          if (tmpDutys.Count != 0)
          {
            foreach (var tmpDuty in tmpDutys)
            {
              if (tmpDuty.date.Equals(targetDate))
              {
                if (EternalDuty(targetDate))
                {
                  tmpStr += ", @" + tmpDuty.login;
                }
                else
                {
                  if (tmpStr == "")
                    tmpStr += "| @" + tmpDuty.login;
                  else
                    tmpStr += ", @" + tmpDuty.login;
                }
              }
            }
          }
          if (!EternalDuty(targetDate))
          {
            if (tmpStr != "")
            {
              tmpStr += " - дополнительный дежурный";
            }
          }
          tmpDutyList.Add(tmpStr);
        }
        return tmpDutyList;
      }
    }
    /// <summary>
    /// Метод анализирует дату запрощенного дня недели из списка рабочих дней для дежурств
    /// </summary>
    /// <param name="dayOfWeek"></param>
    /// <param name="dutyDays"></param>
    /// <returns>возращает дату требуемого дня недели</returns>
    public static DateTime GetDayOfWeek(string dayOfWeek, List<DateTime> dutyDays)
    {
      DateTime targetDate = new DateTime();
      foreach (var dutyDay in dutyDays)
      {
        if (dayOfWeek.Equals(dutyDay.DayOfWeek.ToString()))
          targetDate = dutyDay;
      }
      return targetDate;
    }
    /// <summary>
    /// метод
    /// </summary>
    /// <param name="intern">список стажеров</param>
    /// <param name="endDateOfWeek">конец недели</param>
    /// <param name="startDateOfWeek">начало недели</param>
    /// <returns>возвращает кортеж списка дежурных с закрепленными днями недели и командами дежурных</returns>
    public static List<Tuple<DateTime, string, string>> GetDutyList(List<string> intern, DateTime endDateOfWeek, DateTime startDateOfWeek)
    {
      List<Tuple<DateTime, string, string>> newDutyList = new List<Tuple<DateTime, string, string>>(); //ДАТА : Дежурный : Команда Дежурного
      using (ApplicationContext db = new ApplicationContext())
      {
        var dutyHistory = db.DutyHistorys.Where(x => x.Date >= startDateOfWeek && x.Date <= endDateOfWeek).ToList();
        //Рефакторинг
        //var dutyHistory = db.DutyHistorys.FromSqlRaw(string.Format("select * from dutyhistory " +
        //    "where date between '{0}' and '{1}'", startDateOfWeek, endDateOfWeek)).ToList();
        var users = db.Users.ToList();
        //Рефакторинг
        //var users = db.Users.FromSqlRaw("SELECT * FROM users").ToList();
        var dutyList = from d in dutyHistory
                       join u in users on d.Iduser equals u.Id
                       select new { date = d.Date, iduser = d.Iduser, login = u.Login, team = u.Team };
        foreach (var d in dutyList)
        {
          if (!d.login.ToLower().Equals(Config.EternalDuty.ToLower()) && !intern.Contains(d.login))
            newDutyList.Add(new Tuple<DateTime, string, string>(d.date, d.login, d.team));
        }
      }
      return newDutyList;
    }

    /// <summary>
    /// Метод для преобразования введенного пользователем текста к дню недели на английском языке
    /// </summary>
    /// <param name="inputTxt">Полученный от пользователя текст дня недели</param>
    /// <returns>День недели на английском языке, либо пустое значение если введеный текст не распознан</returns>
    public static string textToDayFormat(string inputTxt)
    {
      switch (inputTxt.ToLower().Trim())
      {
        case "понедельник":
          return "Monday";
        case "пн":
          return "Monday";
        case "вторник":
          return "Tuesday";
        case "вт":
          return "Tuesday";
        case "среда":
          return "Wednesday";
        case "ср":
          return "Wednesday";
        case "четверг":
          return "Thursday";
        case "чт":
          return "Thursday";
        case "пятница":
          return "Friday";
        case "пт":
          return "Friday";
        case "суббота":
          return "Saturday";
        case "сб":
          return "Saturday";
        case "воскресенье":
          return "Sunday";
        case "вс":
          return "Sunday";
        default:
          return "";
      }
    }
  }
}