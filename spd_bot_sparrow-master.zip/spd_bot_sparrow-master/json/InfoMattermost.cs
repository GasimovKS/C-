﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace spd_bot_sparrow
{
    /// <summary>
    /// Классы для серилизации информации о пользователях.
    /// </summary>
    public class UsersInfo
    {
        public string id { get; set; }
        public long create_at { get; set; }
        public long update_at { get; set; }
        public int delete_at { get; set; }
        public string username { get; set; }
        public string auth_data { get; set; }
        public string auth_service { get; set; }
        public string email { get; set; }
        public string nickname { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string position { get; set; }
        public string roles { get; set; }
        public Props props { get; set; }
        public string locale { get; set; }
        public Timezone timezone { get; set; }
        public bool disable_welcome_email { get; set; }
    }
    public class Props
    {
        public string focalboard_onboardingTourStarted { get; set; }
        public string focalboard_onboardingTourStep { get; set; }
        public string focalboard_tourCategory { get; set; }
        public string focalboard_welcomePageViewed { get; set; }
    }

    public class Timezone
    {
        public string automaticTimezone { get; set; }
        public string manualTimezone { get; set; }
        public string useAutomaticTimezone { get; set; }
    }

    /// <summary>
    /// Класс для десерилизация ответа от сервера ММ о создании канала прямых сообщений. Отсюда нам нужен ID
    /// </summary>
    public class DirectChannelInfo
    {
        public string id { get; set; }
        public long create_at { get; set; }
        public long update_at { get; set; }
        public int delete_at { get; set; }
        public string team_id { get; set; }
        public string type { get; set; }
        public string display_name { get; set; }
        public string name { get; set; }
        public string header { get; set; }
        public string purpose { get; set; }
        public long last_post_at { get; set; }
        public int total_msg_count { get; set; }
        public int extra_update_at { get; set; }
        public string creator_id { get; set; }
        public object scheme_id { get; set; }
        public object props { get; set; }
        public object group_constrained { get; set; }
        public bool? shared { get; set; }
        public int total_msg_count_root { get; set; }
        public object policy_id { get; set; }
        public long last_root_post_at { get; set; }
    }

    /// <summary>
    /// Класс для единичного сообщения
    /// </summary>
    public class OneMessage
    {
        public string id { get; set; }
        public long create_at { get; set; }
        public long update_at { get; set; }
        public long edit_at { get; set; }
        public long delete_at { get; set; }
        public bool is_pinned { get; set; }
        public string user_id { get; set; }
        public string channel_id { get; set; }
        public string root_id { get; set; }
        public string original_id { get; set; }
        public string message { get; set; }
        public string type { get; set; }
        public PropsInPost props { get; set; }
        public string hashtags { get; set; }
        public string pending_post_id { get; set; }
        public int reply_count { get; set; }
        public int last_reply_at { get; set; }
        public object participants { get; set; }
        public MetadataInPost metadata { get; set; }
    }

    public class PropsInPost
    {
        public string from_bot { get; set; }
    }

    public class MetadataInPost
    {
    }

    /// <summary>
    /// Класс информации о загруженном файле
    /// </summary>
    public class fileInfo
    {
        public File_Infos[] file_infos { get; set; }
        public object client_ids { get; set; }
    }
    public class File_Infos
    {
        public string id { get; set; }
        public string user_id { get; set; }
        public string channel_id { get; set; }
        public long create_at { get; set; }
        public long update_at { get; set; }
        public int delete_at { get; set; }
        public string name { get; set; }
        public string extension { get; set; }
        public int size { get; set; }
        public string mime_type { get; set; }
        public object mini_preview { get; set; }
        public string remote_id { get; set; }
    }

    /// <summary>
    /// класс для реакция на постах.
    /// </summary>
    public class EmojyReaction
    {
        public string user_id { get; set; }
        public string post_id { get; set; }
        public string emoji_name { get; set; }
        public long create_at { get; set; }
        public long update_at { get; set; }
        public int delete_at { get; set; }
        public string remote_id { get; set; }
    }

}
